
* 1) Classic DHS:
gen beatout= 1 if M1==1
replace beatout= 0 if M1==0
gen beatch= 1 if M2==1
replace beatch= 0 if M2==0
gen beatarg= 1 if M3==1
replace beatarg= 0 if M3==0
gen beatsex= 1 if M4==1
replace beatsex= 0 if M4==0
gen beatburn= 1 if M5==1
replace beatburn= 0 if M5==0

egen beat = rowmax(beatout-beatburn)

*need to recode the vioence variables so that zero on A implies zero on B


* 1) Less severe violence:
* spouse ever pushed, shook or threw something
recode  M_17A (-77=0) (-99=0), gen(less_severe1) 
* spouse ever slapped
recode M_18A (-77=0) (-99=0), gen(less_severe2) 
* spouse ever twist arm or pull hair?
recode M_19A (-77=0) (-99=0), gen(less_severe3) 
* spouse ever punched with fist or something harmful
recode M_20A (-77=0) (-99=0), gen(less_severe4) 
* spouse ever kicked or dragged
recode M_21A (-77=0) (-99=0), gen(less_severe5) 
egen less_severe_violence = rowmax(less_severe1-less_severe5)

* 2) Severe violence:
* spouse ever tried to strangle or burn
recode M_22A (-77=0) (-99=0), gen(severe1) 
* spouse ever threatened with knife/gun or other weapon
recode M_23A (-77=0) (-99=0), gen(severe2) 
egen severe_violence = rowmax(severe1-severe2)

* 3) Sexual violence:
* spouse ever physically forced sex when not wanted
recode M_24A (-77=0) (-99=0), gen(sexual1) 
* spouse ever forced other sexual acts when not wanted
recode M_25A (-77=0) (-99=0), gen(sexual2) 
* spouse ever forced with threats sexual acts when not wanted
recode M_26A (-77=0) (-99=0), gen(sexual3) 
egen sexual_violence = rowmax(sexual1-sexual3)

* Other
/*

	if yes, specify	Freq.	Percent	Cum.
				
	77	1,294	99.54	99.54
He	cheated over me, I thought he has ..	1	0.08	99.62
He	doesn't give me money for monthely..	1	0.08	99.69
He	has stopped giving me money for mo..	1	0.08	99.77
	He pinned me	1	0.08	99.85
He	stopped giving money for monthly e..	1	0.08	99.92
He	wasn't give enough money for month..	1	0.08	100.00
				
	Total	1,300	100.00
*/

egen physical_violence = rowmax(less_severe_violence severe_violence sexual_violence) 

* Last 3 months:
* 1) Less severe violence:
* spouse ever pushed, shook or threw something
recode  M_17B (-77=0), gen(less_severe1_3m) 
replace less_severe1_3m=0 if M_17A==0
* spouse ever slapped
recode M_18B (-77=0), gen(less_severe2_3m) 
replace less_severe2_3m=0 if M_18A==0
* spouse ever twist arm or pull hair?
recode M_19B (-77=0), gen(less_severe3_3m) 
replace less_severe3_3m=0 if M_19A==0
* spouse ever punched with fist or something harmful
recode M_20B (-77=0), gen(less_severe4_3m) 
replace less_severe4_3m=0 if M_20A==0
* spouse ever kicked or dragged
recode M_21B (-77=0), gen(less_severe5_3m) 
replace less_severe5_3m=0 if M_21A==0
egen less_severe_violence_3m = rowmax(less_severe1_3m-less_severe5_3m)

* 2) Severe violence:
* spouse ever tried to strangle or burn
recode M_22B (-77=0), gen(severe1_3m) 
replace severe1_3m=0 if M_22A==0
* spouse ever threatened with knife/gun or other weapon
recode M_23B (-77=0), gen(severe2_3m) 
replace severe2_3m=0 if M_23A==0
egen severe_violence_3m = rowmax(severe1_3m-severe2_3m)

* 3) Sexual violence:
* spouse ever physically forced sex when not wanted
recode M_24B (-77=0), gen(sexual1_3m) 
replace sexual1_3m=0 if M_24A==0
* spouse ever forced other sexual acts when not wanted
recode M_25B (-77=0), gen(sexual2_3m) 
replace sexual2_3m=0 if M_25A==0
* spouse ever forced with threats sexual acts when not wanted
recode M_26B (-77=0), gen(sexual3_3m) 
replace sexual3_3m=0 if M_26A==0
egen sexual_violence_3m = rowmax(sexual1_3m-sexual3_3m)

egen physical_violence_3m = rowmax(less_severe_violence_3m severe_violence_3m sexual_violence_3m) 


recode M_39 (-99=0) (-88=.) (-77=0), gen(fbm)


* Psychological/emotional violence: 
* DHS
recode M_13A   (-99 9=.), gen(husband_humiliated) 
recode M_14A   (-99 9=.), gen(husband_threatened) 
recode M_15A   (-99 9=.), gen(husband_insult) 
egen emotional_violence = rowmax(husband_humiliated-husband_insult)

* Last 3 months:
recode M_13B  (-77=0), gen(husband_humiliated_3m) 
replace husband_humiliated_3m=0 if husband_humiliated==0

recode M_14B  (-77=0), gen(husband_threatened_3m) 
replace husband_threatened_3m=0 if husband_threatened==0
recode M_15B  (-77=0), gen(husband_insult_3m) 
replace husband_insult_3m=0 if husband_insult==0
egen emotional_violence_3m = rowmax(husband_humiliated_3m-husband_insult_3m)

su emo* husband_humiliated_3m-husband_insult_3m


* Control issues 
* Classic DHS:
recode M_7A (2/9=.) (-88 -99=.), gen(husband_jealous) 
recode M_8A (2/9=.) (-88 -99=.), gen(husband_accuses) 
recode M_9A (2/9=.) (-88 -99=.), gen(husband_forbids_friends) 
recode M_10A (2/9=.) (-88 -99=.), gen(husband_limit_famcontact) 
recode M_11A (2/9=.) (-88 -99=.), gen(husband_must_know) 
egen number_control = rowtotal(husband_jealous-husband_must_know), missing


* We have these for the last 3 months as well:
recode M_7B (2/9=.) (-77=0), gen(husband_jealous_3m) 
replace husband_jealous_3m=0 if husband_jealous==0

recode M_8B (2/9=.) (-77=0), gen(husband_accuses_3m) 
replace husband_accuses_3m=0 if husband_accuses==0
recode M_9B (2/9=.) (-77=0), gen(husband_forbids_friends_3m) 
replace husband_forbids_friends_3m=0 if husband_forbids_friends==0
recode M_10B (2/9=.) (-77=0), gen(husband_limit_famcontact_3m) 
replace husband_limit_famcontact_3m=0 if husband_limit_famcontact==0
recode M_11B (2/9=.) (-77=0), gen(husband_must_know_3m) 
replace husband_must_know_3m=0 if husband_must_know==0
egen number_control_3m = rowtotal(husband_jealous_3m-husband_must_know_3m), missing





*OBS LOOK through. Looks good now. 

* Gender attitudes, 1=non gender equal
tab Ga_1
recode Ga_1 (1/2=1) (3/4=0) (-88=.), gen(ga_son_school)
tab Ga_2
* No variation: Eveyryone thinks it is OK for women to work
tab Ga_3
recode Ga_3 (1/2=0) (3/4=1) (-88=.), gen(ga_earn_more)
tab Ga_4
recode Ga_4 (1/2=0) (3/4=1) (-88=.), gen(ga_decide_money)
tab Ga_5
recode Ga_5 (1/2=0) (3/4=1) (-88=.), gen(ga_leave_house_night)
tab Ga_6
recode Ga_6 (1/2=0) (3/4=1) (-88=.), gen(ga_men_childcare)
tab Ga_7
recode Ga_7 (1/2=0) (3/4=1) (-88=.), gen(ga_men_hhwork)
tab Ga_8
recode Ga_8 (1/2=1) (3/4=0) (-88=.), gen(ga_men_imp_dec)
tab Ga_9
recode Ga_9 (1/2=1) (3/4=0) (-88=.), gen(ga_tolerate_abuse)
tab Ga_10
recode Ga_10 (1/2=0) (3/4=1) (-88=.), gen(ga_seekh_har)
tab Ga_11
recode Ga_11 (1/2=0) (3/4=1)(-88=.) , gen(ga_seekrec_har)

gen number_ga=ga_son_school+ga_earn_more+ga_decide_money+ga_leave_house_night+ga_men_childcare+ga_men_hhwork+ga_men_imp_dec+ga_tolerate_abuse+ga_seekh_har+ga_seekrec_har
tab number_ga
gen equal_index= number_ga/10
su equal_index ga_* Ga_*

***************** Earnings ******************
* Note, the last one is "Other, specify" and has many missings. We code missings as zero:
replace D5_6I=0 if D5_6I==.
replace D5_6Ii=0 if D5_6Ii==.

* Main end variable: Earnings from factory job last 6 months:
su D5_1I
recode D5_1I (1/`r(max)'=1) (0=0) (-77=.) (-99=.), gen(fac_last6)
* Husband
su D5_2Ii
recode D5_1Ii (1/`r(max)'=1) (0=0) (-77=.) (-99=.), gen(husb_fac_last6)
* Earnings from other wage job last 12 months:
su D5_2I
recode D5_2I (1/`r(max)'=1) (0=0) (-77=.) (-99=.), gen(othw_last6)
* Husband
su D5_2Ii
recode D5_2Ii (1/`r(max)'=1) (0=0) (-77=.) (-99=.), gen(husb_othw_last6)




gen any_wage_job_last6=fac_last6
replace any_wage_job_last6=1 if othw_last6==1

gen husb_any_wage_job_last6=husb_fac_last6
replace husb_any_wage_job_last6=1 if husb_othw_last6==1



gen earnings_formal_last6=D5_1I+D5_2I if D5_1I>=0 &  D5_2I>=0
gen husb_earnings_formal_last6=D5_1Ii+D5_2Ii  if D5_1Ii>=0 &  D5_2Ii>=0
gen earnings_formal_share_last6=earnings_formal_last6/(earnings_formal_last6+husb_earnings_formal_last6)

gen earnings_last6=D5_1I+D5_2I+D5_3I if D5_1I>=0 &  D5_2I>=0 &  D5_3I>=0
gen husb_earnings_last6=D5_1Ii+D5_2Ii+D5_3Ii if D5_1Ii>=0 &  D5_2Ii>=0 &  D5_3Ii>=0
gen earnings_share_last6=earnings_last6/(earnings_last6+husb_earnings_last6)
* If both are zero:
replace earnings_share_last6=1 if earnings_last6==0 & husb_earnings_last6==0

* 1200= 361 NOK


gen income_last6=D5_1I+D5_2I+D5_3I+D5_4I+D5_5I+D5_6I if D5_1I>=0 &  D5_2I>=0 &  D5_3I>=0 &  D5_4I>=0 & D5_5I>=0  & D5_6I>=0 
gen husb_income_last6=D5_1Ii+D5_2Ii+D5_3Ii+D5_4Ii+D5_5Ii+D5_6Ii if D5_1Ii>=0 &  D5_2Ii>=0 &  D5_3Ii>=0&  D5_4Ii>=0 &  D5_5Ii>=0&  D5_6Ii>=0 
gen income_share_last6=income_last6/(income_last6+husb_income_last6)


recode earnings_formal_share_last6 (0.5/1=1) (0/0.49999=0), gen(she_more)
gen she_more_earnings=she_more*earnings_formal_share_last6


* Main endogenous variable from pre-plan: formal
note: the variable is coded in two different ways in this version of the data
gen formal_last6= Ka1_1 
*replace formal_last6=K1_1 if Ka1_1==.

replace formal_last6=1 if Kb_1==1
replace formal_last6=0 if Kb_1==0

tab fac_last6 if Ka1_1==1

* merge with baseline data: created in base_for_follow_up_July18.do. Note, only merging the randomized sample
/*
rename N_Id n_id
tostring n_id, gen(aa)
gen N_Id="N"+aa
drop aa
*/
merge 1:1 N_Id using "C:\Users\andrkot\Dropbox\GBV_application\Data\base_fu_j18.dta", 


rename earnings_formal_last6 ea_f_last6
rename earnings_formal_share_last6 ea_f_sh_last6
rename earnings_last6 ea_last6
rename earnings_share_last6 ea_sh_last6

rename base_earnings_formal_last6 base_ea_f_last6
rename base_earnings_formal_share_last6 base_ea_f_sh_last6
rename base_earnings_last6 base_ea_last6
rename base_earnings_share_last6 base_ea_sh_last6


gen base_formal_last6=base_K1



rename less_severe_violence_3m less_3m



****************** New emp index ***************'
*Make new empoverment index
* 1 and 2 only apply to some. 
* He decides unless: 1) she decides or 2) they decide together and she has a lot to say (from B)

recode J1A_03 (2 12 23 24=1) (1 3 4 13 14 34=0), gen(h_fs_she_sick)
replace h_fs_she_sick=0 if J1A_03==12 & J1B_03==4
recode J1A_04 (2 12 23 24=1) (1 3 4 13 14 34=0) (-77=.) (-99=.), gen(h_fs_nrch)
replace h_fs_nrch=0 if J1A_04==12 & J1B_04==4
recode J1A_05 (2 12 23 24=1) (1 3 4 13 14 34=0) (-77=.) (-99=.), gen(h_fs_contraception)
replace h_fs_contraception=0 if J1A_05==12 & J1B_05==4
recode J1A_06 (2 12 23 24=1) (1 3 4 13 14 34=0) (-77=.) (-99=.), gen(h_fs_earn_outside)
replace h_fs_earn_outside=0 if J1A_06==12 & J1B_06==4
recode J1A_07 (2 12 23 24=1) (1 3 4 13 14 34=0) (-77=.) (-99=.), gen(h_fs_visit_rel)
replace h_fs_visit_rel=0 if J1A_07==12 & J1B_07==4
recode J1A_08 (2 12 23 24=1) (1 3 4 13 14 34=0) (-77=.) (-99=.) (-99=.) (-99=.), gen(h_fs_use_earn)
replace h_fs_use_earn=0 if J1A_08==12 & J1B_08==4
recode J1A_09 (2 12 23 24=1) (1 3 4 13 14 34=0) (-77=.) (-99=.), gen(h_fs_use_h_earn)
replace h_fs_use_h_earn=0 if J1A_09==12 & J1B_09==4
recode J1A_10 (2 12 23 24=1) (1 3 4 13 14 34=0) (-77=.) (-99=.), gen(h_fs_small_p)
replace h_fs_small_p=0 if J1A_10==12 & J1B_10==4
recode J1A_11 (2 12 23 24=1) (1 3 4 13 14 34=0) (-77=.) (-99=.), gen(h_fs_bulk_p)
replace h_fs_bulk_p=0 if J1A_11==12 & J1B_11==4
recode J1A_12 (2 12 23 24=1) (1 3 4 13 14 34=0) (-77=.) (-99=.), gen(h_fs_large_p)
replace h_fs_large_p=0 if J1A_12==12 & J1B_12==4
recode J1A_14 (2 12 23 24=1) (1 3 4 13 14 34=0) (-77=.) (-99=.), gen(h_fs_bank)
replace h_fs_bank=0 if J1A_14==12 & J1B_14==4
recode J1A_15 (2 12 23 24=1) (1 3 4 13 14 34=0) (-77=.) (-99=.), gen(h_fs_business)
replace h_fs_business=0 if J1A_14==12 & J1B_15==4

gen h_fs_index= (h_fs_she_sick +h_fs_nrch +h_fs_contraception +h_fs_earn_outside +h_fs_visit_rel +h_fs_use_earn +h_fs_use_h_earn +h_fs_bulk_p +h_fs_small_p +h_fs_large_p +h_fs_business +h_fs_bank)/12

gen h_fs_nr= h_fs_she_sick +h_fs_nrch +h_fs_contraception +h_fs_earn_outside +h_fs_visit_rel +h_fs_use_earn +h_fs_use_h_earn +h_fs_bulk_p +h_fs_small_p +h_fs_large_p +h_fs_business +h_fs_bank

* generate an index without the working variables
gen h_fs_index_small= (h_fs_she_sick +h_fs_nrch +h_fs_contraception +h_fs_earn_outside +h_fs_visit_rel +h_fs_bulk_p +h_fs_small_p +h_fs_large_p +h_fs_business +h_fs_bank)/10



	  
* merge =1 those that should be missing due to non-rand. 
tab A4 if _m==1
* Drop these now
drop if _m==1
* Merge=2 actual attrition
  tab region if _m==2

  gen attrit=1 if _m==2
  replace attrit=0 if _m!=2
  


drop _m



* interaction terms for ITT:
foreach var of varlist  base_formal_last6 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///
base_h_fs_she_sick base_h_fs_nrch base_h_fs_contraception base_h_fs_earn_outside base_h_fs_visit_rel base_h_fs_use_earn ///
base_h_fs_use_h_earn base_h_fs_small_p base_h_fs_bulk_p base_h_fs_large_p base_h_fs_bank base_h_fs_business base_h_fs_index base_h_fs_nr ///
base_age_gap base_number_ga h_fs_index_small ///
{
gen `var'_ot=orig_treatment*`var'
}

* For now, just take the baseline values of these:

gen age =base_age
gen Muslim =base_Muslim
gen Protestant =base_Protestant
gen Medium_edu =base_Medium_edu
gen High_edu =base_High_edu






* Create sample including all non-attrited women

reg physical_violence_3m orig_treatment  i.block, cl(N_Id) 
gen main_s=1 if e(sample)==1


* Divide husb earnings by 1000:
gen husb_earnings_last6_sc=husb_earnings_last6/1000
gen base_husb_earnings_last6_sc=base_husb_earnings_last6/1000


* Identity by treatment:
gen she_more_T=orig_treatment*she_more
gen share_T=orig_treatment*ea_f_sh_last6 
gen she_more_earnings_T=orig_treatment*she_more_earnings


gen h_work_T=orig_treatment*husb_any_wage_job_last6
gen base_h_work_T=orig_treatment*base_husb_any_wage_job_last6
gen h_earn_T=orig_treatment*husb_earnings_last6_sc 
gen base_h_earn_T=orig_treatment*base_husb_earnings_last6_sc  
gen share_earn_T=orig_treatment*ea_f_sh_last6
gen base_share_earn_T=orig_treatment*base_ea_f_sh_last6

************** Leisure and social relations ***********
tab I1_10A
recode I1_10A (-77 -99=.), gen(leisure)
tab I1_9A
recode I1_9A (-77=.), gen(soc_rel)

recode I1_10C (-77 -99=.), gen(leisure_daughter)

tab I1_10C

reg leisure_daughter orig_treatment  i.block ,  cl(N_Id) 

tab I1_3A
recode I1_3A (-77 -99=.), gen(hh_work)
tab I1_3B
recode I1_3B (-77 -99=.), gen(hh_work_husb)
tab I1_3C
recode I1_3C (-77 -99=.), gen(hh_work_daughter)

tab I1_1A
recode I1_3A (-77 -99=.), gen(hours)
tab I1_1B
recode I1_1B (-77 -99=.), gen(hours_husb)
tab I1_1C
recode I1_1C (-77 -99=.), gen(hours_daughter)



gen travel_time=I1_8A


 * Fixing
 replace number_control_3m=. if number_control_3m==-99
