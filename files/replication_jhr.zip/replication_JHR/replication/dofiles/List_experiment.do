
	* Change to your own directory 
global data = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\Data"
global results = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\results"
capture global 	do = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\dofiles"

use "$data\replication_data_list.dta", clear


* List table
su p_punches p_hits T2 T3
des p_punches p_hits
reg L_p_punches T3, robust

reg L_p_hits T2, robust
 estadd local Controls "None"
su L_p_hits if e(sample)==1 & T2==0
estadd scalar mean_L_p_c = r(mean)
su p_hits if e(sample)==1 & T2==0
estadd scalar mean_p_c = r(mean)
eststo L_p_hits


tabstat  p_hits if e(sample)==1 & T2==0, s(mean semean n)
reg L_p_punches T3, robust
 estadd local Controls "None"
su L_p_punches if e(sample)==1 & T2==0
estadd scalar mean_L_p_c = r(mean)
sum p_punches if e(sample)==1 & T3==0
estadd scalar mean_p_c = r(mean)
*estadd scalar mean_p_cse = r(semean)
eststo L_p_punches
*add by hand
tabstat  p_punches if e(sample)==1 & T3==0, s(mean semean n)


********* Table:  ************
	
local varlist /// 
T2 T3 ///



cd "$results"
#delimit;
	noisily esttab L_p_hits L_p_punches using "List_nov18.tex", 
	style(tex) stats(mean_L_p_c mean_p_c N r2 Controls, labels("Mean nr answers in C group" "Mean direct question in C group" "No. of observations" "R-squared" "Controls") 
	fmt(2 2 0 2)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles( "Partner hits sometimes"  "Partner punched last 3 months"  )
		keep(`varlist') order(`varlist')
		varlabels(
	T2 "List treatment"
	T3 "List treatment"
	orig_treatment "Treatment"
	base_formal_last6 "Any wage job last 6 months (B)" 
		)
	prehead("\begin{tabular}{l*{12}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
***************** coefplot ****************************


* Sometimes your partner hits you when he gets angry


gen new_l2=L_p_hits
replace new_l2=L_p_hits+p_hits if T2==0
* Just for presentation
gen T2_d=T2

reg new_l2 T2_d, robust
reg new_l2 T2_d##base_formal_last6, robust
reg new_l2 T2_d base_formal_last6 base_physical_violence_3m, robust

reg L_p_hits T2 i.block, robust
reg L_p_hits T2 base_formal_last6 orig_treatment T2#orig_treatment i.block, robust
reg L_p_hits T2 i.block, robust
reg L_p_hits T2 i.block, robust


reg new_l2 T2_d, robust
estimates store l2_diff
reg L_p_hits T2, robust
estimates store l2_list
reg p_hits if e(sample)==1 & T2==0
estimates store l2_direct


coefplot (l2_list, keep(T2) label(List)) (l2_direct, keep(_cons) label(Direct))  (l2_diff, keep(T2_d) label(Difference)), ///
coeflabels(T2 = "List"  _cons= "Direct" T2_d = "Difference", notick labsize(small))  yline(0) vertical order(T2 _cons T2_d) 

coefplot (l2_list, keep(T2) label(List)) (l2_direct, keep(_cons) label(Direct))  (l2_diff, keep(T2_d) label(Difference)), ///
legend(off) coeflabels(T2 = "List"  _cons= "Direct" T2_d = "Difference", notick labsize(small))  yline(0) vertical order(T2 _cons T2_d) 
		gr save list_all.gph, replace
		graph export "$results\list_all.png", replace 
		graph export "$results\list_all.pdf", replace 




* Treatment and control:
reg new_l2 T2_d if orig_treatment==1, robust
estimates store l2_diff_t
reg L_p_hits T2 if orig_treatment==1, robust
estimates store l2_list_t
reg p_hits if e(sample)==1 & T2==0
estimates store l2_direct_t

reg new_l2 T2_d if orig_treatment==0, robust
estimates store l2_diff_c
reg L_p_hits T2 if orig_treatment==0, robust
estimates store l2_list_c
reg p_hits if e(sample)==1 & T2==0
estimates store l2_direct_c


coefplot (l2_list_t, keep(T2) label(List)) (l2_direct_t, keep(_cons) label(Direct))  (l2_diff_t, keep(T2_d) label(Difference)),  ///
legend(off) coeflabels(T2 = "List"  _cons= "Direct" T2_d = "Difference", notick labsize(small))  title(Treated) yline(0) vertical order(T2 _cons T2_d) 
gr save a1.gph, replace

coefplot (l2_list_c, keep(T2) label(List)) (l2_direct_c, keep(_cons) label(Direct))  (l2_diff_c, keep(T2_d) label(Difference)),  ///
legend(off) coeflabels(T2 = "List"  _cons= "Direct" T2_d = "Difference", notick labsize(small))   title(Control) yline(0) vertical order(T2 _cons T2_d) 
gr save a2.gph, replace

 	
* Employment at base:
reg new_l2 T2_d if base_formal_last6==1, robust
estimates store l2_diff_e
reg L_p_hits T2 if base_formal_last6==1, robust
estimates store l2_list_e
reg p_hits if e(sample)==1 & T2==0
estimates store l2_direct_e

reg new_l2 T2_d if base_formal_last6==0, robust
estimates store l2_diff_ne
reg L_p_hits T2 if base_formal_last6==0, robust
estimates store l2_list_ne
reg p_hits if e(sample)==1 & T2==0
estimates store l2_direct_ne


coefplot (l2_list_e, keep(T2) label(List)) (l2_direct_e, keep(_cons) label(Direct))  (l2_diff_e, keep(T2_d) label(Difference)),  ///
legend(off) coeflabels(T2 = "List"  _cons= "Direct" T2_d = "Difference", notick labsize(small))  title(Employed at baseline) yline(0) vertical order(T2 _cons T2_d) 
gr save b1.gph, replace

coefplot (l2_list_ne, keep(T2) label(List)) (l2_direct_ne, keep(_cons) label(Direct))  (l2_diff_ne, keep(T2_d) label(Difference)),  ///
legend(off) coeflabels(T2 = "List"  _cons= "Direct" T2_d = "Difference", notick labsize(small))   title(Not employed) yline(0) vertical order(T2 _cons T2_d) 
gr save b2.gph, replace

 #delimit ;
graph combine a1.gph a2.gph b1.gph b2.gph, 
ycommon
;
 #delimit cr
  gr save list_t_c.gph, replace
 graph export "$results\list_groups.png", replace
  graph export "$results\list_groups.pdf", replace 
		gr save list_groups.gph, replace

*************** Punch variable ****************

gen new_l3=L_p_punches
replace new_l3=L_p_punches+p_punches if T3==0
* Just for presentation
gen T3_d=T3

reg new_l3 T3_d, robust
reg new_l3 T3_d##base_formal_last6, robust
reg new_l3 T3_d base_formal_last6 base_physical_violence_3m, robust

reg L_p_punches T3 i.block, robust
reg L_p_punches T3 base_formal_last6 orig_treatment T3#orig_treatment i.block, robust
reg L_p_punches T3 i.block, robust
reg L_p_punches T3 i.block, robust


reg new_l3 T3_d, robust
estimates store l3_diff
reg L_p_punches T3, robust
estimates store l3_list
reg p_punches if e(sample)==1 & T3==0
estimates store l3_direct


coefplot (l3_list, keep(T3) label(List)) (l3_direct, keep(_cons) label(Direct))  (l3_diff, keep(T3_d) label(Difference)), ///
coeflabels(T3 = "List"  _cons= "Direct" T3_d = "Difference", notick labsize(small))  yline(0) vertical order(T3 _cons T3_d) 

coefplot (l3_list, keep(T3) label(List)) (l3_direct, keep(_cons) label(Direct))  (l3_diff, keep(T3_d) label(Difference)), ///
legend(off) coeflabels(T3 = "List"  _cons= "Direct" T3_d = "Difference", notick labsize(small))  yline(0) vertical order(T3 _cons T3_d) 
		graph export "$results\list_all_p_punches.png", replace 
		graph export "$results\list_all_p_punches.pdf", replace 
		gr save list_all_p_punches.gph, replace




* Treatment and control:
reg new_l3 T3_d if orig_treatment==1, robust
estimates store l3_diff_t
reg L_p_punches T3 if orig_treatment==1, robust
estimates store l3_list_t
reg p_punches if e(sample)==1 & T3==0
estimates store l3_direct_t

reg new_l3 T3_d if orig_treatment==0, robust
estimates store l3_diff_c
reg L_p_punches T3 if orig_treatment==0, robust
estimates store l3_list_c
reg p_punches if e(sample)==1 & T3==0
estimates store l3_direct_c


coefplot (l3_list_t, keep(T3) label(List)) (l3_direct_t, keep(_cons) label(Direct))  (l3_diff_t, keep(T3_d) label(Difference)),  ///
legend(off) coeflabels(T3 = "List"  _cons= "Direct" T3_d = "Difference", notick labsize(small))  title(Treated) yline(0) vertical order(T3 _cons T3_d) 
gr save a1.gph, replace

coefplot (l3_list_c, keep(T3) label(List)) (l3_direct_c, keep(_cons) label(Direct))  (l3_diff_c, keep(T3_d) label(Difference)),  ///
legend(off) coeflabels(T3 = "List"  _cons= "Direct" T3_d = "Difference", notick labsize(small))   title(Control) yline(0) vertical order(T3 _cons T3_d) 
gr save a3.gph, replace

 	
* Employment at base:
reg new_l3 T3_d if base_formal_last6==1, robust
estimates store l3_diff_e
reg L_p_punches T3 if base_formal_last6==1, robust
estimates store l3_list_e
reg p_punches if e(sample)==1 & T3==0
estimates store l3_direct_e

reg new_l3 T3_d if base_formal_last6==0, robust
estimates store l3_diff_ne
reg L_p_punches T3 if base_formal_last6==0, robust
estimates store l3_list_ne
reg p_punches if e(sample)==1 & T3==0
estimates store l3_direct_ne


coefplot (l3_list_e, keep(T3) label(List)) (l3_direct_e, keep(_cons) label(Direct))  (l3_diff_e, keep(T3_d) label(Difference)),  ///
legend(off) coeflabels(T3 = "List"  _cons= "Direct" T3_d = "Difference", notick labsize(small))  title(Employed at baseline) yline(0) vertical order(T3 _cons T3_d) 
gr save b1.gph, replace

coefplot (l3_list_ne, keep(T3) label(List)) (l3_direct_ne, keep(_cons) label(Direct))  (l3_diff_ne, keep(T3_d) label(Difference)),  ///
legend(off) coeflabels(T3 = "List"  _cons= "Direct" T3_d = "Difference", notick labsize(small))   title(Not employed) yline(0) vertical order(T3 _cons T3_d) 
gr save b3.gph, replace


 #delimit ;
graph combine a1.gph a3.gph b1.gph b3.gph, 
ycommon
;
 #delimit cr
  gr save list_t_c.gph, replace
 graph export "$results\list_groups_p_punches.png", replace
  graph export "$results\list_groups_p_punches.pdf", replace 
 		gr save list_groups_p_punches.gph, replace
 

	