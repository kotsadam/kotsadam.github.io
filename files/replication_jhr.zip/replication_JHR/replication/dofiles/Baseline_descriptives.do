
	* Change to your own directory 
global data = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\Data"
global results = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\results"
capture global 	do = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\dofiles"

set more off
* Created in follow up march 2018
use "$data\replication_data_first_fu.dta", clear

* keep sample of non-attrited women
keep if main_s==1

local varlist /// 
physical_violence physical_violence_3m less_severe_violence less_3m ///
severe_violence severe_violence_3m sexual_violence sexual_violence_3m ///
emotional_violence emotional_violence_3m number_control  number_control_3m  ///
h_fs_index h_fs_nr equal_index number_ga ///


cd "$results"
estpost summarize `varlist' 
est save "desk_viol", replace
eststo viol


local varlist /// 
formal_last6  ea_f_last6 ea_f_sh_last6 ea_last6 ///
ea_sh_last6 income_last6 income_share_last6 she_more ///

cd "$results"
estpost summarize `varlist' 
est save "desk_indep", replace
eststo dep

local varlist /// 
base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///

cd "$results"
estpost summarize `varlist' 
est save "desk_cont", replace
eststo cont

local varlist /// 
physical_violence physical_violence_3m less_severe_violence less_3m ///
severe_violence severe_violence_3m sexual_violence sexual_violence_3m ///
 emotional_violence emotional_violence_3m number_control  number_control_3m  ///
formal_last6  ea_f_last6 ea_f_sh_last6 ea_last6 ///
ea_sh_last6 income_last6 income_share_last6 she_more ///

cd "$results"
estpost summarize `varlist' 
est save "desk_viol_ind", replace
eststo viol_ind

local varlist /// 
physical_violence physical_violence_3m less_severe_violence less_3m ///
severe_violence severe_violence_3m sexual_violence sexual_violence_3m ///
 emotional_violence emotional_violence_3m number_control  number_control_3m  ///
h_fs_index h_fs_nr equal_index number_ga ///
formal_last6  ea_f_last6 ea_f_sh_last6 ea_last6 ///
ea_sh_last6 income_last6 income_share_last6 she_more ///
orig_treatment ///
base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///

cd "$results"
estpost summarize `varlist' 
est save "desk_all", replace
eststo all

 
local varlist /// 
physical_violence physical_violence_3m less_severe_violence less_3m ///
severe_violence severe_violence_3m sexual_violence sexual_violence_3m ///
 emotional_violence emotional_violence_3m number_control  number_control_3m  ///
h_fs_index h_fs_nr equal_index number_ga ///
formal_last6  ea_f_last6 ea_f_sh_last6 ea_last6 ///
ea_sh_last6 income_last6 income_share_last6 she_more ///
orig_treatment ///
base_physical_violence_3m base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn  base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///



cd "$results"
#delimit;
esttab all using "desk_all_nov18.tex",
    style(tex) /*stats(N)*/  
    cells("mean (fmt(3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 0 3 0 3 0 3) pattern(1 1 1 1 1 1)) sd (fmt(3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 0 3 0 3 0 3) par pattern(1 1 1 1 1 1)) ") 
	order(`varlist')
    collabels(\multicolumn{1}{c}{Mean} \multicolumn{1}{c}{SD})
	varlabels(
	physical_violence "Abuse (lifetime)"
	physical_violence_3m "Abuse last 3 months"
	less_severe_violence "Less severe (lifetime)"
	less_3m "Less severe last 3 months"
	severe_violence "Severe (lifetime)"
	severe_violence_3m "Severe last 3 months"
	sexual_violence "Sexual (lifetime)"
	sexual_violence_3m "Sexual last 3 months"
  emotional_violence "Emotional (lifetime)"
  emotional_violence_3m "Emotional last 3 months"
  number_control "Nr of control issues (lifetime)"
  number_control_3m  "Nr control last 3 months"	
  	h_fs_index "Empowerment index" 
	h_fs_nr	"Nr empowerment items"
	 equal_index "Equality index"  
 number_ga "Nr equality items"
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months (in Birr)" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings last 6 months (in Birr)" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months (in Birr)" 
	income_share_last6 "Share of income" 
	orig_treatment "Treatment"	
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
	she_more "She earns more than him"
	base_K1 "Any formal wage job (ever)"
	base_age "Age"
	base_beatout "Justified: goes out"
	base_beatch "Justified: neglects ch"
	base_beatsex "Justified: refuses sex"
	base_beatarg "Justified: argues"	
	base_beatburn "Justified: burns food" 
	base_physical_violence_3m "Abuse last 3 months"
	base_Muslim "Muslim"
	base_Protestant "Protestant"
	base_Medium_edu "Medium education (10 years)"
	base_High_edu "High education (>10 years)"
	base_fbm "Father beat mother"
	,blist(physical_violence "\multicolumn{2}{l}{\emph{Physical abuse variables (1st follow up)}} \\" 
				emotional_violence "\multicolumn{2}{l}{\emph{Other outcome variables (1st follow up)}} \\" 
				formal_last6 "\multicolumn{2}{l}{\emph{Employment and income variables (1st follow up)}} \\"
				orig_treatment "\multicolumn{2}{l}{\emph{Main baseline variables}} \\"
	)
	)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
    replace;
#delimit cr

local varlist /// 
physical_violence physical_violence_3m less_severe_violence less_3m ///
severe_violence severe_violence_3m sexual_violence sexual_violence_3m ///
formal_last6  ea_f_last6 ea_f_sh_last6 ea_last6 ///
ea_sh_last6 income_last6 income_share_last6 she_more ///



cd "$results"
#delimit;
esttab viol_ind using "desk_viol_ind_nov18.tex",
    style(tex) /*stats(N)*/  
    cells("mean (fmt(3) pattern(1 1 1 1 1 1)) sd (fmt(3) par pattern(1 1 1 1 1 1)) ") 
	order(`varlist')
    collabels(\multicolumn{1}{c}{Mean} \multicolumn{1}{c}{SD})
	varlabels(
	physical_violence "Abuse"
	physical_violence_3m "Abuse last 3 months"
	less_severe_violence "Less severe"
	less_3m "Less severe last 3 months"
	severe_violence "Severe"
	severe_violence_3m "Severe last 3 months"
	sexual_violence "Sexual"
	sexual_violence_3m "Sexual last 3 months"
  emotional_violence "Emotional"
  emotional_violence_3m "Emotional last 3 months"
  number_control "Nr of control issues"
  number_control_3m  "Nr control last 3 months"	
		 equal_index "Equality index"  
 number_ga "Nr equality items"
 orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
	she_more "She earns more than him"
	,blist(physical_violence "\multicolumn{2}{l}{\emph{Abuse variables}} \\" 
				formal_last6 "\multicolumn{2}{l}{\emph{Employment and income variables }} \\"
	)
	)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
    replace;
#delimit cr


local varlist /// 
base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///

cd "$results"
#delimit;
esttab cont using "desk_control_nov18.tex",
    style(tex) /*stats(N)*/  
    cells("mean (fmt(3) pattern(1 1 1 1 1 1)) sd (fmt(3) par pattern(1 1 1 1 1 1)) ") 
	order(`varlist')
    collabels(\multicolumn{1}{c}{Mean} \multicolumn{1}{c}{SD})
	varlabels(
	physical_violence "Abuse"
	physical_violence_3m "Abuse last 3 months"
	less_severe_violence "Less severe"
	less_3m "Less severe last 3 months"
	severe_violence "Severe"
	severe_violence_3m "Severe last 3 months"
	sexual_violence "Sexual"
	sexual_violence_3m "Sexual last 3 months"
  emotional_violence "Emotional"
  emotional_violence_3m "Emotional last 3 months"
  number_control "Nr of control issues"
  number_control_3m  "Nr control last 3 months"	
	 equal_index "Equality index"  
 number_ga "Nr equality items"
 orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
	she_more "She earns more than him"
	base_K1 "Any formal wage job (ever)"
	base_age "Age"
	base_beatout "Justified: goes out"
	base_beatch "Justified: neglects ch"
	base_beatsex "Justified: refuses sex"
	base_beatarg "Justified: argues"	
	base_beatburn "Justified: burns food" 
	base_physical_violence_3m "Abuse last 3 months"
	base_Muslim "Muslim"
	base_Protestant "Protestant"
	base_Medium_edu "Medium education"
	base_High_edu "High education"
	base_fbm "Father beat mother"
	,blist(physical_violence "\multicolumn{2}{l}{\emph{Abuse variables}} \\" 
				formal_last6 "\multicolumn{2}{l}{\emph{Employment and income variables }} \\"
	)
	)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
    replace;
#delimit cr



cap drop bviol3
gen bviol3=base_physical_violence_3m
set more off
foreach var of varlist base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn bviol3 base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///
///
{
* Baseline corr after controlling for blocks
reg orig_treatment `var' i.block, cl(N_Id) 
eststo `var'_rc_a
reg physical_violence_3m `var' i.block, cl(N_Id) 
eststo `var'_cv_a
}
reg  orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn bviol3 base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
eststo rc_b
reg  physical_violence_3m base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn bviol3 base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
eststo cv_b

* F-test:
reg  orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn bviol3 base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
test base_K1+base_age+base_beatout+base_beatch+base_beatsex+base_beatarg+ ///
base_beatburn+bviol3+base_Muslim+base_Protestant+base_Medium_edu+base_High_edu+base_fbm==0
/*

       F(  1,  1261) =    1.26
            Prob > F =    0.2628


*/

* Test of baseline predictors
* F-test:
reg  bviol3 base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
test base_K1+base_age+base_beatout+base_beatch+base_beatsex+base_beatarg+ ///
base_beatburn+base_Muslim+base_Protestant+base_Medium_edu+base_High_edu+base_fbm==0
/*

       F(  1,  1261) =    0.01
            Prob > F =    0.9245

*/

set more off
foreach var of varlist base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///
///
{
reg base_physical_violence_3m `var' i.block, cl(N_Id) 
eststo `var'_cvb_a
}
reg  base_physical_violence_3m base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
eststo cvb_b


			local varlist ///
base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn bviol3 base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///
 
cd "$results"
#delimit;
	noisily esttab *_rc_a rc_b using "randc_nov18.tex", 
	style(tex) stats(N r2, labels("No. of observations" "R-squared")  fmt(0 2)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
		mtitles("T" "T" "T" "T" "T" "T" "T" "T" "T" "T" "T" "T" "T" "T" )
	keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	she_more "She earns more than him"
	she_more_earnings "She earns more*Share of earnings"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings last 6 months" 
	ea_sh_last6 "Share of earnings" 
	ea_f_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_she_more "She earns more than him (B)"
	base_she_more_earnings "She earns more*Share of earnings(B)"
	base_ea_f_sh_last6 "Share of earnings (B)" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
	base_K1 "Any formal wage job (ever)"
	base_age "Age"
	base_beatout "Justified: goes out"
	base_beatch "Justified: neglects ch"
	base_beatsex "Justified: refuses sex"
	base_beatarg "Justified: argues"	
	base_beatburn "Justified: burns food" 
	bviol3 "Abuse last 3 months"
	base_Muslim "Muslim"
	base_Protestant "Protestant"
	base_Medium_edu "Medium education"
	base_High_edu "High education"
	base_fbm "Father beat mother"
		)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr

			local varlist ///
base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn bviol3 base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///
 
cd "$results"
#delimit;
	noisily esttab *_cv_a cv_b using "cont_viol_nov18.tex", 
	style(tex) stats(N r2, labels("No. of observations" "R-squared")  fmt(0 2)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	she_more "She earns more than him"
	she_more_earnings "She earns more*Share of earnings"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings last 6 months" 
	ea_sh_last6 "Share of earnings" 
	ea_f_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_she_more "She earns more than him (B)"
	base_she_more_earnings "She earns more*Share of earnings(B)"
	base_ea_f_sh_last6 "Share of earnings (B)" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
	base_K1 "Any formal wage job (ever)"
	base_age "Age"
	base_beatout "Justified: goes out"
	base_beatch "Justified: neglects ch"
	base_beatsex "Justified: refuses sex"
	base_beatarg "Justified: argues"	
	base_beatburn "Justified: burns food" 
	bviol3 "Abuse last 3 months"
	base_Muslim "Muslim"
	base_Protestant "Protestant"
	base_Medium_edu "Medium education"
	base_High_edu "High education"
	base_fbm "Father beat mother"
		)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr

	

	
			local varlist ///
base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///
 
cd "$results"
#delimit;
	noisily esttab *_cvb_a cvb_b using "cont_viol_base_nov18.tex", 
	style(tex) stats(N r2, labels("No. of observations" "R-squared")  fmt(0 2)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	she_more "She earns more than him"
	she_more_earnings "She earns more*Share of earnings"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings last 6 months" 
	ea_sh_last6 "Share of earnings" 
	ea_f_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_she_more "She earns more than him (B)"
	base_she_more_earnings "She earns more*Share of earnings(B)"
	base_ea_f_sh_last6 "Share of earnings (B)" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
	base_K1 "Any formal wage job (ever)"
	base_age "Age"
	base_beatout "Justified: goes out"
	base_beatch "Justified: neglects ch"
	base_beatsex "Justified: refuses sex"
	base_beatarg "Justified: argues"	
	base_beatburn "Justified: burns food" 
	bviol3 "Abuse last 3 months"
	base_Muslim "Muslim"
	base_Protestant "Protestant"
	base_Medium_edu "Medium education"
	base_High_edu "High education"
	base_fbm "Father beat mother"
		)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
foreach var of varlist bviol3 base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
 base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///
///
{
reg physical_violence_3m `var' i.block, cl(N_Id) 
eststo `var'_cvfu_f_a
}
reg  physical_violence_3m bviol3 base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
eststo cv_fu_f_b


test bviol3+base_K1+base_age+base_beatout+base_beatch+base_beatsex+base_beatarg+ ///
base_beatburn+base_Muslim+base_Protestant+base_Medium_edu+base_High_edu+base_fbm==0
/*


       F(  1,  1261) =    3.43
            Prob > F =    0.0641

*/


			local varlist ///
bviol3 base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///
 
cd "$results"
#delimit;
	noisily esttab *_cvfu_f_a cv_fu_f_b using "cont_viol_fu_full_nov18.tex", 
	style(tex) stats(N r2, labels("No. of observations" "R-squared")  fmt(0 2)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	she_more "She earns more than him"
	she_more_earnings "She earns more*Share of earnings"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings last 6 months" 
	ea_sh_last6 "Share of earnings" 
	ea_f_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	bviol3 "Abuse last 3 months (B)"
	base_she_more "She earns more than him (B)"
	base_she_more_earnings "She earns more*Share of earnings(B)"
	base_ea_f_sh_last6 "Share of earnings (B)" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
	base_K1 "Any formal wage job (ever)"
	base_age "Age"
	base_beatout "Justified: goes out"
	base_beatch "Justified: neglects ch"
	base_beatsex "Justified: refuses sex"
	base_beatarg "Justified: argues"	
	base_beatburn "Justified: burns food" 
	bviol3 "Abuse last 3 months"
	base_Muslim "Muslim"
	base_Protestant "Protestant"
	base_Medium_edu "Medium education"
	base_High_edu "High education"
	base_fbm "Father beat mother"
		)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr	
	

	