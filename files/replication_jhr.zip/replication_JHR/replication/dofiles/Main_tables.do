	
	* Change to your own directory 
global data = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\Data"
global results = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\results"
capture global 	do = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\dofiles"


use "$data\replication_data_first_fu.dta", clear

  
* Check attrition: uncorrelated with treatment
reg attrit orig_treatment i.block, cl(N_Id) 
 estadd local Controls "Block"
su attrit if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo attrit_a

* Only age is correlated with attrition, younger people less likely to continue
reg attrit  orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su attrit if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo attrit_b




local varlist /// 
orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///



cd "$results"
#delimit;
esttab attrit_a attrit_b using "Attrition.tex",
    style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Attrition" "Attrition")
		keep(`varlist') order(`varlist')
		varlabels(
	physical_violence "Physical"
	physical_violence_3m "Abuse last 3 months"
	less_severe_violence "Less severe"
	less_3m "Less severe last 3 months"
	severe_violence "Severe"
	severe_violence_3m "Severe last 3 months"
	sexual_violence "Sexual"
	sexual_violence_3m "Sexual last 3 months"
  emotional_violence "Emotional"
  emotional_violence_3m "Emotional last 3 months"
  number_control "Nr of control issues"
  number_control_3m  "Nr control last 3 months"	
  	h_fs_index "Empowerment index" 
	h_fs_nr	"Nr empowerment items"
	 equal_index "Equality index"  
 number_ga "Nr equality items"
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
	she_more "She earns more than him"
	base_K1 "Any formal wage job (ever)"
	base_age "Age"
	base_beatout "Justified: goes out"
	base_beatch "Justified: neglects ch"
	base_beatsex "Justified: refuses sex"
	base_beatarg "Justified: argues"	
	base_beatburn "Justified: burns food" 
	base_physical_violence_3m "Abuse last 3 months"
	base_Muslim "Muslim"
	base_Protestant "Protestant"
	base_Medium_edu "Medium education"
	base_High_edu "High education"
	base_fbm "Father beat mother"
	,
	)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
    replace;
#delimit cr

* Add interaction with T 

foreach var of varlist base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm ///
{
gen Ti_`var'=orig_treatment*`var'
}



reg attrit  orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm Ti_* i.block, cl(N_Id) 
 estadd local Controls "Full"
su attrit if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo attrit_c



local varlist /// 
Ti_* ///

cd "$results"
#delimit;
esttab attrit_c using "Attrition_interact.tex",
    style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Attrition" )
		keep(`varlist') order(`varlist')
		varlabels(
	physical_violence "Physical"
	physical_violence_3m "Abuse last 3 months"
	less_severe_violence "Less severe"
	less_3m "Less severe last 3 months"
	severe_violence "Severe"
	severe_violence_3m "Severe last 3 months"
	sexual_violence "Sexual"
	sexual_violence_3m "Sexual last 3 months"
  emotional_violence "Emotional"
  emotional_violence_3m "Emotional last 3 months"
  number_control "Nr of control issues"
  number_control_3m  "Nr control last 3 months"	
  	h_fs_index "Empowerment index" 
	h_fs_nr	"Nr empowerment items"
	 equal_index "Equality index"  
 number_ga "Nr equality items"
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
	she_more "She earns more than him"
	Ti_base_K1 "Any formal wage job (ever)"
	Ti_base_age "Age"
	Ti_base_beatout "Justified: goes out"
	Ti_base_beatch "Justified: neglects ch"
	Ti_base_beatsex "Justified: refuses sex"
	Ti_base_beatarg "Justified: argues"	
	Ti_base_beatburn "Justified: burns food" 
	Ti_base_physical_violence_3m "Abuse last 3 months"
	Ti_base_Muslim "Muslim"
	Ti_base_Protestant "Protestant"
	Ti_base_Medium_edu "Medium education"
	Ti_base_High_edu "High education"
	Ti_base_fbm "Father beat mother"
	,
	)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
    replace;
#delimit cr

drop Ti_*






set more off
foreach var of varlist formal_last6 fac_last6 ea_f_last6 ea_f_sh_last6 ea_last6 ///
ea_sh_last6 income_last6 income_share_last6 she_more ///
///
{
* First stage
reg `var' orig_treatment i.block, cl(N_Id) 
 estadd local Controls "Block"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_fs_a
reg `var' orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_fs_b
* OLS
reg physical_violence_3m `var'  i.block, cl(N_Id) 
 estadd local Controls "Block"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_ols_a
reg  physical_violence_3m `var' base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_ols_b
* OLS baseline
reg base_physical_violence_3m base_`var'  i.block, cl(N_Id) 
 estadd local Controls "Block"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_olsb_a
reg  base_physical_violence_3m base_`var' base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_olsb_b
* OLS baseline same sample
reg base_physical_violence_3m base_`var'  i.block if physical_violence_3m!=., cl(N_Id) 
 estadd local Controls "Block"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_olsssb_a
reg  base_physical_violence_3m base_`var' base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block if physical_violence_3m!=., cl(N_Id) 
 estadd local Controls "Full"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_olsssb_b
* IV
ivreg2 physical_violence_3m (`var'=orig_treatment)  i.block, cl(N_Id) 
 estadd local Controls "Block"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_iv_a
ivreg2 physical_violence_3m (`var'=orig_treatment) base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_iv_b
}

* Emo: 

set more off
foreach var of varlist formal_last6 fac_last6 ea_f_last6 ea_f_sh_last6 ea_last6 ///
ea_sh_last6 income_last6 income_share_last6 she_more ///
///
{
* First stage
* OLS
reg emotional_violence_3m `var'  i.block, cl(N_Id) 
 estadd local Controls "Block"
su emotional_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_ols_ae
reg  emotional_violence_3m `var' base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_emotional_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su emotional_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_ols_be
* OLS baseline
reg base_emotional_violence_3m base_`var'  i.block, cl(N_Id) 
 estadd local Controls "Block"
su emotional_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_olsb_ae
reg  base_emotional_violence_3m base_`var' base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su emotional_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_olsb_be
* OLS baseline same sample
reg base_emotional_violence_3m base_`var'  i.block if emotional_violence_3m!=., cl(N_Id) 
 estadd local Controls "Block"
su emotional_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_sssb_ae
reg  base_emotional_violence_3m base_`var' base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block if emotional_violence_3m!=., cl(N_Id) 
 estadd local Controls "Full"
su emotional_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_sssb_be
* IV
ivreg2 emotional_violence_3m (`var'=orig_treatment)  i.block, cl(N_Id) 
 estadd local Controls "Block"
su emotional_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_iv_ae
ivreg2 emotional_violence_3m (`var'=orig_treatment) base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_emotional_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su emotional_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_iv_be
}




set more off
foreach var of varlist physical_violence_3m  less_3m severe_violence_3m sexual_violence_3m emotional_violence_3m number_control_3m ///
///
{
* Reduced form effects on different types of violence
reg `var' orig_treatment i.block, cl(N_Id) 
 estadd local Controls "Block"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_itt_a
reg `var' orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_itt_b
}
	
					local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab physical_violence_3m_itt_a physical_violence_3m_itt_b  emotional_violence_3m_itt_a emotional_violence_3m_itt_b 
	  using "ITT_nov18.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Physical" "Physical" "Emotional" "Emotional")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{12}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
	
	
				local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab less_3m_itt_a less_3m_itt_b 
		severe_violence_3m_itt_a severe_violence_3m_itt_b sexual_violence_3m_itt_a sexual_violence_3m_itt_b 
		 using "ITT_nov18_components.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Less severe" "Less severe" "Severe" "Severe" "Sexual" "Sexual")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{12}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr

	*_fs_b 
	/*
	formal_last6 fac_last6  ea_f_last6_fs_a ea_f_sh_last6_fs_a ea_last6_fs_a ///
ea_sh_last6_fs_a income_last6_fs_a income_share_last6_fs_a she_more_fs_a ///
*/
	********** First stage tables ***************
	
	* short
					local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab formal_last6_fs_a   ea_f_last6_fs_a ea_f_sh_last6_fs_a  ///
	   she_more_fs_a income_last6_fs_a
	using "FS_nc_nov18_short.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("\shortstack{Any\\wage job}" "\shortstack{Earnings from\\wage job}" "\shortstack{Share of\\wage earnings}"  "\shortstack{She earns\\more}"  "\shortstack{All source\\income}")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
	* Controls:
						local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab formal_last6_fs_b   ea_f_last6_fs_b ea_f_sh_last6_fs_b  ///
	   she_more_fs_b income_last6_fs_b
	using "FS_c_nov18_short.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("\shortstack{Any\\wage job}" "\shortstack{Earnings from\\wage job}" "\shortstack{Share of\\wage earnings}"  "\shortstack{She earns\\more}"  "\shortstack{All source\\income}")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
	
	
				local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab formal_last6_fs_a fac_last6_fs_a  ea_f_last6_fs_a ea_f_sh_last6_fs_a ea_last6_fs_a ///
	ea_sh_last6_fs_a income_last6_fs_a income_share_last6_fs_a she_more_fs_a 
	using "FS_nc_nov18.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Any wage job" "Any factory job" "Earnings from wage job" "Share" "Earnings" "Share" "Income" "Share" "She earns more")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	* Controls:
	
					local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab formal_last6_fs_b fac_last6_fs_b  ea_f_last6_fs_b ea_f_sh_last6_fs_b ea_last6_fs_b ///
	ea_sh_last6_fs_b income_last6_fs_b income_share_last6_fs_b she_more_fs_b 
	using "FS_c_nov18.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Any wage job" "Any factory job" "Earnings from wage job" "Share" "Earnings" "Share" "Income" "Share" "She earns more")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
	************ IV table **************
		********** Second stage tables ***************
				local varlist ///
ea_f_last6 ea_f_sh_last6 ea_last6 ///
	ea_sh_last6 income_last6 income_share_last6 she_more  ///
 
cd "$results"
#delimit;
	noisily esttab   ea_f_last6_iv_a ea_f_sh_last6_iv_a ea_last6_iv_a ///
	ea_sh_last6_iv_a income_last6_iv_a income_share_last6_iv_a she_more_iv_a 
	using "IV_nc_nov18.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Physical" "Physical" "Physical" "Physical" "Physical" "Physical" "Physical")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	she_more "She earns more than him"
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
	*** Emotional
					local varlist ///
ea_f_last6 ea_f_sh_last6 ea_last6 ///
	ea_sh_last6 income_last6 income_share_last6 she_more  ///
 
cd "$results"
#delimit;
	noisily esttab   ea_f_last6_iv_ae ea_f_sh_last6_iv_ae ea_last6_iv_ae ///
	ea_sh_last6_iv_ae income_last6_iv_ae income_share_last6_iv_ae she_more_iv_ae 
	using "IV_nc_nov18e.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Emotional" "Emotional" "Emotional" "Emotional" "Emotional" "Emotional" "Emotional")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	she_more "She earns more than him"
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
	

	* Result tables for different variables
	
	* formal_last6 with same sample: formal_last6_ss
	
******** Present in main text: no first stage repitition and include emo:
* Revision: split up correlation and iv in 2 panels: 

		local varlist ///
 base_formal_last6   ///
 
cd "$results"
#delimit;
	noisily esttab formal_last6_olsssb_a formal_last6_olsssb_b formal_last6_sssb_ae formal_last6_sssb_be   using "formal_last6_jan22a.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("\shortstack{Physical\\OLS}"  "\shortstack{Physical\\OLS}" "\shortstack{Emotional\\OLS}" "\shortstack{Emotional\\OLS}" )
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
			she_more "She earns more than him"
	base_she_more "She earns more than him (B)"
		)
	prehead("\begin{tabular}{l*{8}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
		local varlist ///
 formal_last6   ///
 
cd "$results"
#delimit;
	noisily esttab formal_last6_iv_a formal_last6_iv_b formal_last6_iv_ae formal_last6_iv_be using "formal_last6_jan22b.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("\shortstack{Physical\\IV}"  "\shortstack{Physical\\IV}" "\shortstack{Emotional\\IV}" "\shortstack{Emotional\\IV}" )
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
			she_more "She earns more than him"
	base_she_more "She earns more than him (B)"
		)
	prehead("\begin{tabular}{l*{8}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr	
	
	
	
			local varlist ///
 base_formal_last6 formal_last6  orig_treatment ///
 
cd "$results"
#delimit;
	noisily esttab formal_last6_olsssb_a formal_last6_olsssb_b formal_last6_fs_a formal_last6_fs_b formal_last6_iv_a formal_last6_iv_b  using "formal_last6_nov18_ss.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("OLS" "OLS" "First stage" "First stage" "IV" "IV")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
			she_more "She earns more than him"
	base_she_more "She earns more than him (B)"
		)
	prehead("\begin{tabular}{l*{8}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr

	
	
	* any_wage_job_last6
	foreach var of varlist formal_last6 fac_last6  ea_f_last6 ea_f_sh_last6 ea_last6 ///
ea_sh_last6 income_last6 income_share_last6 she_more ///
///
{
			local varlist ///
 base_`var' `var'  orig_treatment ///
 
cd "$results"
#delimit;
	noisily esttab `var'_olsb_a `var'_olsb_b `var'_fs_a `var'_fs_b `var'_iv_a `var'_iv_b  using "`var'_nov18.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("OLS" "OLS" "First stage" "First stage" "IV" "IV")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
			she_more "She earns more than him"
	base_she_more "She earns more than him (B)"
		)
	prehead("\begin{tabular}{l*{8}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
}



* Machine learning to select controls:
pdslasso physical_violence_3m orig_treatment (base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block) , pnotpen(i.block) cl(N_Id) 
 estadd local Controls "Optimal"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo optimal_itt
* Cool, choses only baseline viol as control
* But not lower p-value and very similar s.e
pdslasso emotional_violence_3m orig_treatment (base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_emotional_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block) , pnotpen(i.block) cl(N_Id) 
 estadd local Controls "Optimal"
su emotional_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo optimal_itt_emo
pdslasso number_control_3m orig_treatment (base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_number_control_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block) , pnotpen(i.block) cl(N_Id) 
 estadd local Controls "Optimal"
su number_control_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo optimal_itt_contr

					local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab optimal_itt optimal_itt_emo  using "ITT_opt_nov18.tex", 
	style(tex) stats(mean_depvar_c N Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Physical" "Emotional" "Controlling")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{12}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
	
*********** Mediators same sample ******************
* fix by hand:
su  base_h_fs_index
gen b_ind=1-base_h_fs_index


set more off	
reg base_physical_violence_3m base_equal_index  i.block  if equal_index!=. ,  cl(N_Id) 
 estadd local Controls "Block"
su base_physical_violence_3m if e(sample)==1
estadd scalar mean_depvar_c = r(mean)
eststo base_med_a
reg base_physical_violence_3m b_ind  i.block  if h_fs_index!=. ,  cl(N_Id) 
 estadd local Controls "Block"
su base_physical_violence_3m if e(sample)==1
estadd scalar mean_depvar_c = r(mean)
eststo base_med_b
reg base_physical_violence_3m base_beat  i.block  if beat!=. ,  cl(N_Id) 	
 estadd local Controls "Block"
su base_physical_violence_3m if e(sample)==1
estadd scalar mean_depvar_c = r(mean)
eststo base_med_c
reg base_physical_violence_3m base_number_control  i.block  if number_control!=. ,  cl(N_Id) 
 estadd local Controls "Block"
su base_physical_violence_3m if e(sample)==1
estadd scalar mean_depvar_c = r(mean)
eststo base_med_d

	 
set more off
foreach var of varlist equal_index  h_fs_index beat number_control ///
///
{
* Itt
reg `var' orig_treatment i.block, cl(N_Id) 
 estadd local Controls "Block"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_itt_med_a
reg `var' orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_itt_med_b
}






* Same sample


local varlist /// 
base_equal_index  b_ind base_beat base_number_control ///



cd "$results"
#delimit;
esttab base_med_a base_med_b base_med_c base_med_d using "ols_med.tex",
    style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in sample" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Physical" "Physical" "Physical" "Physical")
		keep(`varlist') order(`varlist')
		varlabels(
base_equal_index "Equality index (B)"
b_ind "Decisionmaking index (B)"
base_beat  "Acceptance index (B)"
  base_number_control  "Nr of control issues (B)"
		,
	)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
    replace;
#delimit cr



set more off	
reg base_emotional_violence_3m base_equal_index  i.block  if equal_index!=. ,  cl(N_Id) 
 estadd local Controls "Block"
su base_emotional_violence_3m if e(sample)==1
estadd scalar mean_depvar_c = r(mean)
eststo base_med_a
reg base_emotional_violence_3m b_ind  i.block  if h_fs_index!=. ,  cl(N_Id) 
 estadd local Controls "Block"
su base_emotional_violence_3m if e(sample)==1
estadd scalar mean_depvar_c = r(mean)
eststo base_med_b
reg base_emotional_violence_3m base_beat  i.block  if beat!=. ,  cl(N_Id) 	
 estadd local Controls "Block"
su base_emotional_violence_3m if e(sample)==1
estadd scalar mean_depvar_c = r(mean)
eststo base_med_c
reg base_emotional_violence_3m base_number_control  i.block  if number_control!=. ,  cl(N_Id) 
 estadd local Controls "Block"
su base_emotional_violence_3m if e(sample)==1
estadd scalar mean_depvar_c = r(mean)
eststo base_med_d

local varlist /// 
base_equal_index  b_ind base_beat base_number_control ///



cd "$results"
#delimit;
esttab base_med_a base_med_b base_med_c base_med_d using "ols_med_emo.tex",
    style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in sample" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Emotional" "Emotional" "Emotional" "Emotional")
		keep(`varlist') order(`varlist')
		varlabels(
base_equal_index "Equality index (B)"
b_ind "Decisionmaking index (B)"
base_beat  "Acceptance index (B)"
  base_number_control  "Nr of control issues (B)"
		,
	)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
    replace;
#delimit cr



local varlist /// 
orig_treatment ///

cd "$results"
#delimit;
esttab equal_index_itt_med_a  h_fs_index_itt_med_a beat_itt_med_a number_control_itt_med_a using "ITT_med_a.tex",
    style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in sample" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Equality index" "Decisionmaking index" "Acceptance index" "Nr controlling issues")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
base_equal_index "Equality index (B)"
base_h_fs_index "Empowerment index (B)"
base_beat  "Acceptance index (B)"
  base_number_control  "Nr of control issues (B)"
		,
	)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
    replace;
#delimit cr

local varlist /// 
orig_treatment ///

cd "$results"
#delimit;
esttab equal_index_itt_med_b  h_fs_index_itt_med_b beat_itt_med_b number_control_itt_med_b using "ITT_med_b.tex",
    style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in sample" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Equality index" "Decisionmaking index" "Acceptance index" "Nr controlling issues")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
base_equal_index "Equality index (B)"
base_h_fs_index "Empowerment index (B)"
base_beat  "Acceptance index (B)"
  base_number_control  "Nr of control issues (B)"
		,
	)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
    replace;
#delimit cr

	
	
	



	
* What component of emotional violence



set more off
foreach var of varlist husband_humiliated_3m husband_threatened_3m husband_insult_3m ///
{
* Itt
reg `var' orig_treatment i.block, cl(N_Id) 
 estadd local Controls "Block"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_itt_a
reg `var' orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_itt_b
}



				local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab husband_humiliated_3m_itt_a husband_threatened_3m_itt_a husband_insult_3m_itt_a  
	using "ITT_emoviol_nov18.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Humiliated" "Threatened" "Insult")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{14}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr

	
	* Follow up data 


estimates drop _all

use "$data\replication_data_sec_fu.dta", clear


set more off
foreach var of varlist any_wage_job_last6 fac_last6 ea_f_last6 ea_f_sh_last6 ea_last6 ///
ea_sh_last6 income_last6 income_share_last6 she_more ///
///
{
* First stage
reg `var' orig_treatment i.block, cl(N_Id) 
 estadd local Controls "Block"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_fs_a
reg `var' orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_fs_b
* OLS
reg physical_violence_3m `var'  i.block, cl(N_Id) 
 estadd local Controls "Block"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_ols_a
reg  physical_violence_3m `var' base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_ols_b
* OLS baseline
reg base_physical_violence_3m base_`var'  i.block, cl(N_Id) 
 estadd local Controls "Block"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_olsb_a
reg  base_physical_violence_3m base_`var' base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_olsb_b
* IV
ivreg2 physical_violence_3m (`var'=orig_treatment)  i.block, cl(N_Id) 
 estadd local Controls "Block"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_iv_a
ivreg2 physical_violence_3m (`var'=orig_treatment) base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_iv_b
}

set more off
foreach var of varlist physical_violence_3m  less_3m severe_violence_3m sexual_violence_3m emotional_violence_3m number_control_3m ///
///
{
* Reduced form effects on different types of violence
reg `var' orig_treatment i.block, cl(N_Id) 
 estadd local Controls "Block"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_itt_a
reg `var' orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_itt_b
}
	
					local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab physical_violence_3m_itt_a physical_violence_3m_itt_b  emotional_violence_3m_itt_a emotional_violence_3m_itt_b 
	  using "ITT_nov18_2nd.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Physical" "Physical" "Emotional" "Emotional")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{12}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
				local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab physical_violence_3m_itt_a physical_violence_3m_itt_b less_3m_itt_a less_3m_itt_b 
		severe_violence_3m_itt_a severe_violence_3m_itt_b sexual_violence_3m_itt_a sexual_violence_3m_itt_b 
		emotional_violence_3m_itt_a emotional_violence_3m_itt_b number_control_3m_itt_a number_control_3m_itt_b using "ITT_nov18_2nd_det.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Physical" "Physical" "Less severe" "Less severe" "Severe" "Severe" "Sexual" "Sexual" "Emotional" "Emotional" "Controlling" "Controlling")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	any_wage_job_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_any_wage_job_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{12}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr

	*_fs_b 
	/*
	any_wage_job_last6 fac_last6  ea_f_last6_fs_a ea_f_sh_last6_fs_a ea_last6_fs_a ///
ea_sh_last6_fs_a income_last6_fs_a income_share_last6_fs_a she_more_fs_a ///
*/
	********** First stage table ***************
				local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab any_wage_job_last6_fs_a fac_last6_fs_a  ea_f_last6_fs_a ea_f_sh_last6_fs_a ea_last6_fs_a ///
	ea_sh_last6_fs_a income_last6_fs_a income_share_last6_fs_a she_more_fs_a 
	using "FS_nc_nov18_2nd.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Any wage job" "Any factory job" "Earnings from wage job" "Share" "Earnings" "Share" "Income" "Share" "She earns more")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	any_wage_job_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_any_wage_job_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
	* Revision short version: 
						local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab any_wage_job_last6_fs_a   ea_f_last6_fs_a ea_f_sh_last6_fs_a  ///
	   she_more_fs_a income_last6_fs_a
	using "FS_nc_nov18_short_2nd.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("\shortstack{Any\\wage job}" "\shortstack{Earnings from\\wage job}" "\shortstack{Share of\\wage earnings}"  "\shortstack{She earns\\more}"  "\shortstack{All source\\income}")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	

	* Controls:
	
	
							local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
		noisily esttab any_wage_job_last6_fs_b   ea_f_last6_fs_b ea_f_sh_last6_fs_b  ///
	   she_more_fs_b income_last6_fs_b
	using "FS_c_nov18_short_2nd.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("\shortstack{Any\\wage job}" "\shortstack{Earnings from\\wage job}" "\shortstack{Share of\\wage earnings}"  "\shortstack{She earns\\more}"  "\shortstack{All source\\income}")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
					local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab any_wage_job_last6_fs_b fac_last6_fs_b  ea_f_last6_fs_b ea_f_sh_last6_fs_b ea_last6_fs_b ///
	ea_sh_last6_fs_b income_last6_fs_b income_share_last6_fs_b she_more_fs_b 
	using "FS_c_nov18_2nd.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Any wage job" "Any factory job" "Earnings from wage job" "Share" "Earnings" "Share" "Income" "Share" "She earns more")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	any_wage_job_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_any_wage_job_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr


	
	
	estimates drop _all

	use "$data\replication_data_thi_fu.dta", clear
	
	
	

set more off
foreach var of varlist any_wage_job_last6 fac_last6 ea_f_last6 ea_f_sh_last6 ea_last6 ///
ea_sh_last6 income_last6 income_share_last6 she_more ///
///
{
* First stage
reg `var' orig_treatment i.block, cl(N_Id) 
 estadd local Controls "Block"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_fs_a
reg `var' orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_fs_b
* OLS
reg physical_violence_3m `var'  i.block, cl(N_Id) 
 estadd local Controls "Block"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_ols_a
reg  physical_violence_3m `var' base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_ols_b
* OLS baseline
reg base_physical_violence_3m base_`var'  i.block, cl(N_Id) 
 estadd local Controls "Block"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_olsb_a
reg  base_physical_violence_3m base_`var' base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_olsb_b
* IV
ivreg2 physical_violence_3m (`var'=orig_treatment)  i.block, cl(N_Id) 
 estadd local Controls "Block"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_iv_a
ivreg2 physical_violence_3m (`var'=orig_treatment) base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su physical_violence_3m if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_iv_b
}

set more off
foreach var of varlist physical_violence_3m  less_3m severe_violence_3m sexual_violence_3m emotional_violence_3m number_control_3m ///
///
{
* Reduced form effects on different types of violence
reg `var' orig_treatment i.block, cl(N_Id) 
 estadd local Controls "Block"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_itt_a
reg `var' orig_treatment base_K1 base_age base_beatout base_beatch base_beatsex base_beatarg ///
base_beatburn base_physical_violence_3m base_Muslim base_Protestant base_Medium_edu base_High_edu base_fbm i.block, cl(N_Id) 
 estadd local Controls "Full"
su `var' if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo `var'_itt_b
}
	
					local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab physical_violence_3m_itt_a physical_violence_3m_itt_b  emotional_violence_3m_itt_a emotional_violence_3m_itt_b 
	  using "ITT_nov18_3rd.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Physical" "Physical" "Emotional" "Emotional" )
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{12}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
				local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab physical_violence_3m_itt_a physical_violence_3m_itt_b less_3m_itt_a less_3m_itt_b 
		severe_violence_3m_itt_a severe_violence_3m_itt_b sexual_violence_3m_itt_a sexual_violence_3m_itt_b 
		emotional_violence_3m_itt_a emotional_violence_3m_itt_b number_control_3m_itt_a number_control_3m_itt_b using "ITT_nov18_3rd_det.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Physical" "Physical" "Less severe" "Less severe" "Severe" "Severe" "Sexual" "Sexual" "Emotional" "Emotional" "Controlling" "Controlling")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	any_wage_job_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_any_wage_job_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{12}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr

	
	
	*_fs_b 
	/*
	any_wage_job_last6 fac_last6  ea_f_last6_fs_a ea_f_sh_last6_fs_a ea_last6_fs_a ///
ea_sh_last6_fs_a income_last6_fs_a income_share_last6_fs_a she_more_fs_a ///
*/
	********** First stage table ***************
				local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab any_wage_job_last6_fs_a fac_last6_fs_a  ea_f_last6_fs_a ea_f_sh_last6_fs_a ea_last6_fs_a ///
	ea_sh_last6_fs_a income_last6_fs_a income_share_last6_fs_a she_more_fs_a 
	using "FS_nc_nov18_3rd.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Any wage job" "Any factory job" "Earnings from wage job" "Share" "Earnings" "Share" "Income" "Share" "She earns more")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	any_wage_job_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_any_wage_job_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	
	
	* Revision short version: 
						local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab any_wage_job_last6_fs_a   ea_f_last6_fs_a ea_f_sh_last6_fs_a  ///
	   she_more_fs_a income_last6_fs_a
	using "FS_nc_nov18_short_3rd.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("\shortstack{Any\\wage job}" "\shortstack{Earnings from\\wage job}" "\shortstack{Share of\\wage earnings}"  "\shortstack{She earns\\more}"  "\shortstack{All source\\income}")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
* controls 
						local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab any_wage_job_last6_fs_b   ea_f_last6_fs_b ea_f_sh_last6_fs_b  ///
	   she_more_fs_b income_last6_fs_b
	using "FS_c_nov18_short_3rd.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("\shortstack{Any\\wage job}" "\shortstack{Earnings from\\wage job}" "\shortstack{Share of\\wage earnings}"  "\shortstack{She earns\\more}"  "\shortstack{All source\\income}")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	formal_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_sh_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_formal_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	
	* Controls:
	
					local varlist ///
orig_treatment  ///
 
cd "$results"
#delimit;
	noisily esttab any_wage_job_last6_fs_b fac_last6_fs_b  ea_f_last6_fs_b ea_f_sh_last6_fs_b ea_last6_fs_b ///
	ea_sh_last6_fs_b income_last6_fs_b income_share_last6_fs_b she_more_fs_b 
	using "FS_c_nov18_3rd.tex", 
	style(tex) stats(mean_depvar_c N r2 Controls, labels("Mean dep. var in C group" "No. of observations" "R-squared" "Controls")  fmt(2 0 2 0)) 
	starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se 
mtitles("Any wage job" "Any factory job" "Earnings from wage job" "Share" "Earnings" "Share" "Income" "Share" "She earns more")
		keep(`varlist') order(`varlist')
		varlabels(
	orig_treatment "Treatment"
	any_wage_job_last6 "Any wage job last 6 months" 
	fac_last6 "Any factory job last 6 months" 
	any_wage_job_last6 "Any wage last 6 months" 
	ea_f_last6 "Earnings from wage job last 6 months" 
	ea_f_last6 "Share of earnings from wage job" 
	ea_last6 "Earnings job last 6 months" 
	ea_sh_last6 "Share of earnings" 
	income_last6 "Income last 6 months" 
	income_share_last6 "Share of income" 
	base_any_wage_job_last6 "Any wage job last 6 months (B)" 
	base_fac_last6 "Any factory job last 6 months (B)" 
	base_any_wage_job_last6 "Any wage last 6 months (B)" 
	base_ea_f_last6 "Earnings from wage job last 6 months (B)" 
	base_ea_f_last6 "Share of earnings from wage job (B)" 
	base_ea_last6 "Earnings job last 6 months (B)" 
	base_ea_sh_last6 "Share of earnings (B)" 
	base_income_last6 "Income last 6 months (B)" 
	base_income_share_last6 "Share of income (B)"
		)
	prehead("\begin{tabular}{l*{10}{l}}" "\hline") posthead(\hline)
	postfoot("\hline" "\end{tabular}")
	replace;
	#delimit cr
	