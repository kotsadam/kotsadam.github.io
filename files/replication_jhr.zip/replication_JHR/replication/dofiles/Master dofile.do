
* Master dofile
* Change to your own directory 
global data = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\Data"
global results = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\results"
capture global 	do = "C:\Users\andrkot\Dropbox (Frischsenteret)\GBV_application\Data\replication_JHR\replication\dofiles"


* Main result tables
do "$do\Baseline_descriptives" // Creates descriptive tables, and tests for balance. Tables 1 and 2.
estimates drop _all
clear
do "$do\Main_tables" // Runs regressions for Tables 3-7 
estimates drop _all
clear
do "$do\List_experiment" // Runs regressions for Table 8 and Figure 2.
