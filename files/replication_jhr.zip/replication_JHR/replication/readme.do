
The replication material contains do-files and datasets. The datasets are anonymized and coded. 

All tables and figures of the published paper "Jobs and Intimate Partner Violence - Evidence from a Field Experiment in Ethiopia" 

If you just want to reproduce the results, run the file "Master dofile.do".
The codes for creating the variables are shown in the dofile "Coding of variables in non-anonymized data".
If you want to try other codings, the original variables are in the dataset.
It is the same coding for baseline variables, they start with "base_..."

All main tables in the paper are reproduced in these files. Here is a description of where a particular table is found:

Table 1 has the name "desk_all_nov18" and is created in the dofile "Baseline_descriptives" 
Table 2 is based on "cont_viol_fu_full_nov18" and "randc_nov18", and is created in the dofile "Baseline_descriptives" 

Table 3 is based on "FS_nc_nov18_short", "FS_nc_nov18_short_2ndb", and "FS_nc_nov18_short_3rdc" and is created in the dofile "Main_tables"
Table 4 is based on "ITT_nov18", "ITT_nov18_2nd", and "ITT_nov18_3rd" and is created in the dofile "Main_tables" 
Table 5 is based on "formal_last6_jan22a" and "formal_last6_jan22b" and is created in the dofile "Main_tables" 
Table 6 is based on "ols_med" and "ols_med_emo" and is created in the dofile "Main_tables" 

Table 8 has the name "List_nov18" and is created in the dofile "List_experiment" 


Figure 2 is based on "list_groups" and is created in the dofile "List_experiment" 




