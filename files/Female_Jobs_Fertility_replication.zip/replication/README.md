# Replication package: Female Jobs and Fertility

Replication files for *Female Jobs and Fertility: Long-term Experimental Evidence
from Ethiopian Factories*.

Prepared by Andreas Kotsadam (andreas.kotsadam@gmail.com).
Version: October 2026. Download: https://kotsadam.github.io/files/Female_Jobs_Fertility_replication.zip

## Overview

Four Stata do-files reproduce the tables, figures and in-text numbers of the
paper from three de-identified datasets. Each script runs exhibit by exhibit,
opening the relevant dataset and writing each table (`.tex`) and figure
(`.pdf`/`.png`) to `output/`.

- `do/replication_main.do`: main-text tables and figures (`output/main/`)
- `do/replication_appendix.do`: appendix tables and figures (`output/appendix/`)
- `do/replication_text.do`: numbers quoted in the text that appear in no table
  or figure, printed to `output/text/replication_text_log.txt` on lines that
  start with `TEXT |`
- `do/replication_BD2018.do`: appendix re-analysis of Blattman & Dercon (2018)
  (requires their public replication data; see below)

## Software

Stata 17 or later (developed on StataNow 19). The do-files install or update the
required user-written packages (`estout`, `pdslasso`, `lassopack`, `ivreg2`,
`ranktest`, `cibar`, `blindschemes`) from SSC on every run. Restart Stata after
the first run so that freshly installed packages are loaded. The machine-learning
heterogeneity test (`do/ml_hetero.R`) needs R 4.x with the CRAN packages `grf`,
`GenericML`, `mlr3learners`, `glmnet` and `ranger`.

The paper's numbers were generated with pdslasso 1.3 (lassopack 1.4.x) and
ivreg2 4.1.x, and verified identical under the SSC versions current as of
October 2026 (lassopack 1.4.3, ivreg2 4.1.12). All estimation is deterministic
and no seeds are involved, except two seeded procedures that reproduce exactly:
the randomization inference in `replication_text.do` (block C; it also resets
Stata's sort tie-breaking seed with `set sortseed 1001`, the value at Stata
startup) and the causal forest / Generic ML in `ml_hetero.R` (verified with
grf 2.6.1 and GenericML 0.2.3). If your standard errors differ
from the paper's by a small uniform factor (~0.5%) with identical point
estimates, your `lassopack` or `ivreg2` installation is outdated: update the
packages and restart Stata before suspecting the data.

Approximate run times on a 2024 laptop: `replication_main.do` 2 minutes,
`replication_appendix.do` 5 minutes, `replication_text.do` 12 minutes (of which
the randomization inference takes 9), `ml_hetero.R` 15 minutes.

## Contents

```
replication/
  data/            de-identified datasets (and DHS/ park coordinates)
  do/              replication_main.do, replication_appendix.do,
                   replication_text.do, replication_BD2018.do, ml_hetero.R
  build_release/   script documenting how the datasets were de-identified
  output/          created on first run (main/, appendix/, text/)
  README.md
```

## Data

The datasets in `data/` are de-identified extracts of the study's analysis files:

- `FU_slim.dta`: Wave-7 endline cross-section (1,463 randomized women; 1,130
  interviewed at endline)
- `panel_slim.dta`: person-by-wave panel
- `cumulative_slim.dta`: person-by-wave income and savings

The respondent identifier is replaced by an anonymous `id_anon`. Exact interview
dates, birth timing in days, factory names, wages and locations, and other direct
identifiers are removed; the few variables derived from those inputs (e.g., the
survival-analysis durations) are pre-computed. `FU_slim.dta` keeps the
industrial-park region (five categories), which is coarser than the
randomization blocks. Specifications that cluster at the individual level use
`id_anon`. The de-identification is documented in
`build_release/build_release.do`, which the authors run on the raw data; it is
included for transparency and cannot be run without the raw data.

### Third-party data (DHS)

Three exhibits use the Ethiopia Demographic and Health Surveys (EDHS):

- Table 5 (surrogate index): 2024 EDHS Individual Recode.
- Appendix Table A.1 (DHS-2016 near-park summary statistics) and Appendix
  Figure A.1, panels a-c: 2016 EDHS Individual Recode and GPS.

DHS data cannot be redistributed under the DHS Program's terms of use. Replicators
must register (free of charge) at https://dhsprogram.com/data/ and download the
files themselves. The blocks skip with a message when the files are absent:

- **Table 5:** place the 2024 Individual Recode at
  `data/DHS/2024/ETIR8ADT/ETIR8AFL.dta`.
- **DHS-2016 table and figure:** place the 2016 Individual Recode at
  `data/DHS/Ethiopia_women_2016.DTA` and export the 2016 GPS clusters to
  `data/DHS/etge7_clusters.csv` (columns `DHSCLUST`, `LATNUM`, `LONGNUM`).

The five industrial-park locations used to define the near-park sample are
provided in `data/DHS/industrial_park_coordinates.csv`.

### Third-party data (Blattman & Dercon 2018)

The appendix table "Heterogeneity in employment effects by baseline marital
status" re-analyses data from Blattman, C. and S. Dercon (2018), "The Impacts
of Industrial and Entrepreneurial Work on Income and Health: Experimental
Evidence from Ethiopia", *AEJ: Applied Economics* 10(3). Their data are not
redistributed here. Download their replication archive from the AEA's
replication repository (openICPSR), then set `global BDDATA` to the archive
root (the folder containing `data\ILEanalysis.dta`) and `global bd = 1` at the
top of `do/replication_BD2018.do`, and run it. The block is skipped by default.

## Instructions

1. In each do-file, set the single path line near the top:
   `global ROOT "<absolute path to this replication folder>"`
2. Run:
   ```
   do "<ROOT>/do/replication_main.do"
   do "<ROOT>/do/replication_appendix.do"
   do "<ROOT>/do/replication_text.do"
   ```
   or from a shell:
   ```
   "<stata>" /e do "<ROOT>\do\replication_main.do"
   "<stata>" /e do "<ROOT>\do\replication_appendix.do"
   "<stata>" /e do "<ROOT>\do\replication_text.do"
   ```

Treatment effects use the paper's main specification, post-double-selection LASSO:
`pdslasso outcome orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust`
(panel specifications add `i.wave` and cluster on `id_anon`).

## Exhibit map

Paper label (in `Paper.tex`) → output file → producing do-file and block.
Blocks are marked in each do-file with a header comment.

**Main text** (`replication_main.do`)

| Exhibit | Output | Block |
|---|---|---|
| Table 1, baseline characteristics (`tab:fert_des`) | `fert_des_new_fert_ed_edt.tex` | TABLE 1 |
| Table 2, first stage by wave (`tab:first_stage_lasso`) | `first_lasso_pres.tex` | TABLE 2 |
| Table 3, ITT on fertility (`tab:main_pres`) | `main_pres.tex` | TABLE 3 |
| Table 4, IV with Wave-2 employment (`tab:IV_any_child`) | `IV_w2.tex` | TABLE 4 |
| Figure, Kaplan-Meier, all women / non-mothers (`fig:KM_months_all`) | `KM_combined.pdf` | FIGURE KM |
| Table 5, surrogate extrapolation (`tab:surrogate`) | `surrogate_paper.tex` | TABLE 5 (EDHS 2024) |
| Table 6, cumulative income and savings | `hhinc6_savings_cum_bal.tex` | TABLE 6 |
| Table 7, heterogeneity by income | `hhinc_hetero_any_nr.tex` | TABLE 7 |
| Figure, Kaplan-Meier by firm wage | `KM_wage_combined.pdf` | FIGURE KM by wage |
| Table 8, other mechanisms (`tab:mechanisms`) | `mechanisms_combined.tex` | TABLE 8 |

**Appendix** (`replication_appendix.do` unless noted)

| Exhibit | Output | Block |
|---|---|---|
| Distribution of months worked | `hist_months_tc_binning.pdf` | E |
| ITT by region (`fig:park_ordered`) | `bread_effects_by_park_ordered.pdf` | J |
| Kaplan-Meier, can/cannot combine work and childcare | `KM_workchild_combined.pdf` | E |
| Working with a newborn; combining work and household duties | `work_child.pdf`, `work_hhdut.pdf` | E |
| Figure A.1 panels a-c, EDHS 2016 near parks | `figA1_panel_*.png` | F (EDHS 2016) |
| Table A.1, RCT vs EDHS 2016 near parks | `DHS_compare_stars_2016.tex` | F (EDHS 2016) |
| Blattman & Dercon (2018) by marital status (`tab:BD2018_mw_nmw`) | `table1_hte_by_married_women.tex` | `replication_BD2018.do` |
| First stage by baseline motherhood (`tab:first_lasso_nm_pres`) | `first_lasso_by_motherhood_pres.tex` | B |
| Time use, Wave 2 (`tab:timeuse_w2`) | `check_TU_w2_2.tex` | G5 |
| ITT, alternative specifications (`tab:main_fert_w7`) | `main_fert_w7.tex`, `main_fert_w7_timesample.tex` | A |
| Births by wave | `nr_births_w.tex`, `any_birth_w_nrsample.tex` | A |
| IV with cumulative employment (`tab:IV_any_child_alt`) | `IV_combined.tex` | I |
| Fertility by years since baseline | `any_child_nr_births_y.tex`, `any_child_y_nm.tex` | A |
| First stage by income quintile (`tab:first_stage_by_incq`) | `check_firststage_hhinc_q.tex` | G4 |
| Heterogeneity by desired fertility (`tab:hetero_desired_nonlinear`) | `check_fertprefs_young.tex` | G1/G2 |
| Contraceptive use, Waves 2-7 (`tab:contraception_use_w2w7`) | `contraception_use_w2w7.tex` | E |
| Aspirations for children | `Aspirations_combined.tex` | E |
| Attrition | `Attrition_w7.tex`, `Attrition_w7_pres_PR.tex` | A |
| Pre-registered outcome: partner wants more children (`tab:partner_w_more`) | `partner_w_more.tex` | A |
| ITT by tracking sample, IPW | `Itt_samples_combined.tex` | E |
| Factory characteristics by wage; balance | `fact_des_mw_fac_hi.tex`, `balance_samples_higlow_edt.tex` | H |
| ITT with high-wage interaction | `main_pres_hwage.tex` | A |
| First stage by firm wage | `first_lasso_pres_hw.tex`, `first_lasso_pres_lw.tex` | B |
| Savings and income by firm wage | `check_savings_inc_mw_split.tex` | G3 |
| Kaplan-Meier, high- and low-wage firms | `KM_months_all_mw_fac_hi.pdf`, `KM_months_all_mw_fac_lo.pdf` | E |
| Within-region wage split | `check_mw_within_region.tex` | G1/G2 |

The appendix do-file also writes some tables that the current draft does not
input (e.g. the separate income and savings panels); they are kept for
reference.

**Numbers in the text** (`replication_text.do`, plus `ml_hetero.R`)

| Section of the paper | What | Block |
|---|---|---|
| Introduction, Sec. 3 | sample sizes, attrition, respondents by wave, survey timing | A1, A2 |
| Introduction, Sec. 1, Sec. 4.3 | ages | A3 |
| Sec. 2, Sec. 6 | women's share of workers; Wave-2 pay and hours; pay relative to household income | A4 |
| Sec. 2, Sec. 5.2 | combining work and childcare | A5 |
| Sec. 5.1 | savings accounts and borrowing | A6 |
| Sec. 5.3 | baseline gender attitudes; childless women's partners | A7, A8 |
| Notes to `tab:hetero_desired_nonlinear` | desired-fertility bins | A9 |
| Figure KM notes, Sec. 4.2 | log-rank tests; time-varying Cox hazard ratios | B1 |
| Figure KM work/childcare notes | log-rank tests | B2 |
| Sec. 4.2 footnote | dropping one large firm at a time | B3 |
| Sec. 5.3 | contraceptive use, baseline non-mothers | B4 |
| Sec. 4.2 | fertility preferences by baseline motherhood | B5 |
| Sec. 5.2 | quitting before the first birth | B6 |
| Sec. 5.3 | cost of a child | B7 |
| Sec. 4.3 | kappa (EDHS 2024) | B8 |
| Sec. 5.2 footnote | ML heterogeneity tests: B9 exports `output/text/ml_hetero.csv`; then run `do/ml_hetero.R` (R with `grf` and `GenericML`; set `root` at its top) | B9 + `ml_hetero.R` |
| Sec. 4.2 footnote; Table 3 notes | randomization inference, 1,000 permutations | C |
| Sec. 4.1 footnote | Blattman & Dercon sample and gender interaction | `replication_BD2018.do` |

## Not reproduced by this package

- Figure of the industrial parks (map; ArcGIS spatial join).
- Conceptual model figures (`dynamicIE.pdf`, `dynamicSE.pdf`, `sequential.pdf`):
  illustrations of the theoretical model, not data.
- Interviews-over-waves figures (`interviews_over_waves_7w.pdf`,
  `interviews_over_waves_bars.pdf`): they need exact interview dates, which are
  removed for privacy. The respondent counts by wave are reproduced in
  `replication_text.do`.
- Fostering figure (`fostering_all.png`): computed from the DHS of 73 countries
  for Zipfel (2026); see that paper's replication package.
- Appendix Table F.1 (`tab_income_fertility_comparison`): a literature summary;
  every number is taken from the cited papers.
- Numbers in the text taken from external sources (UN population projections,
  EDHS fertility rates, the child-penalty atlas, the cited studies).
