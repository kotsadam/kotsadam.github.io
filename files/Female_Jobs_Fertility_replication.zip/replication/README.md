# Replication package: Female Jobs and Fertility

Replication files for *Female Jobs and Fertility: Long-term Experimental Evidence
from Ethiopian Factories*.

Prepared by Andreas Kotsadam (andreas.kotsadam@gmail.com).

## Overview

Two Stata do-files reproduce the tables and figures in the paper from three
de-identified datasets. Each script runs exhibit by exhibit, opening the relevant
dataset and writing each table (`.tex`) and figure (`.pdf`) to `output/`.

- `do/replication_main.do` — main-text tables and figures
- `do/replication_appendix.do` — appendix tables and figures

## Software

Stata 17 or later (developed on StataNow 19). The do-files install the required
user-written packages (`estout`, `pdslasso`, `cibar`) from SSC automatically on
first run.

## Contents

```
replication/
  data/            de-identified datasets (and DHS/ park coordinates)
  do/              replication_main.do, replication_appendix.do
  build_release/   script documenting how the datasets were de-identified
  output/          created on first run (main/ and appendix/)
  README.md
```

## Data

The datasets in `data/` are de-identified extracts of the study's analysis files:

- `FU_slim.dta` — Wave-7 endline cross-section
- `panel_slim.dta` — person-by-wave panel
- `cumulative_slim.dta` — person-by-wave income and savings

The respondent identifier is replaced by an anonymous `id_anon`. Exact interview
dates, birth timing in days, factory names and locations, and other direct
identifiers are removed; the few variables derived from those inputs (e.g., the
survival-analysis durations) are pre-computed. Specifications that cluster at the
individual level use `id_anon`. The de-identification is documented in
`build_release/build_release.do`, which the authors run on the raw data.

### Third-party data (DHS)

Two exhibits use the Ethiopia Demographic and Health Surveys (EDHS):

- Table 5 (surrogate index) — 2024 EDHS Individual Recode.
- DHS-2016 near-park summary statistics — 2016 EDHS Individual Recode and GPS.

DHS data cannot be redistributed under the DHS Program's terms of use. Replicators
must register (free of charge) at https://dhsprogram.com/data/ and download the
files themselves. Both blocks are skipped by default and run automatically once
the files are in place:

- **Table 5:** place the 2024 Individual Recode at
  `data/DHS/2024/ETIR8ADT/ETIR8AFL.dta`.
- **DHS-2016 comparison:** place the 2016 Individual Recode at
  `data/DHS/Ethiopia_women_2016.DTA`, export the 2016 GPS clusters to
  `data/DHS/etge7_clusters.csv` (columns `DHSCLUST`, `LATNUM`, `LONGNUM`), and set
  `global dhs = 1` at the top of `replication_appendix.do`.

The five industrial-park locations used to define the near-park sample are
provided in `data/DHS/industrial_park_coordinates.csv`.

## Instructions

1. In each do-file, set the single path line near the top:
   `global ROOT "<absolute path to this replication folder>"`
2. Run:
   ```
   do "<ROOT>/do/replication_main.do"
   do "<ROOT>/do/replication_appendix.do"
   ```
   or from a shell:
   ```
   "<stata>" /e do "<ROOT>\do\replication_main.do"
   "<stata>" /e do "<ROOT>\do\replication_appendix.do"
   ```

Tables and figures are written to `output/main/` and `output/appendix/`.

Treatment effects use the paper's main specification, post-double-selection LASSO:
`pdslasso outcome orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust`
(panel specifications add `i.wave` and cluster on `id_anon`).
