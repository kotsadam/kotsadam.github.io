*==============================================================================
* replication_appendix.do
*   Self-contained, exhibit-by-exhibit replication of the APPENDIX exhibits of
*   "Female Jobs and Fertility" (current Overleaf draft, October 2026).
*
*   Each block opens the dataset it needs and runs minimal code for one exhibit,
*   writing a *.tex (or .pdf/.png) to $OUT for diffing against the committed
*   Jobs_and_Fertility_overleaf results files. "EXPECT"/"PRODUCER" comments give
*   the target and the original producing do-file for each exhibit.
*
*   RUN: set global ROOT below, then  do "<ROOT>\do\replication_appendix.do"
*   (see README.md). All estimation is deterministic; no seed is needed.
*
*   ------------------------------------------------------------------------
*   NOT REPRODUCIBLE FROM THE ANONYMIZED DATA (excluded from this script):
*     - the Industrial-Parks map (ArcGIS/GIS) and the conceptual model-illustration
*       figures (dynamicIE.pdf, dynamicSE.pdf, sequential.pdf)
*     - the interview-over-waves figures (interviews_over_waves_7w/_bars): need the
*       exact interview dates, which are dropped for privacy
*     - the fostering figure (fostering_all.png): computed from the DHS of 73
*       countries for Zipfel (2026); see that paper's replication package
*     - Table F.1 (tab_income_fertility_comparison): a literature summary; every
*       number in it is taken from the cited papers
*     - hetero_commute.tex: not in the current paper (its text and table float are
*       commented out), so it is not part of this package
*   ------------------------------------------------------------------------
*==============================================================================
clear all
set more off
set varabbrev off
set maxvar 20000
version 17

* Two-significant-digit formatter for the hand-written table fragments, keeping
* the leading zero (Stata's %g drops it: .19 instead of 0.19), with a floor of
* three decimals. The floor is a deliberate departure from esttab's b(a2): a2
* would print A.12's four estimates at mixed precision (0.19 / 0.17 / 0.11 /
* 0.027), whereas the floor shows them uniformly (0.187 / 0.172 / 0.110 /
* 0.027). Values below 0.01 still get as many decimals as they need, so E.2's
* Age and time-use rows are unaffected either way.
capture program drop sigfmt
program define sigfmt, rclass
    args x
    if missing(`x') | `x'==0 {
        return local s "0.000"
        exit
    }
    local d = 1 - floor(log10(abs(`x')))
    if `d' < 3 local d = 3
    if `d' > 8 local d = 8
    local t = strtrim(string(`x', "%20.`d'f"))
    return local s "`t'"
end

*--- switches -----------------------------------------------------------------
global fert_family = 1     // FU_6th_norest fertility tables
global firststage  = 1     // panel_long first-stage variants
global cumfamily   = 1     // cumulative_slim.dta income/savings/wage/factory/earnings
global hetero_nr   = 1     // add_hetero number-of-children heterogeneity
global checkq      = 1     // check_questions tables (within-region, fertprefs, splits)
global descr       = 1     // balance_samples, fact_des
* combined = contraception/aspirations/work-child KM/wage KM/histogram/bar charts
* (Section E) — portable, reads FU_slim, writes exhibit files to $OUT. dhs = DHS 2016
* comparison (needs a downloaded DHS file; OFF by default, see README).
global combined    = 1     // Section E: contracep/asp/work-child/wage-KM/hist/cb_*
global iv_alt      = 1     // Section I: A.6 IV with cumulative employment measures (IV_combined)
global region      = 1     // Section J: ITT by region figure (bread_effects_by_park_ordered)
global dhs         = 1     // DHS 2016 comparison table + Figure A.1 panels (DHS files in data\DHS per README)

*--- paths --------------------------------------------------------------------
* EDIT THIS ONE LINE to the absolute path of the replication/ folder.
global ROOT "C:\path\to\replication"
global CRE  "$ROOT\data"
global DHS  "$ROOT\data\DHS"     // put DHS files here if you download them (see README)
global OUT  "$ROOT\output\appendix"
capture mkdir "$ROOT\output"
capture mkdir "$OUT"

capture log close _all
log using "$OUT\replication_appendix_log.txt", text replace

*------------------------------------------------------------------------------
* Required user-written packages.
*
* Installed unconditionally with , replace -- deliberately NOT behind a
* "capture which" test.  "capture which" only detects a package that is
* MISSING, so it can never update one that is already installed but out of
* date.  An outdated lassopack / ivreg2 silently shifts the post-double-
* selection Lasso standard errors (this is what produced the ~0.5% SE
* differences against the committed tables, and an F-statistic of 63 instead
* of 64, in Tables 4-7).
*
*  >>> RESTART STATA AFTER THIS BLOCK HAS RUN FOR THE FIRST TIME. <<<
*  Stata keeps the ado-files it has already loaded in memory for the rest of
*  the session, so a newly installed or updated package is not actually used
*  until Stata is restarted.  So: run the do-file once to install, restart
*  Stata, then run it again to produce the output.  (Once the packages are
*  current this block can be left in place -- it just re-checks SSC -- or
*  commented out to save a few seconds per run.)
*------------------------------------------------------------------------------
ssc install lassopack, replace
ssc install pdslasso, replace
ssc install ivreg2, replace
ssc install ranktest, replace
ssc install estout, replace
ssc install cibar, replace
ssc install blindschemes, replace    // plotplainblind scheme, DHS Figure A.1
di as text "replication_appendix.do  started  $S_DATE $S_TIME"


*==============================================================================
* A. FERTILITY FAMILY  (dataset: FU_slim.dta; producer: 02_main_w7.do)
*==============================================================================
if $fert_family {
capture noisily {
use "$CRE\FU_slim.dta", clear

* ---- main_fert_w7 : any_child + Ab08, each 3 specs (Lasso / Necessary / Full) ----
estimates drop _all
foreach var of varlist any_child Ab08 {
    pdslasso `var' orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo `var'_pds
    reg `var' orig_treatment bl_fe*, robust
    estadd local Controls "Necessary"
    su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo `var'_n
    reg `var' orig_treatment i.em* m_* bl_fe*, robust
    estadd local Controls "Full"
    su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo `var'_full
}
esttab any_child* Ab08* using "$OUT\main_fert_w7.tex", replace style(tex) booktabs ///
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes nomtitles keep(orig_treatment) order(orig_treatment) ///
    mgroups("Any children" "Number of children", pattern(1 0 0 1 0 0) ///
            prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
    varlabels(orig_treatment "Treatment")

* ---- main_fert_w7_timesample : any_child_w7nr + nr_births_w7, 3 specs each ----
estimates drop _all
foreach var of varlist any_child_w7nr nr_births_w7 {
    pdslasso `var' orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo `var'_pds
    reg `var' orig_treatment bl_fe*, robust
    estadd local Controls "Necessary"
    su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo `var'_n
    reg `var' orig_treatment i.em* m_* bl_fe*, robust
    estadd local Controls "Full"
    su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo `var'_full
}
esttab any_child_w7nr* nr_births_w7* using "$OUT\main_fert_w7_timesample.tex", replace ///
    style(tex) booktabs stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes nomtitles keep(orig_treatment) order(orig_treatment) ///
    varlabels(orig_treatment "Treatment")

* ---- nr_births_w : retrospective births by wave (W1 reg; W2-W7 pdslasso) ----
estimates drop _all
reg nr_births_w1 orig_treatment bl_fe*, robust
estadd local Controls "Necessary"
estadd local Wave "1"
su nr_births_w1 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo nr_births_w1_a
forvalues a = 2/7 {
    pdslasso nr_births_w`a' orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    estadd local Wave "`a'"
    su nr_births_w`a' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo nr_births_w`a'_pds
}
esttab nr_births_w* using "$OUT\nr_births_w.tex", replace style(tex) booktabs ///
    stats(mean_depvar_c Controls Wave N, labels("Control mean" "Controls" "Wave" "N") fmt(2 0 0 %9.0fc)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes keep(orig_treatment) order(orig_treatment) ///
    varlabels(orig_treatment "Treatment") nomtitles

* ---- any_child_y_nm : cumulative any-child by year, non-mothers (y1-y9) ----
estimates drop _all
forvalues a = 1/9 {
    pdslasso any_child_y`a' orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su any_child_y`a' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo y`a'
}
#delimit ;
esttab y1 y2 y3 y4 y5 y6 y7 y8 y9 using "$OUT\any_child_y_nm.tex", replace style(tex) booktabs
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes
    keep(orig_treatment) order(orig_treatment)
    varlabels(orig_treatment "Treatment")
    nomtitles nonumbers
    prehead("\begin{tabular}{l*{9}{c}}" "\toprule"
            "&\multicolumn{9}{c}{Any children} \\"
            "\cmidrule(lr){2-10}"
            " & 1 year & 2 years & 3 years & 4 years & 5 years & 6 years & 7 years & 8 years & 9 years \\"
            " & (1) & (2) & (3) & (4) & (5) & (6) & (7) & (8) & (9) \\")
    posthead("\midrule") postfoot("\bottomrule" "\end{tabular}")
    ;
#delimit cr

* ---- wanted_parity01 : wanted_nrch by baseline parity (0 / at least 1) ----
estimates drop _all
pdslasso wanted_nrch orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
estadd local Controls "Lasso"
estadd local Sample "Baseline non-mothers"
su wanted_nrch if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo any0
pdslasso wanted_nrch orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==1, partial(bl_fe*) robust
estadd local Controls "Lasso"
estadd local Sample "Baseline mothers"
su wanted_nrch if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo any1
#delimit ;
esttab any0 any1 using "$OUT\wanted_parity01.tex", replace style(tex) booktabs
    stats(mean_depvar_c Sample Controls N, labels("Control mean" "Sample" "Controls" "N") fmt(2 0 0 %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes keep(orig_treatment) order(orig_treatment)
    varlabels(orig_treatment "Treatment")
    nomtitles nonumbers
    prehead("\begin{tabular}{l*{2}{c}}" "\toprule"
            "&\multicolumn{2}{c}{Ideal number of children} \\"
            "\cmidrule(lr){2-3}"
            "            &\multicolumn{1}{c}{(1)}&\multicolumn{1}{c}{(2)}\\")
    posthead("\midrule") postfoot("\bottomrule" "\end{tabular}")
    ;
#delimit cr

* ---- partner_w_more : pre-registered desired-fertility outcome (PAP hypothesis 2):
*      partner wants more children than the woman (endline L33), all / non-mothers /
*      mothers. Asked of women with a partner at endline (N=929).
*      EXPECT Treatment: -0.009 (0.026), -0.024 (0.048), 0.004 (0.033); control mean 0.19;
*      N 929 / 283 / 639 (mothers = any_child_w1nr==1, as in Table 3)
estimates drop _all
local i = 0
foreach spec in "1 All" "any_child_w1nr==0 Non-mothers" "any_child_w1nr==1 Mothers" {
    tokenize "`spec'"
    pdslasso partner_w_more_ch orig_treatment (i.em* m_* bl_fe*) if `1' & !missing(Ab08), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    estadd local Sample "`2'"
    qui su partner_w_more_ch if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    local ++i
    eststo pw`i'
}
esttab pw1 pw2 pw3 using "$OUT\partner_w_more.tex", replace style(tex) booktabs ///
    stats(mean_depvar_c Sample Controls N, labels("Control mean" "Sample" "Controls" "N") fmt(2 0 0 %9.0fc)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes nomtitles keep(orig_treatment) varlabels(orig_treatment "Treatment") ///
    mgroups("Partner wants more children", pattern(1 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span}))

* ---- Attrition_w7 : attrition on treatment, five control sets (matches
*      replication_w7.do: nc / full / any-interaction / nr-interaction / age) ----
estimates drop _all
reg attrit orig_treatment i.block, cl(id_anon)
estadd local Controls "Necessary"
su attrit if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo attr_nc
reg attrit orig_treatment base_any_child base_B11 base_partner_w_more_ch base_wanted_nrch ///
    base_appr_age_fkid base_K1 base_age base_Muslim base_Protestant base_edu_yrs base_leisure ///
    base_soc_rel bl_fe*, robust
estadd local Controls "Full"
su attrit if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo attr_full
reg attrit orig_treatment base_any_child base_any_t i.block, cl(id_anon)
estadd local Controls "Necessary"
su attrit if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo attr_any
reg attrit orig_treatment base_B11 base_nr_t i.block, cl(id_anon)
estadd local Controls "Necessary"
su attrit if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo attr_nr
reg attrit orig_treatment z_base_age z_base_age_t i.block, cl(id_anon)
estadd local Controls "Necessary"
su attrit if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo attr_age
esttab attr_nc attr_full attr_any attr_nr attr_age using "$OUT\Attrition_w7.tex", ///
    replace style(tex) booktabs stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes nomtitles ///
    keep(orig_treatment base_any_child base_B11 base_partner_w_more_ch base_wanted_nrch ///
         base_appr_age_fkid base_K1 base_age base_Muslim base_Protestant base_edu_yrs ///
         base_leisure base_soc_rel base_any_t base_nr_t z_base_age z_base_age_t) ///
    varlabels(orig_treatment "Treatment")

* ---- Attrition_w7_pres_PR : the 3-column presentation version the paper inputs
*      (col1 = Treatment only; col2 + baseline number of children and its
*       interaction; col3 + standardized baseline age and its interaction).
*       Reuses the attr_nc / attr_nr / attr_age estimates stored above. ----
#delimit ;
esttab attr_nc attr_nr attr_age using "$OUT\Attrition_w7_pres_PR.tex",
    replace style(tex) booktabs
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes
    keep(orig_treatment base_B11 base_nr_t z_base_age z_base_age_t)
    order(orig_treatment base_B11 base_nr_t z_base_age z_base_age_t)
    varlabels(orig_treatment "Treatment" base_B11 "Number of children"
              base_nr_t "Treatment $\times$ Number of children" z_base_age "Age (std)"
              z_base_age_t "Treatment $\times$ Age (std)")
    nomtitles nonumbers
    prehead("\begin{tabular}{l*{3}{c}}" "\toprule"
            "&\multicolumn{3}{c}{Respondent missing in Wave 7} \\"
            "\cmidrule(lr){2-4}"
            "            &\multicolumn{1}{c}{(1)}&\multicolumn{1}{c}{(2)}&\multicolumn{1}{c}{(3)}\\")
    posthead("\midrule") postfoot("\bottomrule" "\end{tabular}")
    ;
#delimit cr

* ---- main_pres_hwage : ITT with treatment x high-wage-firm interaction ----
* 7 columns: any_child All/NM, Ab08 All/Mothers/NM, wanted All, appr_age All.
capture drop t_mw_fac_hi
gen t_mw_fac_hi = mw_fac_hi*orig_treatment
estimates drop _all
pdslasso any_child orig_treatment t_mw_fac_hi (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
su any_child if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo hw_a
pdslasso any_child orig_treatment t_mw_fac_hi (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
estadd local Controls "Lasso"
su any_child if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Non-mothers"
eststo hw_b
pdslasso Ab08 orig_treatment t_mw_fac_hi (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo hw_c
pdslasso Ab08 orig_treatment t_mw_fac_hi (i.em* m_* bl_fe*) if any_child_w1nr==1, partial(bl_fe*) robust
estadd local Controls "Lasso"
su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Mothers"
eststo hw_d
pdslasso Ab08 orig_treatment t_mw_fac_hi (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
estadd local Controls "Lasso"
su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Non-mothers"
eststo hw_d2
pdslasso wanted_nrch orig_treatment t_mw_fac_hi (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
su wanted_nrch if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo hw_e
pdslasso appr_age_fkid orig_treatment t_mw_fac_hi (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
su appr_age_fkid if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo hw_f
esttab hw_a hw_b hw_c hw_d hw_d2 hw_e hw_f using "$OUT\main_pres_hwage.tex", replace ///
    style(tex) booktabs b(3) se(3) nonotes nomtitles starlevels(* 0.10 ** 0.05 *** 0.01) ///
    stats(mean_depvar_c Sample Controls N, labels("Control mean" "Sample" "Controls" "N") fmt(2 0 0 %9.0fc)) ///
    keep(orig_treatment t_mw_fac_hi) order(orig_treatment t_mw_fac_hi) ///
    mgroups("\shortstack{Any\\children}" "\shortstack{Number of\\children}" ///
            "\shortstack{Ideal nr.\\of children}" "\shortstack{Appropriate age\\at first birth}", ///
            pattern(1 0 1 0 0 1 1) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
    varlabels(orig_treatment "Treatment" t_mw_fac_hi "Treatment $\times$ High wage firm")

* ---- any_birth_w_nrsample : any-child by wave (W1 reg, W2-7 pdslasso) ----
estimates drop _all
reg any_child_w1nr orig_treatment bl_fe*, robust
estadd local Controls "Necessary"
estadd local Wave "1"
su any_child_w1nr if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo ab_w1
forvalues a = 2/7 {
    pdslasso any_child_w`a'nr orig_treatment (i.em_* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    estadd local Wave "`a'"
    su any_child_w`a'nr if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo ab_w`a'
}
esttab ab_w1 ab_w2 ab_w3 ab_w4 ab_w5 ab_w6 ab_w7 using "$OUT\any_birth_w_nrsample.tex", ///
    replace style(tex) booktabs stats(mean_depvar_c Controls Wave N, labels("Control mean" "Controls" "Wave" "N") fmt(2 0 0 %9.0fc)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes keep(orig_treatment) order(orig_treatment) ///
    varlabels(orig_treatment "Treatment") nomtitles

* ---- any_child_nr_births_y : cumulative fertility by year (Panel A any child, ----
* Panel B number of births), years 1-9, pdslasso main spec ----
estimates drop _all
forvalues a = 1/9 {
    pdslasso any_child_y`a' orig_treatment (i.em_* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su any_child_y`a' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo acy`a'
    pdslasso nr_births_y`a' orig_treatment (i.em_* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su nr_births_y`a' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo nby`a'
}
#delimit ;
esttab acy1 acy2 acy3 acy4 acy5 acy6 acy7 acy8 acy9 using "$OUT\any_child_nr_births_y.tex",
    replace style(tex) booktabs stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 %9s %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes keep(orig_treatment) order(orig_treatment)
    varlabels(orig_treatment "Treatment")
    nomtitles nonumbers
    prehead("\begin{tabular}{l*{9}{c}}" "\toprule"
            " & 1 year & 2 years & 3 years & 4 years & 5 years & 6 years & 7 years & 8 years & 9 years \\"
            " & (1) & (2) & (3) & (4) & (5) & (6) & (7) & (8) & (9) \\"
            "\midrule"
            "\multicolumn{10}{l}{\textbf{Panel A. Any children}} \\")
    posthead("") postfoot("") ;
esttab nby1 nby2 nby3 nby4 nby5 nby6 nby7 nby8 nby9 using "$OUT\any_child_nr_births_y.tex",
    append style(tex) booktabs stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 %9s %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes keep(orig_treatment) order(orig_treatment)
    varlabels(orig_treatment "Treatment")
    nomtitles nonumbers
    prehead("\midrule" "\multicolumn{10}{l}{\textbf{Panel B. Number of children}} \\")
    posthead("") postfoot("\bottomrule" "\end{tabular}") ;
#delimit cr

di as result "A. fertility family done (incl. any_birth_w_nrsample, any_child_nr_births_y)"
* (fact_des_mw_fac_hi and balance_samples_higlow_edt are produced in Section H.)
}
}


*==============================================================================
* B. FIRST-STAGE VARIANTS  (dataset: panel_slim.dta; producer: 03_over_time.do)
*   first_lasso_by_motherhood_pres = first stage by wave, Panel A baseline non-mothers,
*   Panel B baseline mothers;
*   first_lasso_nm_can / _cannot (can/cannot combine work with a newborn) and
*   first_lasso_pres_hw / _lw (high/low-wage-firm split) are all produced below.
*==============================================================================
if $firststage {
capture noisily {
use "$CRE\panel_slim.dta", clear
capture confirm variable orig_treatment
if _rc capture rename orig_treatment_r orig_treatment

* ---- first_lasso_by_motherhood_pres : first stage by wave, by baseline motherhood ----
* Two panels, Lasso only: Panel A = baseline non-mothers, Panel B = baseline
* mothers. Panel B replaces the former Table A.7 (first_stage_by_motherhood),
* which is no longer produced.
estimates drop _all
foreach s in 0 1 {
    local p = cond(`s'==0,"A","B")
    pdslasso any_wage_job_last6_r_alt orig_treatment (i.em* m_* bl_fe* i.wave) ///
        if wave>1 & wave<8 & nr_births_r!=. & any_child_w1nr==`s', partial(bl_fe* i.wave) cl(id_anon)
    estadd local Controls "Lasso"
    estadd local Wave "2--7"
    su any_wage_job_last6_r_alt if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo `p'_w1
    forvalues a = 2/7 {
        pdslasso any_wage_job_last6_r_alt orig_treatment (i.em* m_* bl_fe*) ///
            if wave==`a' & nr_births_r!=. & any_child_w1nr==`s', partial(bl_fe*) cl(id_anon)
        estadd local Controls "Lasso"
        estadd local Wave "`a'"
        su any_wage_job_last6_r_alt if e(sample)==1 & orig_treatment==0
        estadd scalar mean_depvar_c = r(mean)
        eststo `p'_w`a'
    }
}
#delimit ;
esttab A_w1 A_w2 A_w3 A_w4 A_w5 A_w6 A_w7 using "$OUT\first_lasso_by_motherhood_pres.tex",
    replace style(tex) booktabs b(3) se(3) nonotes starlevels(* 0.10 ** 0.05 *** 0.01)
    keep(orig_treatment) varlabels(orig_treatment "Treatment")
    stats(mean_depvar_c Controls Wave N, labels("Control mean" "Controls" "Wave" "N") fmt(2 0 0 %9.0fc))
    nomtitles nonumbers
    prehead("\begin{tabular}{l*{7}{c}}" "\toprule"
            " & \multicolumn{7}{c}{Any formal wage job in the last six months} \\\cmidrule(lr){2-8}"
            " & (1) & (2) & (3) & (4) & (5) & (6) & (7) \\"
            "\midrule"
            "\multicolumn{8}{l}{\textbf{Panel A. Non-mothers at baseline}}\\")
    posthead("") postfoot("") ;
esttab B_w1 B_w2 B_w3 B_w4 B_w5 B_w6 B_w7 using "$OUT\first_lasso_by_motherhood_pres.tex",
    append style(tex) booktabs b(3) se(3) nonotes starlevels(* 0.10 ** 0.05 *** 0.01)
    keep(orig_treatment) varlabels(orig_treatment "Treatment")
    stats(mean_depvar_c Controls Wave N, labels("Control mean" "Controls" "Wave" "N") fmt(2 0 0 %9.0fc))
    nomtitles nonumbers
    prehead("\midrule" "\multicolumn{8}{l}{\textbf{Panel B. Mothers at baseline}}\\")
    posthead("") postfoot("\bottomrule" "\end{tabular}") ;
#delimit cr
* ---- first_lasso_pres_hw / _lw : first stage by wave, split by firm wage ----
foreach hl in hw lw {
    if "`hl'"=="hw" local cond "mw_fac_hi==1"
    else            local cond "mw_fac_hi==0"
    preserve
    keep if `cond'
    estimates drop _all
    pdslasso any_wage_job_last6_r_alt orig_treatment (i.em* m_* bl_fe* i.wave) ///
        if wave>1 & wave<8 & nr_births_r!=., partial(bl_fe* i.wave) cl(id_anon)
    estadd local Controls "Lasso"
    estadd local Wave "2--7"
    su any_wage_job_last6_r_alt if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo w1
    forvalues a = 2/7 {
        pdslasso any_wage_job_last6_r_alt orig_treatment (i.em* m_* bl_fe*) ///
            if wave==`a' & nr_births_r!=., partial(bl_fe*) cl(id_anon)
        estadd local Controls "Lasso"
        estadd local Wave "`a'"
        su any_wage_job_last6_r_alt if e(sample)==1 & orig_treatment==0
        estadd scalar mean_depvar_c = r(mean)
        eststo w`a'
    }
    esttab w1 w2 w3 w4 w5 w6 w7 using "$OUT\first_lasso_pres_`hl'.tex", replace ///
        style(tex) booktabs b(3) se(3) nonotes starlevels(* 0.10 ** 0.05 *** 0.01) ///
        keep(orig_treatment) varlabels(orig_treatment "Treatment") ///
    mgroups("Any formal wage job in the last six months", pattern(1 0 0 0 0 0 0) ///
            prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
        stats(mean_depvar_c Controls Wave N, labels("Control mean" "Controls" "Wave" "N") fmt(2 0 0 %9.0fc)) ///
        nomtitles
    restore
}
* ---- first_lasso_nm_can / _cannot : first stage by wave, baseline non-mothers,
*   split by K1_53 "able to work with a newborn" (1,2 = can; 3 = cannot).
*   can + cannot pooled N (753 + 928) = Panel A pooled N of first_lasso_by_motherhood_pres (1681). ----
capture confirm variable K1_53
if _rc merge m:1 id_anon using "$CRE\FU_slim.dta", keepusing(K1_53) nogen
capture drop wchild_bin
gen byte wchild_bin = .
replace wchild_bin = 1 if inlist(K1_53,1,2)
replace wchild_bin = 0 if K1_53==3
foreach cc in can cannot {
    if "`cc'"=="can" local w = 1
    else             local w = 0
    preserve
    keep if wchild_bin==`w'
    estimates drop _all
    pdslasso any_wage_job_last6_r_alt orig_treatment (i.em* m_* bl_fe* i.wave) ///
        if wave>1 & wave<8 & nr_births_r!=. & any_child_w1nr==0, partial(bl_fe* i.wave) cl(id_anon)
    estadd local Controls "Lasso"
    estadd local Wave "2--7"
    su any_wage_job_last6_r_alt if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo cw1
    forvalues a = 2/7 {
        pdslasso any_wage_job_last6_r_alt orig_treatment (i.em* m_* bl_fe*) ///
            if wave==`a' & nr_births_r!=. & any_child_w1nr==0, partial(bl_fe*) cl(id_anon)
        estadd local Controls "Lasso"
        estadd local Wave "`a'"
        su any_wage_job_last6_r_alt if e(sample)==1 & orig_treatment==0
        estadd scalar mean_depvar_c = r(mean)
        eststo cw`a'
    }
    esttab cw1 cw2 cw3 cw4 cw5 cw6 cw7 using "$OUT\first_lasso_nm_`cc'.tex", ///
        replace style(tex) booktabs b(3) se(3) nonotes starlevels(* 0.10 ** 0.05 *** 0.01) ///
        keep(orig_treatment) varlabels(orig_treatment "Treatment") ///
    mgroups("Any formal wage job in the last six months", pattern(1 0 0 0 0 0 0) ///
            prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
        stats(mean_depvar_c Controls Wave N, labels("Control mean" "Controls" "Wave" "N") fmt(2 0 0 %9.0fc)) ///
        nomtitles
    restore
}
di as result "B. first-stage (non-mothers/mothers + hw/lw + can/cannot) done"
}
}


*==============================================================================
* C. CUMULATIVE / OVER-TIME INCOME-SAVINGS FAMILY  (dataset: cumulative_slim.dta)
*   Producer: do/cumulative.do.  Templated across the six outcomes.
*   ot  = wave-specific level (x2..x7);  cum = cumulative (x2, sum23..sum27).
*   bal = balanced (observed in wave 7).  Balanced-sample nuance flagged.
*==============================================================================
if $cumfamily {
capture noisily {
use "$CRE\cumulative_slim.dta", clear
* a_w_j is created in the producer by renaming any_wage_job_last6_r_alt.
capture rename any_wage_job_last6_r_alt a_w_j
keep ea_last6_r fac_last6_r a_w_j savings hhinc6 inc6 any_child_r orig_treatment_r id_anon wave em* m_* bl_fe*
reshape wide ea_last6_r fac_last6_r a_w_j savings hhinc6 inc6 any_child_r orig_treatment_r, i(id_anon) j(wave)
foreach x in ea_last6_r fac_last6_r a_w_j savings hhinc6 inc6 {
    gen sum27_`x' = `x'2+`x'3+`x'4+`x'5+`x'6+`x'7
    gen sum23_`x' = `x'2+`x'3
    gen sum24_`x' = `x'2+`x'3+`x'4
    gen sum25_`x' = `x'2+`x'3+`x'4+`x'5
    gen sum26_`x' = `x'2+`x'3+`x'4+`x'5+`x'6
}
gen byte nm = any_child_r1==0

* ---- over-time balanced (level by wave), full + non-mothers ----
foreach x in ea_last6_r fac_last6_r a_w_j savings hhinc6 inc6 {
    * control means: birr amounts at 0 decimals (house rule), shares at 2
    local mfmt = cond(inlist("`x'","ea_last6_r","savings","hhinc6","inc6"), "%12.0fc", "2")
    estimates drop _all
    * over-time uses the per-wave observed sample restricted to wave-7 presence
    * (if x7!=.); NOT the fully-balanced sample used for the cumulative columns.
    forvalues i = 2/7 {
        pdslasso `x'`i' orig_treatment_r1 (i.em* m_* `x'1 bl_fe*) if `x'7!=., partial(bl_fe*) robust
        estadd local Controls "Lasso"
        estadd local Wave "`i'"
        su `x'`i' if e(sample)==1 & orig_treatment_r1==0
        estadd scalar mean_depvar_c = r(mean)
        eststo ot`i'
    }
    esttab ot2 ot3 ot4 ot5 ot6 ot7 using "$OUT/`x'_ot_bal.tex", replace style(tex) booktabs ///
        stats(mean_depvar_c Controls Wave N, labels("Control mean" "Controls" "Wave" "N") fmt(`mfmt' 0 0 %9.0fc)) ///
        starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes keep(orig_treatment_r1) order(orig_treatment_r1) ///
        varlabels(orig_treatment_r1 "Treatment") nomtitles

    * cumulative balanced
    estimates drop _all
    pdslasso `x'2 orig_treatment_r1 (i.em* m_* `x'1 bl_fe*) if !missing(sum27_`x'), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    estadd local Wave "2"
    su `x'2 if e(sample)==1 & orig_treatment_r1==0
    estadd scalar mean_depvar_c = r(mean)
    eststo c2
    foreach j in 3 4 5 6 7 {
        pdslasso sum2`j'_`x' orig_treatment_r1 (i.em* m_* `x'1 bl_fe*) if !missing(sum27_`x'), partial(bl_fe*) robust
        estadd local Controls "Lasso"
        estadd local Wave "2--`j'"
        su sum2`j'_`x' if e(sample)==1 & orig_treatment_r1==0
        estadd scalar mean_depvar_c = r(mean)
        eststo c`j'
    }
    esttab c2 c3 c4 c5 c6 c7 using "$OUT/`x'_cum_bal.tex", replace style(tex) booktabs ///
        stats(mean_depvar_c Controls Wave N, labels("Control mean" "Controls" "Wave" "N") fmt(`mfmt' 0 0 %9.0fc)) ///
        starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes keep(orig_treatment_r1) order(orig_treatment_r1) ///
        varlabels(orig_treatment_r1 "Treatment") nomtitles
}
* ---- non-mother variants (savings, hhinc6): ot_bal_nm + cum_bal_nm ----
foreach x in savings hhinc6 {
    local mfmt "%12.0fc"
    * over-time, non-mothers
    estimates drop _all
    forvalues i = 2/7 {
        pdslasso `x'`i' orig_treatment_r1 (i.em* m_* `x'1 bl_fe*) if `x'7!=. & nm==1, partial(bl_fe*) robust
        estadd local Controls "Lasso"
        estadd local Wave "`i'"
        su `x'`i' if e(sample)==1 & orig_treatment_r1==0
        estadd scalar mean_depvar_c = r(mean)
        eststo ot`i'
    }
    esttab ot2 ot3 ot4 ot5 ot6 ot7 using "$OUT/`x'_ot_bal_nm.tex", replace style(tex) booktabs ///
        stats(mean_depvar_c Controls Wave N, labels("Control mean" "Controls" "Wave" "N") fmt(`mfmt' 0 0 %9.0fc)) ///
        starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes keep(orig_treatment_r1) order(orig_treatment_r1) ///
        varlabels(orig_treatment_r1 "Treatment") nomtitles
    * cumulative, non-mothers
    estimates drop _all
    pdslasso `x'2 orig_treatment_r1 (i.em* m_* `x'1 bl_fe*) if !missing(sum27_`x') & nm==1, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    estadd local Wave "2"
    su `x'2 if e(sample)==1 & orig_treatment_r1==0
    estadd scalar mean_depvar_c = r(mean)
    eststo c2
    foreach j in 3 4 5 6 7 {
        pdslasso sum2`j'_`x' orig_treatment_r1 (i.em* m_* `x'1 bl_fe*) if !missing(sum27_`x') & nm==1, partial(bl_fe*) robust
        estadd local Controls "Lasso"
        estadd local Wave "2--`j'"
        su sum2`j'_`x' if e(sample)==1 & orig_treatment_r1==0
        estadd scalar mean_depvar_c = r(mean)
        eststo c`j'
    }
    esttab c2 c3 c4 c5 c6 c7 using "$OUT/`x'_cum_bal_nm.tex", replace style(tex) booktabs ///
        stats(mean_depvar_c Controls Wave N, labels("Control mean" "Controls" "Wave" "N") fmt(`mfmt' 0 0 %9.0fc)) ///
        starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes keep(orig_treatment_r1) order(orig_treatment_r1) ///
        varlabels(orig_treatment_r1 "Treatment") nomtitles
}
* ---- hhinc6_savings_ot_bal: income (Panel A) + savings (Panel B), 2-panel ----
* Producer: do/cumulative.do. Over-time balanced (if x7!=.), waves 2-7.
estimates drop _all
forvalues i = 2/7 {
    pdslasso hhinc6`i' orig_treatment_r1 (i.em* m_* hhinc61 bl_fe*) if hhinc67!=., partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su hhinc6`i' if e(sample)==1 & orig_treatment_r1==0
    estadd scalar mean_depvar_c = r(mean)
    eststo hhinc6_r`i'
}
forvalues i = 2/7 {
    pdslasso savings`i' orig_treatment_r1 (i.em* m_* savings1 bl_fe*) if savings7!=., partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su savings`i' if e(sample)==1 & orig_treatment_r1==0
    estadd scalar mean_depvar_c = r(mean)
    eststo savings_r`i'
}
#delimit ;
esttab hhinc6_r2 hhinc6_r3 hhinc6_r4 hhinc6_r5 hhinc6_r6 hhinc6_r7
    using "$OUT/hhinc6_savings_ot_bal.tex",
    style(tex) booktabs
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(%12.0fc %9s %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes
    nomtitles nonumbers
    keep(orig_treatment_r1) order(orig_treatment_r1)
    varlabels(orig_treatment_r1 "Treatment")
    prehead("\begin{tabular}{l*{6}{c}}" "\toprule"
            " & Wave 2 & Wave 3 & Wave 4 & Wave 5 & Wave 6 & Wave 7 \\"
            " & (1) & (2) & (3) & (4) & (5) & (6) \\"
            "\midrule"
            "\multicolumn{7}{l}{\textbf{Panel A. Household income}} \\")
    posthead("") postfoot("")
    replace ;
esttab savings_r2 savings_r3 savings_r4 savings_r5 savings_r6 savings_r7
    using "$OUT/hhinc6_savings_ot_bal.tex",
    style(tex) booktabs
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(%12.0fc %9s %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes
    nomtitles nonumbers
    keep(orig_treatment_r1) order(orig_treatment_r1)
    varlabels(orig_treatment_r1 "Treatment")
    prehead("\midrule" "\multicolumn{7}{l}{\textbf{Panel B. Savings}} \\")
    posthead("") postfoot("\bottomrule" "\end{tabular}")
    append ;
#delimit cr
di as result "C. cumulative family done (ot_bal + cum_bal + _nm + hhinc6_savings_ot_bal)"
}
}


*==============================================================================
* D. NUMBER-OF-CHILDREN HETEROGENEITY BY INCOME  (hhinc_hetero_nr)
*   Dataset: FU_slim.dta; producer: do/add_hetero.do.
*==============================================================================
if $hetero_nr {
capture noisily {
use "$CRE\FU_slim.dta", clear
xtile hhinc_q = base_hhinc6 if base_hhinc6<., nq(5)
tab hhinc_q, gen(hhinc_q_)
gen t_q2 = hhinc_q_2 * orig_treatment
gen t_q3 = hhinc_q_3 * orig_treatment
gen t_q4 = hhinc_q_4 * orig_treatment
gen t_q5 = hhinc_q_5 * orig_treatment
estimates drop _all
pdslasso Ab08 orig_treatment hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 t_q2 t_q3 t_q4 t_q5 ///
    (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo nr_all
pdslasso Ab08 orig_treatment hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 t_q2 t_q3 t_q4 t_q5 ///
    (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
estadd local Controls "Lasso"
su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Non-mothers"
eststo nr_nm
* committed hhinc_hetero_nr also has reg (Necessary) columns 3-4; add them:
reg Ab08 orig_treatment hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 t_q2 t_q3 t_q4 t_q5 bl_fe*, robust
estadd local Controls "Necessary"
su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo nr_all_n
reg Ab08 orig_treatment hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 t_q2 t_q3 t_q4 t_q5 bl_fe* ///
    if any_child_w1nr==0, robust
estadd local Controls "Necessary"
su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Non-mothers"
eststo nr_nm_n
local vlist orig_treatment hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 t_q2 t_q3 t_q4 t_q5
esttab nr_all nr_nm nr_all_n nr_nm_n using "$OUT\hhinc_hetero_nr.tex", replace style(tex) booktabs ///
    b(3) se(3) nonotes nomtitles starlevels(* 0.10 ** 0.05 *** 0.01) ///
    stats(mean_depvar_c Sample Controls N, labels("Control mean" "Sample" "Controls" "N") fmt(2 0 0 %9.0fc)) ///
    keep(`vlist') order(`vlist') ///
    varlabels(orig_treatment "Treatment" hhinc_q_2 "Income Q2" hhinc_q_3 "Income Q3" ///
              hhinc_q_4 "Income Q4" hhinc_q_5 "Income Q5 (richest)" ///
              t_q2 "Treatment $\times$ Income Q2" t_q3 "Treatment $\times$ Income Q3" ///
              t_q4 "Treatment $\times$ Income Q4" t_q5 "Treatment $\times$ Income Q5 (richest)")
di as result "D. hhinc_hetero_nr done"
}
}


*==============================================================================
* G. CHECK_QUESTIONS TABLES  (producer: do/check_questions.do)
*   check_mw_within_region + check_fertprefs_young/bins (FU_6th_norest);
*   check_savings_inc_mw_split (cumulative_slim.dta); check_firststage_hhinc_q
*   (panel_slim.dta); check_TU_w2_2 (time use, panel_slim.dta).
*==============================================================================
if $checkq {
* ---- G1/G2 on FU_6th_norest ----
capture noisily {
use "$CRE\FU_slim.dta", clear

* check_mw_within_region : treatment x within-region high-wage
* mw_fac_hi_within (high wage relative to the within-region median) is
* pre-computed in the release build from factory wage + region (both dropped
* from the public data); it is already in FU_slim.
gen byte t_mw_fac_hi_within = orig_treatment * mw_fac_hi_within
estimates drop _all
foreach spec in "any_child . All a" "any_child any_child_w1nr==0 Non-mothers b" ///
                "Ab08 . All c" "Ab08 any_child_w1nr==1 Mothers d" ///
                "Ab08 any_child_w1nr==0 Non-mothers d2" "wanted_nrch . All e" ///
                "appr_age_fkid . All f" {
    tokenize "`spec'"
    if "`2'"=="." local ifq ""
    else          local ifq "if `2'"
    pdslasso `1' orig_treatment t_mw_fac_hi_within (i.em* m_* bl_fe*) `ifq', partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su `1' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    estadd local Sample "`3'"
    eststo `4'
}
esttab a b c d d2 e f using "$OUT\check_mw_within_region.tex", replace style(tex) booktabs ///
    stats(mean_depvar_c Sample Controls N, labels("Control mean" "Sample" "Controls" "N") fmt(2 0 0 %9.0fc)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes nomtitles keep(orig_treatment t_mw_fac_hi_within) ///
    order(orig_treatment t_mw_fac_hi_within) ///
    mgroups("\shortstack{Any\\children}" "\shortstack{Number of\\children}" ///
            "\shortstack{Ideal nr.\\of children}" "\shortstack{Appropriate age\\at first birth}", ///
            pattern(1 0 1 0 0 1 1) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
    varlabels(orig_treatment "Treatment" t_mw_fac_hi_within "Treatment $\times$ High wage within region")

* check_fertprefs_young : binned baseline desired fertility (young + all)
gen byte want_bin = 1 if base_wanted_nrch <= 2
replace want_bin = 2 if base_wanted_nrch >= 3 & base_wanted_nrch <= 4
replace want_bin = 3 if base_wanted_nrch >= 5 & !missing(base_wanted_nrch)   // missing is not ">= 5" (fixed 2026-10-03)
tab want_bin, gen(want_bin_)
gen byte t_wb_2 = orig_treatment * want_bin_2
gen byte t_wb_3 = orig_treatment * want_bin_3
* The bins are a deterministic function of base_wanted_nrch, and the control
* pool m_* contains that same variable's dummies (m_base_w_nrch_dum*, built in
* do/wave7.do from base_wanted_nrch_rec). If the lasso selects the full set,
* want_bin_2/want_bin_3 are perfectly collinear with the selected controls and
* drop out as (omitted). Exclude them from the pool for this table only.
unab m_all : m_*
capture ds m_base_w_nrch_dum*
local m_wnrch `r(varlist)'
local m_ctrl : list m_all - m_wnrch
local n_wnrch : word count `m_wnrch'
di as text "A.10 control pool: dropped `n_wnrch' baseline ideal-children dummies"
estimates drop _all
pdslasso any_child orig_treatment want_bin_2 want_bin_3 t_wb_2 t_wb_3 (i.em* `m_ctrl' bl_fe*) if base_age<=25, partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su any_child if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Young (age $\leq$ 25)"
eststo q13_young
pdslasso any_child orig_treatment want_bin_2 want_bin_3 t_wb_2 t_wb_3 (i.em* `m_ctrl' bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su any_child if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All ages"
eststo q13_all
esttab q13_young q13_all using "$OUT\check_fertprefs_young.tex", replace style(tex) booktabs ///
    stats(mean_depvar_c Sample Controls N, labels("Control mean" "Sample" "Controls" "N") fmt(2 0 0 %9.0fc)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes nomtitles ///
    mgroups("Any children", pattern(1 0) ///
            prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
    keep(orig_treatment want_bin_2 want_bin_3 t_wb_2 t_wb_3) ///
    order(orig_treatment want_bin_2 want_bin_3 t_wb_2 t_wb_3) ///
    varlabels(orig_treatment "Treatment ($\leq$2 ref.)" want_bin_2 "Wants 3--4" want_bin_3 "Wants $\geq$ 5" ///
              t_wb_2 "Treatment $\times$ Wants 3--4" t_wb_3 "Treatment $\times$ Wants $\geq$ 5")
* check_fertprefs_bins : bin counts (all / young / control / treatment)
file open fh using "$OUT/check_fertprefs_bins.tex", write replace
file write fh "\begin{tabular}{lcccc}" _n "\toprule" _n
file write fh "Ideal nr. children at baseline & All women & Young (age $\leq$ 25) & Control & Treatment \\" _n
file write fh " & (1) & (2) & (3) & (4) \\" _n
file write fh "\midrule" _n
forvalues b = 1/3 {
    if `b'==1 local lab "Wants $\leq$2"
    if `b'==2 local lab "Wants 3--4"
    if `b'==3 local lab "Wants $\geq$5"
    qui count if want_bin==`b'
    local n_all = r(N)
    qui count if want_bin==`b' & base_age<=25
    local n_young = r(N)
    qui count if want_bin==`b' & orig_treatment==0
    local n_c = r(N)
    qui count if want_bin==`b' & orig_treatment==1
    local n_t = r(N)
    file write fh "`lab' & `n_all' & `n_young' & `n_c' & `n_t' \\" _n
}
file write fh "\midrule" _n
qui count if !missing(want_bin)
local tot_all = r(N)
qui count if !missing(want_bin) & base_age<=25
local tot_young = r(N)
qui count if !missing(want_bin) & orig_treatment==0
local tot_c = r(N)
qui count if !missing(want_bin) & orig_treatment==1
local tot_t = r(N)
file write fh "Total (non-missing) & `tot_all' & `tot_young' & `tot_c' & `tot_t' \\" _n
file write fh "\bottomrule" _n "\end{tabular}" _n
file close fh
di as result "G1/G2 (within-region, fertprefs, bins) done"
}

* ---- G3 check_savings_inc_mw_split on cumulative ----
capture noisily {
use "$CRE\cumulative_slim.dta", clear
keep id_anon wave savings hhinc6 orig_treatment_r mw_fac_hi em_* m_* bl_fe*
drop if wave==1
foreach v in savings hhinc6 {
    bysort id_anon: egen double `v'_cum_W27 = total(`v'), missing
}
bysort id_anon (wave): keep if _n==1
estimates drop _all
foreach v in savings_cum_W27 hhinc6_cum_W27 {
    foreach h in 1 0 {
        pdslasso `v' orig_treatment_r (i.em* m_* bl_fe*) if mw_fac_hi==`h', partial(bl_fe*) robust
        estadd local Controls "Lasso"
        estadd local Sample = cond(`h'==1, "High wage", "Low wage")
        qui su `v' if e(sample)==1 & orig_treatment_r==0
        estadd scalar mean_y_c = r(mean)
        eststo split_`v'_`h'
    }
}
esttab split_savings_cum_W27_1 split_savings_cum_W27_0 split_hhinc6_cum_W27_1 split_hhinc6_cum_W27_0 ///
    using "$OUT\check_savings_inc_mw_split.tex", replace style(tex) booktabs ///
    stats(mean_y_c Sample Controls N, labels("Control mean" "Sample" "Controls" "N") fmt(%12.0fc 0 0 %9.0fc)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes nomtitles keep(orig_treatment_r) order(orig_treatment_r) ///
    mgroups("Cumulative savings" "Cumulative income", pattern(1 0 1 0) ///
            prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
    varlabels(orig_treatment_r "Treatment")
di as result "G3 (savings/income by wage split) done"
}

* ---- G4 check_firststage_hhinc_q on panel_long ----
capture noisily {
use "$CRE\panel_slim.dta", clear
capture confirm variable base_hhinc6
if _rc {
    merge m:1 id_anon using "$CRE\FU_slim.dta", keepusing(base_hhinc6) update
    drop _merge
}
xtile hhinc_q = base_hhinc6 if base_hhinc6<. & wave==1, nq(5)
bysort id_anon (wave): replace hhinc_q = hhinc_q[1] if missing(hhinc_q)
tab hhinc_q, gen(hhinc_q_)
foreach k in 1 2 3 4 5 {
    gen byte t_hhinc_q_`k' = orig_treatment_r * hhinc_q_`k'
}
estimates drop _all
pdslasso any_wage_job_last6_r_alt orig_treatment_r hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 ///
    t_hhinc_q_2 t_hhinc_q_3 t_hhinc_q_4 t_hhinc_q_5 (i.em* m_* bl_fe* i.wave) if wave>1, ///
    partial(bl_fe* i.wave) cl(id_anon)
estadd local Controls "Lasso"
qui su any_wage_job_last6_r_alt if e(sample)==1 & orig_treatment_r==0
estadd scalar mean_depvar_c = r(mean)
eststo fs_hhincq
esttab fs_hhincq using "$OUT\check_firststage_hhinc_q.tex", replace style(tex) booktabs ///
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes nomtitles ///
    mgroups("\shortstack{Any formal wage job\\in the last six months}", pattern(1) ///
            prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
    keep(orig_treatment_r hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 t_hhinc_q_2 t_hhinc_q_3 t_hhinc_q_4 t_hhinc_q_5) ///
    order(orig_treatment_r hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 t_hhinc_q_2 t_hhinc_q_3 t_hhinc_q_4 t_hhinc_q_5) ///
    varlabels(orig_treatment_r "Treatment" ///
              hhinc_q_2 "Q2" hhinc_q_3 "Q3" hhinc_q_4 "Q4" hhinc_q_5 "Q5 (richest)" ///
              t_hhinc_q_2 "Treatment $\times$ Q2" t_hhinc_q_3 "Treatment $\times$ Q3" ///
              t_hhinc_q_4 "Treatment $\times$ Q4" t_hhinc_q_5 "Treatment $\times$ Q5 (richest)")
di as result "G4 (first stage by income quintile) done"
}

* ---- G5 check_TU_w2_2 : time use in wave 2 (9 categories + sum, 10 cols) ----
capture noisily {
use "$CRE\panel_slim.dta" if wave==2, clear
foreach base in leisure eating soc_rel school sleeping travel unpaid hh_work care {
    local v_`base' ""
    capture confirm variable `base'_r
    if !_rc local v_`base' `base'_r
    else {
        capture confirm variable `base'
        if !_rc local v_`base' `base'
    }
}
estimates drop _all
local estlist2 ""
local titles2 ""
foreach pr in "leisure Leisure" "eating Eating" "soc_rel Soc.rel." "school School" ///
              "sleeping Sleeping" "travel Travel" "unpaid Unpaid" "hh_work Housework" "care Care" {
    gettoken base title : pr
    local v `v_`base''
    if "`v'" == "" continue
    pdslasso `v' orig_treatment_r (i.em* m_* bl_fe*), partial(bl_fe*) robust
    qui su `v' if orig_treatment_r==0
    estadd scalar mean_depvar_c = r(mean)
    estadd local Controls "Lasso"
    eststo tuw2_`base'
    local estlist2 `estlist2' tuw2_`base'
    local titles2 `"`titles2' "`title'""'
}
* 10th column is Paid work (hours_r), matching the current paper (the old
* "Sum (10 cats)" diagnostic column was replaced with paid work).
capture confirm variable hours_r
if _rc==0 local vhours hours_r
else      local vhours hours
capture {
    pdslasso `vhours' orig_treatment_r (i.em* m_* bl_fe*), partial(bl_fe*) robust
    qui su `vhours' if orig_treatment_r==0
    estadd scalar mean_depvar_c = r(mean)
    estadd local Controls "Lasso"
    eststo tuw2_paid
    local estlist2 `estlist2' tuw2_paid
    local titles2 `"`titles2' "Paid work""'
}
* header built by hand so the column numbers sit below the column labels
local ncol2 : word count `estlist2'
local hdrA ""
local hdrB ""
local k2 = 0
foreach t of local titles2 {
    local ++k2
    local hdrA `"`hdrA'&\multicolumn{1}{c}{`t'}"'
    local hdrB `"`hdrB'&\multicolumn{1}{c}{(`k2')}"'
}
#delimit ;
esttab `estlist2' using "$OUT\check_TU_w2_2.tex", replace style(tex) booktabs
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes
    keep(orig_treatment_r) order(orig_treatment_r) varlabels(orig_treatment_r "Treatment")
    nomtitles nonumbers
    prehead("\begin{tabular}{l*{`ncol2'}{c}}" "\toprule"
            "            `hdrA'\\"
            "            `hdrB'\\")
    posthead("\midrule") postfoot("\bottomrule" "\end{tabular}")
    ;
#delimit cr
di as result "G5 (time use w2) done"
}
}


*==============================================================================
* H. WAGE-SPLIT DESCRIPTIVES  (FU_6th_norest)
*   Producers found in the NON-cursor tree: first_stage_by_motherhood.do,
*   fertility_results.do (balance_samples_higlow, fact_des_mw_fac_hi).
*==============================================================================
if $descr {
capture noisily {
use "$CRE\FU_slim.dta", clear

* (first_stage_by_motherhood, formerly Table A.7, removed 2026-09-29: the
*  mothers-at-baseline first stage is now Panel B of first_lasso_by_motherhood_pres.)

* ---- balance_samples_higlow_edt: interaction on baseline covariates + F-test ----
* TWO sets of stars, as in the committed table. The plain stars come from ONE
* joint regression of Treatment x High wage firm on all the characteristics
* (block FE included); the stars in SQUARE BRACKETS come from re-estimating each
* difference ONE VARIABLE AT A TIME, block FE only. esttab can carry only one
* star set, so this fragment is written by hand. The manuscript's Notes describe
* both sets -- keep them in sync.
capture drop t_mw_fac_hi
gen t_mw_fac_hi = mw_fac_hi*orig_treatment
local bcov any_child_w1nr nr_births_w1 base_partner_w_more_ch base_wanted_nrch base_appr_age_fkid ///
           base_K1 base_age base_Muslim base_Protestant base_edu_yrs base_leisure base_soc_rel

local lab_any_child_w1nr         "Any children"
local lab_nr_births_w1           "Number of children"
local lab_base_partner_w_more_ch "Partner's ideal number of children $>$ woman's own"
local lab_base_wanted_nrch       "Ideal number of children"
local lab_base_appr_age_fkid     "Appropriate age at first birth"
local lab_base_K1                "Ever had a wage job"
local lab_base_age               "Age"
local lab_base_Muslim            "Muslim"
local lab_base_Protestant        "Protestant"
local lab_base_edu_yrs           "Years of education"
local lab_base_leisure           "Leisure time last 7 days (hours)"
local lab_base_soc_rel           "Social and religious activities last 7 days (hours)"

capture program drop balstar
program define balstar, rclass
    args p
    local s ""
    if `p'<0.10 local s "*"
    if `p'<0.05 local s "**"
    if `p'<0.01 local s "***"
    return local s "`s'"
end

* (a) one variable at a time, block FE only -> bracketed stars
foreach v of local bcov {
    quietly reg t_mw_fac_hi bl_fe* `v', robust
    quietly test `v'
    balstar `=r(p)'
    local brk_`v' "`r(s)'"
}
* (b) joint regression -> coefficients, SEs, plain stars, F-test, N
quietly reg t_mw_fac_hi bl_fe* `bcov', robust
foreach v of local bcov {
    local b_`v'  = _b[`v']
    local se_`v' = _se[`v']
    quietly test `v'
    balstar `=r(p)'
    local st_`v' "`r(s)'"
}
quietly testparm `bcov'
local Fj = r(F)
local pj = r(p)
* No control-mean row: the outcome is mw_fac_hi*orig_treatment, which is zero
* for every control by construction, so the row could only ever print 0.00.
quietly count if e(sample)==1
local Nb = r(N)

file open T using "$OUT\balance_samples_higlow_edt.tex", write replace
file write T "\begin{tabular}{l*{1}{c}}" _n "\toprule" _n
file write T "            &\multicolumn{1}{c}{Treatment $\times$ High wage firm}\\" _n
file write T "            &\multicolumn{1}{c}{(1)}\\" _n
file write T "\midrule" _n
local firstrow = 1
foreach v of local bcov {
    sigfmt `b_`v''
    local bb "`r(s)'"
    sigfmt `se_`v''
    local ss "`r(s)'"
    local bk ""
    if "`brk_`v''" != "" local bk "[`brk_`v'']"
    if !`firstrow' file write T "\addlinespace" _n
    local firstrow = 0
    file write T "`lab_`v'' & `bb'`st_`v''`bk' \\" _n
    file write T " & (`ss') \\" _n
}
file write T "\midrule" _n
file write T "\(F\)-statistic & " (strtrim(string(`Fj', "%9.2f"))) " \\" _n
file write T "P-value \(F\)-test & " (strtrim(string(`pj', "%9.3f"))) " \\" _n
file write T "N & " (strtrim(string(`Nb', "%9.0fc"))) " \\" _n
file write T "\bottomrule" _n "\end{tabular}" _n
file close T
di as result "  balance_samples_higlow_edt done (plain + bracketed one-at-a-time stars)"

* ---- fact_des_mw_fac_hi: factory characteristics by firm wage ----
* FU_6th_norest already carries the factory-ownership vars (Asian/American/
* Ethiopian/share_w/prodyear) from a saved working_conditions.do run. Only
* no_conf_f may need deriving (from conf_f1 or the conflicts var in factories.dta).
use "$CRE\FU_slim.dta", clear
capture confirm variable Asian
if _rc==0 {
    capture confirm variable no_conf_f
    if _rc {
        capture confirm variable conf_f1
        if _rc==0 rename conf_f1 no_conf_f
        else {
            capture confirm variable havetherebeenanyconflictsrelated
            if _rc merge m:1 factory1 using "$CRE\factories.dta", ///
                keepusing(havetherebeenanyconflictsrelated) keep(master match) nogen
            capture tab havetherebeenanyconflictsrelated, gen(conf_f)
            capture rename conf_f1 no_conf_f
        }
    }
    estimates drop _all
    estpost summarize Asian American Ethiopian no_conf_f share_w prodyear if mw_fac_hi!=.
    eststo fd_all
    estpost summarize Asian American Ethiopian no_conf_f share_w prodyear if mw_fac_hi==1
    eststo fd_hi
    estpost summarize Asian American Ethiopian no_conf_f share_w prodyear if mw_fac_hi==0
    eststo fd_lo
    esttab fd_all fd_hi fd_lo using "$OUT\fact_des_mw_fac_hi.tex", replace style(tex) booktabs ///
        cells("mean(fmt(2)) sd(fmt(2) par)") nonotes nomtitles ///
        mgroups("All" "High wage firm" "Low wage firm", pattern(1 1 1) ///
                prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
        varlabels(no_conf_f "No conflicts" share_w "Share female workers" prodyear "Production start year")
    di as result "fact_des_mw_fac_hi done"
}
else di as error "factory-characteristic vars not found in FU_slim (unexpected)"
di as result "H. descriptives done"
}
}


*==============================================================================
* E. CONTRACEPTION, ASPIRATIONS, WORK-CHILD KM, WAGE-KM PANELS, HISTOGRAM,
*    INCOME-QUINTILE BAR CHARTS  (dataset: FU_slim.dta)
*   Portable re-implementations of do/contracep_table.do,
*   do/aspirations_combined.do, fertility_results.do (aspirations by parity,
*   work_child, hist_months), do/km_workchild_combined.do, do/add_hetero.do
*   (cb_* bar charts), and the by-firm-wage KM panels. Each writes its
*   file/figure to $OUT.  Contraceptive-use indicators (use_w2..w7) and the
*   aspiration variables (asp_*) are pre-merged into FU_slim by the release build.
*==============================================================================
if $combined {
capture noisily {

* ---- contraception_use_w2w7 (A.11): ITT on "uses any method", waves 2-7 ----
* use_w7 comes from the endline item L29, whose value label lists Yes before No
* (reversed vs W2-W6); the release build decodes all waves by label text.
use "$CRE\FU_slim.dta", clear
estimates drop _all
local k = 2
foreach v in use_w2 use_w3 use_w4 use_w5 use_w6 use_w7 {
    quietly pdslasso `v' orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    estadd local Wave "W`k'"
    quietly su `v' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo c_`v'
    local ++k
}
#delimit ;
esttab c_use_w2 c_use_w3 c_use_w4 c_use_w5 c_use_w6 c_use_w7
    using "$OUT/contraception_use_w2w7.tex",
    style(tex) booktabs
    stats(mean_depvar_c Controls Wave N, labels("Control mean" "Controls" "Wave" "N") fmt(2 0 0 %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes
    nomtitles nonumbers
    keep(orig_treatment) order(orig_treatment)
    varlabels(orig_treatment "Treatment")
    prehead("\begin{tabular}{l*{6}{c}}" "\toprule"
            " & \multicolumn{6}{c}{Uses any method} \\"
            "\cmidrule(lr){2-7}"
            " & (1) & (2) & (3) & (4) & (5) & (6) \\")
    posthead("\midrule")
    postfoot("\bottomrule" "\end{tabular}")
    replace ;
#delimit cr
di as result "  contraception_use_w2w7 done"

* ---- Aspirations_combined: daughters (Panel A) + sons (Panel B), file writer --
use "$CRE\FU_slim.dta", clear
foreach var in asp_eduyears_d asp_age_marry_d asp_imp_earn_own_d asp_nrch_d asp_eduyears_s asp_nrch_s {
    quietly pdslasso `var' orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
    scalar b_`var'  = _b[orig_treatment]
    scalar se_`var' = _se[orig_treatment]
    quietly su `var' if e(sample)==1 & orig_treatment==0
    scalar m_`var' = r(mean)
    quietly count if e(sample)==1
    scalar n_`var' = r(N)
}
capture program drop aspstar
program define aspstar, rclass
    args b se
    local p = 2*(1-normal(abs(`b'/`se')))
    local s ""
    if `p'<0.10 local s "*"
    if `p'<0.05 local s "**"
    if `p'<0.01 local s "***"
    return local star "`s'"
end
file open T using "$OUT/Aspirations_combined.tex", write replace
file write T "\begin{tabular}{l*{4}{c}}" _n "\toprule" _n
file write T "            &\multicolumn{1}{c}{\shortstack{Education\\years}}&\multicolumn{1}{c}{\shortstack{Age of\\marriage}}&\multicolumn{1}{c}{\shortstack{Importance of\\own earnings}}&\multicolumn{1}{c}{\shortstack{Number of\\children}}\\" _n
file write T "            &\multicolumn{1}{c}{(1)}&\multicolumn{1}{c}{(2)}&\multicolumn{1}{c}{(3)}&\multicolumn{1}{c}{(4)}\\" _n
file write T "\midrule" _n
file write T "\multicolumn{5}{l}{\textbf{Panel A. Aspirations for daughters}} \\" _n
file write T "Treatment"
foreach v in asp_eduyears_d asp_age_marry_d asp_imp_earn_own_d asp_nrch_d {
    aspstar `=b_`v'' `=se_`v''
    local st "`r(star)'"
    sigfmt `=b_`v''
    local bb "`r(s)'"
    file write T " & `bb'`st'"
}
file write T " \\" _n "          "
foreach v in asp_eduyears_d asp_age_marry_d asp_imp_earn_own_d asp_nrch_d {
    sigfmt `=se_`v''
    local ss "`r(s)'"
    file write T " & (`ss')"
}
file write T " \\" _n "\midrule" _n "Control mean"
foreach v in asp_eduyears_d asp_age_marry_d asp_imp_earn_own_d asp_nrch_d {
    local mm = strtrim(string(m_`v', "%9.2f"))
    file write T " & `mm'"
}
file write T " \\" _n "N"
foreach v in asp_eduyears_d asp_age_marry_d asp_imp_earn_own_d asp_nrch_d {
    local nn = strtrim(string(n_`v', "%9.0fc"))
    file write T " & `nn'"
}
file write T " \\" _n "\midrule" _n
file write T "\multicolumn{5}{l}{\textbf{Panel B. Aspirations for sons}} \\" _n
aspstar `=b_asp_eduyears_s' `=se_asp_eduyears_s'
local st1 "`r(star)'"
aspstar `=b_asp_nrch_s' `=se_asp_nrch_s'
local st4 "`r(star)'"
sigfmt `=b_asp_eduyears_s'
    local b1 "`r(s)'"
sigfmt `=b_asp_nrch_s'
    local b4 "`r(s)'"
sigfmt `=se_asp_eduyears_s'
    local s1 "`r(s)'"
sigfmt `=se_asp_nrch_s'
    local s4 "`r(s)'"
local m1 = strtrim(string(m_asp_eduyears_s,  "%9.2f"))
local m4 = strtrim(string(m_asp_nrch_s,      "%9.2f"))
local n1 = strtrim(string(n_asp_eduyears_s,  "%9.0fc"))
local n4 = strtrim(string(n_asp_nrch_s,      "%9.0fc"))
file write T "Treatment & `b1'`st1' &  &  & `b4'`st4' \\" _n
file write T "           & (`s1') &  &  & (`s4') \\" _n
file write T "\midrule" _n
file write T "Control mean & `m1' &  &  & `m4' \\" _n
file write T "N & `n1' &  &  & `n4' \\" _n
file write T "\bottomrule" _n "\end{tabular}" _n
file close T
di as result "  Aspirations_combined done"

* ---- Aspirations_daughters_by_motherhood_stacked: Panel A non-mothers / B mothers
use "$CRE\FU_slim.dta", clear
estimates drop _all
foreach var in asp_eduyears_d asp_age_marry_d asp_imp_earn_own_d asp_nrch_d {
    pdslasso `var' orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo A_`var'
}
#delimit ;
esttab A_asp_eduyears_d A_asp_age_marry_d A_asp_imp_earn_own_d A_asp_nrch_d
    using "$OUT/Aspirations_daughters_by_motherhood_stacked.tex", style(tex) booktabs
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes
    nomtitles nonumbers
    keep(orig_treatment) order(orig_treatment) varlabels(orig_treatment "Treatment")
    prehead("\begin{tabular}{l*{4}{c}}" "\toprule"
            " & \shortstack{Education\\years} & \shortstack{Age of\\marriage} & \shortstack{Importance of\\own earnings} & \shortstack{Number of\\children} \\"
            " & (1) & (2) & (3) & (4) \\"
            "\midrule"
            "\multicolumn{5}{l}{\textbf{Panel A. Non-mothers at baseline}}\\")
    posthead("") postfoot("") replace ;
#delimit cr
estimates drop _all
foreach var in asp_eduyears_d asp_age_marry_d asp_imp_earn_own_d asp_nrch_d {
    pdslasso `var' orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==1, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo B_`var'
}
#delimit ;
esttab B_asp_eduyears_d B_asp_age_marry_d B_asp_imp_earn_own_d B_asp_nrch_d
    using "$OUT/Aspirations_daughters_by_motherhood_stacked.tex", style(tex) booktabs
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes
    nomtitles nonumbers
    keep(orig_treatment) order(orig_treatment) varlabels(orig_treatment "Treatment")
    prehead("\midrule" "\multicolumn{5}{l}{\textbf{Panel B. Mothers at baseline}}\\")
    posthead("") postfoot("\bottomrule" "\end{tabular}") append ;
#delimit cr

* ---- Aspirations_sons_by_motherhood_stacked: Panel A non-mothers / B mothers ---
estimates drop _all
foreach var in asp_eduyears_s asp_nrch_s {
    pdslasso `var' orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo A_`var'
}
#delimit ;
esttab A_asp_eduyears_s A_asp_nrch_s
    using "$OUT/Aspirations_sons_by_motherhood_stacked.tex", style(tex) booktabs
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes
    nomtitles nonumbers
    keep(orig_treatment) order(orig_treatment) varlabels(orig_treatment "Treatment")
    prehead("\begin{tabular}{l*{2}{c}}" "\toprule"
            " & \shortstack{Education\\years} & \shortstack{Number of\\children} \\"
            " & (1) & (2) \\"
            "\midrule"
            "\multicolumn{3}{l}{\textbf{Panel A. Non-mothers at baseline}}\\")
    posthead("") postfoot("") replace ;
#delimit cr
estimates drop _all
foreach var in asp_eduyears_s asp_nrch_s {
    pdslasso `var' orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==1, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo B_`var'
}
#delimit ;
esttab B_asp_eduyears_s B_asp_nrch_s
    using "$OUT/Aspirations_sons_by_motherhood_stacked.tex", style(tex) booktabs
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nonotes
    nomtitles nonumbers
    keep(orig_treatment) order(orig_treatment) varlabels(orig_treatment "Treatment")
    prehead("\midrule" "\multicolumn{3}{l}{\textbf{Panel B. Mothers at baseline}}\\")
    posthead("") postfoot("\bottomrule" "\end{tabular}") append ;
#delimit cr
di as result "  Aspirations by motherhood done"

* ---- KM_workchild_combined: can/cannot combine work+childcare, non-mothers -----
use "$CRE\FU_slim.dta", clear
stset km_duration, failure(km_event)
capture drop wchild_bin
gen byte wchild_bin = .
replace wchild_bin = 1 if inlist(K1_53, 1, 2)
replace wchild_bin = 0 if K1_53 == 3
local grey xline(0 1 2 3 4 5 6 7 8 10 11 12 13 14 15, lcolor(gs14))
sts graph if wchild_bin == 1 & any_child_w1nr == 0, by(orig_treatment) survival ///
    title("") subtitle("Panel A. Can combine work and childcare") ///
    legend(order(1 "Control" 2 "Treatment")) ///
    `grey' xline(9, lcolor(purple%50)) xline(15, lcolor(black%50)) ///
    xtitle("Months since treatment") name(wcA, replace)
graph save "$OUT\wcA.gph", replace
graph export "$OUT\Figure_workchild_a.pdf", replace
sts graph if wchild_bin == 0 & any_child_w1nr == 0, by(orig_treatment) survival ///
    title("") subtitle("Panel B. Cannot combine work and childcare") ///
    legend(order(1 "Control" 2 "Treatment")) ///
    `grey' xline(9, lcolor(purple%50)) xline(15, lcolor(black%50)) ///
    xtitle("Months since treatment") name(wcB, replace)
graph save "$OUT\wcB.gph", replace
graph export "$OUT\Figure_workchild_b.pdf", replace
graph combine "$OUT\wcA.gph" "$OUT\wcB.gph", col(1) xsize(6.5) ysize(9) ///
    graphregion(color(white)) plotregion(color(white)) name(wc_comb, replace)
graph export "$OUT\KM_workchild_combined.pdf", replace
di as result "  KM_workchild_combined done"

* ---- KM_months_all_mw_fac_hi / _lo: duration KM by firm wage (single panels) ---
use "$CRE\FU_slim.dta", clear
stset km_duration, failure(km_event)
sts graph if mw_fac_hi==1, by(orig_treatment) survival title("") ///
    subtitle("High-wage firms") legend(order(1 "Control" 2 "Treatment")) ///
    xline(9, lcolor(purple%50)) xline(35, lcolor(black%50)) ///
    xtitle("Months Since Treatment") name(kmwhi, replace)
graph export "$OUT\KM_months_all_mw_fac_hi.pdf", replace
sts graph if mw_fac_hi==0, by(orig_treatment) survival title("") ///
    subtitle("Low-wage firms") legend(order(1 "Control" 2 "Treatment")) ///
    xline(9, lcolor(purple%50)) ///
    xtitle("Months Since Treatment") name(kmwlo, replace)
graph export "$OUT\KM_months_all_mw_fac_lo.pdf", replace
di as result "  KM_months_all_mw_fac_hi/lo done"

* ---- hist_months_tc_binning: histogram of months worked, treated vs control ----
use "$CRE\FU_slim.dta", clear
gen mw_bin = .
replace mw_bin = 0 if months_worked==0
forvalues b = 1/12 {
    replace mw_bin = `b' if inrange(months_worked, (`b'-1)*10+1, `b'*10)
}
label define mw_bins 0 "0" 1 "1–10" 2 "11–20" 3 "21–30" 4 "31–40" ///
                     5 "41–50" 6 "51–60" 7 "61–70" 8 "71–80" ///
                     9 "81–90" 10 "91–100" 11 "101–110" 12 "111–120"
label values mw_bin mw_bins
twoway ///
 (hist mw_bin if orig_treatment==1, discrete frac color(red%30)  lcolor(red)) ///
 (hist mw_bin if orig_treatment==0, discrete frac color(blue%30) lcolor(blue)) ///
 , xtitle("Number of months worked (10-month bins)") ytitle("Share of women") ///
 xlabel(, valuelabel angle(45)) ///
 legend(order(1 "Treated" 2 "Control") pos(3)) xlabel(0(1)11, grid)
graph export "$OUT\hist_months_tc_binning.pdf", replace
di as result "  hist_months_tc_binning done"

* ---- work_child: ability to work with a newborn (baseline K1_53 distribution) --
use "$CRE\FU_slim.dta", clear
keep if K1_53 != .
contract K1_53
egen total = total(_freq)
gen percent = 100 * _freq / total
graph hbar (asis) percent, over(K1_53, sort(1) descending label) ///
    blabel(bar, format(%4.1f) size(small)) bar(1, color(blue)) ///
    ytitle("Percent") title("Ability to work in a year if newborn next month") legend(off)
graph export "$OUT\work_child.pdf", replace
di as result "  work_child done"

* ---- cb_*: income-quintile bar charts (any child / number, all / non-mothers) --
use "$CRE\FU_slim.dta", clear
xtile hhinc_q = base_hhinc6 if base_hhinc6<., nq(5)
label define hhinc_q 1 "Q1 (lowest)" 2 "Q2" 3 "Q3" 4 "Q4" 5 "Q5 (highest)"
label values hhinc_q hhinc_q
capture noisily {
    cibar any_child, over1(orig_treatment) over2(hhinc_q) ///
        graphopts(ytitle("Any children? (1=Yes)") yscale(range(0 1)) ylabel(0 0.7 0.8 0.9 1)) bargap(5)
    graph export "$OUT\cb_any_hhinc_q_all.pdf", replace
    cibar any_child if any_child_w1nr==0, over1(orig_treatment) over2(hhinc_q) ///
        graphopts(ytitle("Any children? (1=Yes)") yscale(range(0 1)) ylabel(0 0.7 0.8 0.9 1)) bargap(5)
    graph export "$OUT\cb_any_hhinc_q_nm.pdf", replace
    cibar Ab08, over1(orig_treatment) over2(hhinc_q) ///
        graphopts(ytitle("Number of children") yscale(range(0 4)) ylabel(0 1 2 3 4)) bargap(5)
    graph export "$OUT\cb_nr_hhinc_q_all.pdf", replace
    cibar Ab08 if any_child_w1nr==0, over1(orig_treatment) over2(hhinc_q) ///
        graphopts(ytitle("Number of children") yscale(range(0 4)) ylabel(0 1 2 3 4)) bargap(5)
    graph export "$OUT\cb_nr_hhinc_q_nm.pdf", replace
    di as result "  cb_* income-quintile bar charts done"
}

* ---- work_hhdut: difficulty combining factory work and household duties -------
use "$CRE\FU_slim.dta", clear
keep if K1_12C != .
local origlabel : value label K1_12C
contract K1_12C
egen total = total(_freq)
gen percent = 100 * _freq / total
label values K1_12C `origlabel'
graph hbar (asis) percent, over(K1_12C, sort(1) descending label) ///
    blabel(bar, format(%4.1f) size(small)) bar(1, color(blue)) ///
    ytitle("Percent") title("Difficulty combining job at firm X and household duties") legend(off)
graph export "$OUT\work_hhdut.pdf", replace
di as result "  work_hhdut done"
* (fert_des_new_fert_ed_edt is Table 1, reproduced in replication_main.do)

* ---- Itt_samples_combined: ITT by tracking sample, col 4 = phone-vs-FTF IPW ----
* Producer: do/Itt_samples_with_ipw.do. Cols: full Wave 7 | in-person | phone |
* IPW. The IPW is a phone-vs-face-to-face inverse-probability weight computed
* entirely within the Wave-7 sample (stage-1 LPM of "interviewed by phone" on
* baseline age and number of children, by arm), so no external tracking file is
* needed. Interview_Type (1 = in person, 0 = phone) is carried in FU_slim.
use "$CRE\FU_slim.dta", clear
estimates drop _all
foreach var of varlist any_child Ab08 {
    pdslasso `var' orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    estadd local Sample "Wave 7"
    eststo `var'_w7
    pdslasso `var' orig_treatment (i.em* m_* bl_fe*) if Interview_Type==1, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    estadd local Sample "W7 not phone"
    eststo `var'_np
    pdslasso `var' orig_treatment (i.em* m_* bl_fe*) if Interview_Type==0, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    estadd local Sample "W7 phone"
    eststo `var'_p
}
* phone-vs-FTF IPW (within the 1,130 Wave-7 interviewees)
use "$CRE\FU_slim.dta", clear
keep if !missing(any_child)
gen byte hard_R = (Interview_Type == 0)
local x1 base_age base_B11
gen double phat_phone = .
foreach a in 0 1 {
    capture regress hard_R `x1' if orig_treatment == `a'
    if _rc {
        quietly summ hard_R if orig_treatment == `a'
        replace phat_phone = r(mean) if orig_treatment == `a'
    }
    else {
        capture predict double phat_phone_arm_`a' if e(sample), xb
        if _rc {
            quietly summ hard_R if orig_treatment == `a'
            replace phat_phone = r(mean) if orig_treatment == `a' & missing(phat_phone)
        }
        else replace phat_phone = phat_phone_arm_`a' if orig_treatment == `a' & missing(phat_phone)
    }
}
quietly summ phat_phone if hard_R == 1, detail
local pf = max(r(p1), 0.05)
gen double ipw_mm = .
replace    ipw_mm = 1              if hard_R == 0
replace    ipw_mm = 1/phat_phone   if hard_R == 1
replace    ipw_mm = 1/`pf'         if hard_R == 1 & phat_phone < `pf' & phat_phone < .
foreach var of varlist any_child Ab08 {
    pdslasso `var' orig_treatment (i.em* m_* bl_fe*) [pw=ipw_mm] if !missing(ipw_mm), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' [aw=ipw_mm] if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    estadd local Sample "Wave 7"
    eststo `var'_ipw
}
#delimit ;
esttab any_child_w7 any_child_np any_child_p any_child_ipw
    using "$OUT/Itt_samples_combined.tex",
    style(tex) booktabs fragment
    stats(mean_depvar_c Sample Controls N, labels("Control mean" "Sample" "Controls" "N") fmt(2 0 0 %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes
    nomtitles nonumbers
    keep(orig_treatment) order(orig_treatment) varlabels(orig_treatment "Treatment")
    prehead("\begin{tabular}{l*{4}{c}}" "\toprule"
            " & \shortstack{Full\\Wave 7} & \shortstack{In\\person} & Phone & IPW \\"
            " & (1) & (2) & (3) & (4) \\"
            "\midrule"
            "\multicolumn{5}{l}{\textbf{Panel A. Any children}}\\")
    posthead("") postfoot("") replace ;
esttab Ab08_w7 Ab08_np Ab08_p Ab08_ipw
    using "$OUT/Itt_samples_combined.tex",
    style(tex) booktabs fragment append
    stats(mean_depvar_c Sample Controls N, labels("Control mean" "Sample" "Controls" "N") fmt(2 0 0 %9.0fc))
    starlevels(* 0.10 ** 0.05 *** 0.01) b(3) se(3) nonotes
    nomtitles nonumbers
    keep(orig_treatment) order(orig_treatment) varlabels(orig_treatment "Treatment")
    prehead("\midrule" "\multicolumn{5}{l}{\textbf{Panel B. Number of children}}\\")
    posthead("") postfoot("\bottomrule" "\end{tabular}") ;
#delimit cr
di as result "  Itt_samples_combined done"

di as result "E. contraception/aspirations/work-child/wage-KM/histogram/bar-charts done"
}
}


*==============================================================================
* I. APPENDIX TABLE A.6.  IV with cumulative employment measures   (IV_combined)
*   Moved from replication_main.do (it was Table 4 until the Wave-2 IV replaced it).
*   Dataset: FU_slim.dta.  Panel A any_child, Panel B Ab08.
*   Cols: (1) FS any-month (2) OLS (3) IV (4) FS months (5) OLS (6) IV.
*   (Any-month block first, then months worked; both employment measures share
*    one "Employment" row, house template.)
*   First-stage F reported (squared t-ratio on treatment) as in the paper.
*   EXPECT Panel A IV: any-month col3 0.19**, months col6 0.0054**; F 64 / 25.
*          Panel B IV: any-month col3 0.72**, months col6 0.020**.
*==============================================================================
if $iv_alt {
capture noisily {
use "$CRE\FU_slim.dta", clear
estimates drop _all
pdslasso months_worked orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su months_worked if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd scalar Fstat = (_b[orig_treatment]/_se[orig_treatment])^2
eststo first
pdslasso any_work_month orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su any_work_month if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd scalar Fstat = (_b[orig_treatment]/_se[orig_treatment])^2
eststo first_b
foreach var of varlist Ab08 any_child {
    pdslasso `var' months_worked (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo OLS_`var'
    pdslasso `var' any_work_month (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo OLS_`var'_b
    ivlasso `var' (months_worked=orig_treatment) (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo IV_`var'
    ivlasso `var' (any_work_month=orig_treatment) (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo IV_`var'_b
}
* Both employment measures share one "Employment" row (rename() merges them);
* any-month block in cols 1-3, months-worked block in cols 4-6.
local vlist employment orig_treatment
local vlab varlabels(employment "Employment" orig_treatment "Treatment")
local vren rename(months_worked employment any_work_month employment)
local sts stats(mean_depvar_c Fstat Controls N, labels("Control mean" "\(F\)-statistic" "Controls" "N") fmt(2 0 0 %9.0fc))
#delimit ;
esttab first_b OLS_any_child_b IV_any_child_b first OLS_any_child IV_any_child
    using "$OUT\IV_combined.tex",
    replace style(tex) booktabs fragment `sts' starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se
    nomtitles nonumbers `vren' keep(`vlist') order(`vlist') `vlab'
    prehead("\begin{tabular}{l*{6}{c}}" "\toprule"
            " & \multicolumn{3}{c}{Employment = worked $\geq$ 1 month} & \multicolumn{3}{c}{Employment = months worked} \\"
            "\cmidrule(lr){2-4}\cmidrule(lr){5-7}"
            " & First stage & OLS & IV & First stage & OLS & IV \\"
            " & (1) & (2) & (3) & (4) & (5) & (6) \\"
            "\midrule"
            "\multicolumn{7}{l}{\textbf{Panel A. Any children}}\\")
    posthead("") postfoot("") ;
esttab first_b OLS_Ab08_b IV_Ab08_b first OLS_Ab08 IV_Ab08
    using "$OUT\IV_combined.tex",
    append style(tex) booktabs fragment `sts' starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se
    nomtitles nonumbers `vren' keep(`vlist') order(`vlist') `vlab'
    prehead("\midrule" "\multicolumn{7}{l}{\textbf{Panel B. Number of children}}\\")
    posthead("") postfoot("\bottomrule" "\end{tabular}") ;
#delimit cr
di as result "I. IV_combined done"
}
}


*==============================================================================
* J. FIGURE: ITT BY REGION, ordered by endline control share with any children
*    (bread_effects_by_park_ordered.pdf; producers do/bread_BC_hetero_park.do C1
*     + do/bread_H_region_figure.do)
*   Dataset: FU_slim.dta (region = industrial-park region, 5 categories).
*   Each bar is a separate main-spec pdslasso on one region; caps are 95% CIs;
*   the dashed line is the pooled estimate. The original figure hard-coded the
*   control shares, Ns and pooled estimates; here they are computed.
*   EXPECT order/control share: Oromia 0.78, Tigray 0.82, Amhara 0.94,
*     Dire Dawa 0.97, SNNP 0.99; N 22/542/60/230/276 (full), 17/232/20/27/54 (NM).
*==============================================================================
if $region {
capture noisily {
use "$CRE\FU_slim.dta", clear
tempname RG
tempfile rgres
postfile `RG' str12 unit str12 outcome str12 msample double b se long nobs double cmean ///
    using `rgres', replace
quietly levelsof region, local(regs)
foreach y in any_child Ab08 {
    foreach s in All Nonmothers {
        if "`s'"=="All"        local cond "1"
        if "`s'"=="Nonmothers" local cond "any_child_w1nr==0"
        * pooled estimate (red dashed line)
        quietly pdslasso `y' orig_treatment (i.em* m_* bl_fe*) if `cond', partial(bl_fe*) robust
        local pool_`y'_`s' = _b[orig_treatment]
        foreach r of local regs {
            local rname : label (region) `r'
            quietly pdslasso `y' orig_treatment (i.em* m_* bl_fe*) if (`cond') & region==`r', partial(bl_fe*) robust
            local b  = _b[orig_treatment]
            local se = _se[orig_treatment]
            quietly count if e(sample)
            local n = r(N)
            quietly su `y' if e(sample) & orig_treatment==0
            post `RG' ("`rname'") ("`y'") ("`s'") (`b') (`se') (`n') (r(mean))
            di as result "REGION `y' `s' `rname': b=" %8.4f `b' " se=" %7.4f `se' " N=" `n' " cm=" %6.3f r(mean)
        }
    }
}
postclose `RG'

use `rgres', clear
gen lo = b - 1.96*se
gen hi = b + 1.96*se
* order regions by the full-sample control share with any children
gen cshare = cmean if outcome=="any_child" & msample=="All"
bysort unit (cshare): replace cshare = cshare[1]
egen byte x = group(cshare unit)
* x-axis labels "Region (share)" and the N note, in plotted order
local xl ""
local nfull ""
local nnm ""
forvalues i = 1/5 {
    quietly levelsof unit if x==`i', local(u) clean
    quietly su cshare if x==`i'
    local sh : di %4.2f r(mean)
    local xl `xl' `i' "`u' (`sh')"
    if `i'>1 local nfull "`nfull', "
    if `i'>1 local nnm "`nnm' / "
    quietly su nobs if x==`i' & outcome=="any_child" & msample=="All"
    local nfull "`nfull'`u' `=r(mean)'"
    quietly su nobs if x==`i' & outcome=="any_child" & msample=="Nonmothers"
    local nnm "`nnm'`=r(mean)'"
}
label define xl `xl', replace
label values x xl
foreach y in any_child Ab08 {
    foreach s in All Nonmothers {
        local pool = `pool_`y'_`s''
        local ttl = cond("`y'"=="any_child","Any children","Number of children")
        local sl  = cond("`s'"=="All","full sample","baseline non-mothers")
        preserve
        keep if outcome=="`y'" & msample=="`s'"
        twoway (bar b x, barwidth(0.6) color(navy%60)) ///
               (rcap lo hi x, lcolor(navy) lwidth(medium)), ///
               xlabel(1(1)5, valuelabel angle(30) labsize(small)) xtitle("") ///
               ytitle("ITT", size(small)) yline(0, lcolor(black) lwidth(thin)) ///
               yline(`pool', lcolor(cranberry) lpattern(dash)) ///
               title("`ttl' -- `sl'", size(medsmall)) legend(off) ///
               graphregion(color(white)) plotregion(color(white)) name(g_`y'_`s', replace)
        graph save "$OUT\_rb_`y'_`s'.gph", replace
        restore
    }
}
graph combine "$OUT\_rb_any_child_All.gph" "$OUT\_rb_any_child_Nonmothers.gph" ///
              "$OUT\_rb_Ab08_All.gph" "$OUT\_rb_Ab08_Nonmothers.gph", ///
              cols(2) graphregion(color(white)) xsize(9) ysize(7) ///
              note("Regions ordered by control-group share with any children at endline (in parentheses). Bars: ITT; caps: 95% CI; red dashed: pooled estimate. N per region: `nfull' (full); `nnm' (non-mothers).", size(vsmall))
graph export "$OUT\bread_effects_by_park_ordered.pdf", replace
foreach f in any_child_All any_child_Nonmothers Ab08_All Ab08_Nonmothers {
    capture erase "$OUT\_rb_`f'.gph"
}
di as result "J. bread_effects_by_park_ordered done"
}
}


*==============================================================================
* F. DHS 2016 SUMMARY-STATS COMPARISON  (DHS_compare_stars_2016) + FIGURE A.1 (panels a-c)
*   RCT baseline vs married, urban, 18-30 EDHS-2016 women living within 50 km of
*   the five industrial parks. The RCT column comes from FU_slim; the DHS column
*   needs the EDHS-2016 data, which DHS terms forbid us from redistributing.
*
*   The five park coordinates ARE shipped (data/DHS/industrial_park_coordinates.csv);
*   respondent GPS is never shipped. The near-park flag is built here from those
*   coordinates and the DHS cluster-GPS file (great-circle distance <= 50 km),
*   exactly as the paper does. To run this block a replicator supplies, under
*   $DHS:  (1) the 2016 Individual Recode  ETIR71/Ethiopia_women_2016.DTA;
*          (2) the 2016 GPS cluster export  etge7_clusters.csv  (columns
*              DHSCLUST, LATNUM, LONGNUM, exported from the EDHS-2016 GE shapefile).
*   Free download: https://dhsprogram.com/data/ . If either file is absent the
*   block skips with a message. Set $dhs=1 once the files are in place.
*==============================================================================
if $dhs {
capture noisily {
local dhs_ir  "$DHS\Ethiopia_women_2016.DTA"
local dhs_gps "$DHS\etge7_clusters.csv"
capture confirm file "`dhs_ir'"
local rc_ir = _rc
capture confirm file "`dhs_gps'"
local rc_gps = _rc
if `rc_ir' | `rc_gps' {
    di as text "SKIP Table DHS_compare_stars_2016: need `dhs_ir' and `dhs_gps'. See README."
}
else {
    * park coordinates (shipped) -> five (lat,lon) macros
    import delimited using "$DHS\industrial_park_coordinates.csv", clear varnames(1) case(preserve)
    local NP = _N
    forvalues p = 1/`NP' {
        local lat`p' = latitude[`p']
        local lon`p' = longitude[`p']
    }
    * DHS-2016 cluster GPS -> within-50km flag (great-circle / haversine)
    import delimited using "`dhs_gps'", clear case(preserve)
    drop if missing(LATNUM) | LATNUM==0
    forvalues p = 1/`NP' {
        gen double _d`p' = 2*6371*asin(sqrt( sin(((`lat`p''-LATNUM)*_pi/180)/2)^2 + ///
            cos(LATNUM*_pi/180)*cos(`lat`p''*_pi/180)*sin(((`lon`p''-LONGNUM)*_pi/180)/2)^2 ))
    }
    egen double mindist_km = rowmin(_d*)
    gen byte within50 = mindist_km <= 50
    rename DHSCLUST v001
    keep v001 within50
    tempfile buf16
    save `buf16'
    * DHS-2016 near-park sample: married, urban, 18-30
    use v001 v005 v012 v025 v130 v133 v201 v501 v613 v621 v714 v719 v741 using "`dhs_ir'", clear
    merge m:1 v001 using `buf16', keep(match) nogen
    keep if within50==1
    gen byte married = inlist(v501,1,2)
    keep if married & inrange(v012,18,30) & v025==1
    gen byte atleast1bth = v201>0
    gen cheb2 = v201
    gen byte husbwantsmore = v621==2
    gen idealkid = v613
    replace idealkid = . if idealkid>=95
    gen wagejob2 = .
    replace wagejob2 = 1 if v719==2 & v741==1
    recode wagejob2 (.=0) if v714!=.
    gen age2 = v012
    gen byte muslim = v130==4
    gen byte protestant = v130==3
    gen edyrtotal2 = v133
    replace edyrtotal2 = . if edyrtotal2>30
    matrix D16 = J(9,2,.)
    local i = 1
    foreach v in atleast1bth cheb2 husbwantsmore idealkid wagejob2 age2 muslim protestant edyrtotal2 {
        quietly mean `v' [pw=v005]
        matrix D16[`i',1] = _b[`v']
        matrix D16[`i',2] = _se[`v']
        local ++i
    }
    local ND = e(N)
    * RCT baseline means (FU_slim, Wave-7 estimation sample)
    use "$CRE\FU_slim.dta", clear
    keep if !missing(Ab08)
    local rctvars base_any_child base_B11 base_partner_w_more_ch base_wanted_nrch base_K1 base_age base_Muslim base_Protestant base_edu_yrs
    matrix R = J(9,2,.)
    local i = 1
    foreach v of local rctvars {
        quietly mean `v'
        matrix R[`i',1] = _b[`v']
        matrix R[`i',2] = _se[`v']
        local ++i
    }
    local NR = e(N)
    * write the 3-column table with starred differences (DHS minus RCT)
    local lab1 "Any children"
    local lab2 "Number of children"
    local lab3 "Partner's ideal number of children $>$ woman's own"
    local lab4 "Ideal number of children"
    local lab5 "Share in wage work"
    local lab6 "Age"
    local lab7 "Muslim"
    local lab8 "Protestant"
    local lab9 "Years of education"
    file open T using "$OUT/DHS_compare_stars_2016.tex", write replace
    file write T "\begin{tabular}{lccc}" _n "\toprule" _n
    file write T " & RCT baseline & EDHS 2016 & Diff. \\" _n
    file write T " & (1) & (2) & (3) \\" _n "\midrule" _n
    forvalues i = 1/9 {
        local rb = R[`i',1]
        local db = D16[`i',1]
        local diff = `db' - `rb'
        local se = sqrt(R[`i',2]^2 + D16[`i',2]^2)
        local star ""
        if `se'>0 {
            local z = abs(`diff')/`se'
            local p = 2*(1-normal(`z'))
            if `p'<0.10 local star "*"
            if `p'<0.05 local star "**"
            if `p'<0.01 local star "***"
        }
        file write T "`lab`i'' & " %6.3f (`rb') " & " %6.3f (`db') " & " %6.3f (`diff') "`star' \\" _n
    }
    file write T "\midrule" _n
    file write T "N & " %9.0fc (`NR') " & " %9.0fc (`ND') " &  \\" _n
    file write T "\bottomrule" _n "\end{tabular}" _n
    file close T
    di as result "F. DHS_compare_stars_2016 done"

    * ---- Figure A.1, panels a-c (producer: Fertility_Ethiopia/do/DHS_celine.do) ----
    * Same near-park sample as the table above (married, 18-30, urban, cluster
    * within 50 km of a park; identical, woman by woman, to the original
    * DHS_park_2016 "industrial" flag: 750 women). Variable definitions follow
    * DHS_celine.do. Weighted by v005; cibar 95% CIs; scheme plotplainblind.
    use v001 v005 v012 v102 v201 v212 v501 v511 v605 v613 v714 v719 v741 using "`dhs_ir'", clear
    merge m:1 v001 using `buf16', keep(match) nogen
    keep if within50==1 & inlist(v501,1,2) & inrange(v012,18,30) & v102==1
    gen wants_another = inlist(v605,1,2)
    replace wants_another = . if inlist(v605,6,7) | v605==.
    gen wagejob = .
    replace wagejob = 1 if v719==2 & v741==1
    recode wagejob (.=0) if v714!=.
    label define WAGEWK 0 "not in wage work" 1 "in wage work", modify
    label values wagejob WAGEWK
    gen yrs_1stmar_to_bth = v212 - v511
    recode yrs_1stmar_to_bth (996 = .)
    replace yrs_1stmar_to_bth = . if yrs_1stmar_to_bth < 0
    gen parity2 = v201
    replace parity2 = 2 if v201 >= 2 & v201 != .
    label define PARITY2 0 "0" 1 "1" 2 "2+", modify
    label values parity2 PARITY2
    gen idealkid = v613
    replace idealkid = . if idealkid > 20
    local oldscheme "`c(scheme)'"
    set scheme plotplainblind
    local sub "DHS 2016 sample restricted to 50km buffers around the 5 industrial parks in RCT sample."
    cibar idealkid [w=v005], over(wagejob) graphopts(ylabel(0(1)4) legend(row(1) pos(6)) ///
        title("Ideal number of children, by employment status. Urban married women aged 18-30.", size(small)) ///
        subtitle("`sub'", size(vsmall)) ytitle(ideal number of children))
    graph export "$OUT\figA1_panel_a_idealk_by_wagejob_DHS2016_urban_married_18-30_industrial_parks.png", as(png) width(1932) replace
    cibar wants_another [w=v005], over(wagejob parity2) graphopts(ylabel(0(0.2)1) legend(row(1) pos(6)) ///
        title("Desire for a(nother) child, by parity and employment status. Urban married women aged 18-30.", size(small)) ///
        subtitle("`sub'", size(vsmall)) ytitle("share who want to have a(nother) child"))
    graph export "$OUT\figA1_panel_b_wantsanother_by_parityXwagejob_DHS2016_urban_married_18-30_industrial_parks.png", as(png) width(1932) replace
    cibar yrs_1stmar_to_bth if yrs_1stmar_to_bth>=0 [w=v005], over(wagejob) graphopts(ylabel(0(1)3) legend(row(1) pos(6)) ///
        title("Time from marriage to first birth, by employment status. Urban married women aged 18-30.", size(small)) ///
        subtitle("`sub'", size(vsmall)) ytitle("years between first marriage and first birth"))
    graph export "$OUT\figA1_panel_c_yrsto1stbirth_by_wagejob_DHS2016_urban_married_18-30_industrial_parks.png", as(png) width(1932) replace
    set scheme `oldscheme'
    di as result "F. DHS Figure A.1 panels a-c done"
}
}
}

di as text "replication_appendix.do  finished  $S_DATE $S_TIME"
di as text "Outputs in: $OUT"
log close
