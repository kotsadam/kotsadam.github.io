*==============================================================================
* replication_BD2018.do
*
* Reproduces the Blattman & Dercon (2018) re-analysis in the appendix
* (Table "Heterogeneity in employment effects by baseline marital status",
*  tab:BD2018_mw_nmw):
*   table1_hte_by_married_women.tex  (women only, treatment x married)
*   table2_hte_by_gender_full.tex    (full sample, treatment x female)
*
* DATA (not shipped with this package): ILEanalysis.dta from the public
* replication package of
*   Blattman, C. and S. Dercon (2018), "The Impacts of Industrial and
*   Entrepreneurial Work on Income and Health: Experimental Evidence from
*   Ethiopia", AEJ: Applied Economics 10(3).
* Download their replication archive (AEA / openICPSR), then set $BDDATA
* below to the folder containing data\ILEanalysis.dta and set $bd = 1.
*
* Specification (aligned with their paper):
*   Y_i = a + b1*treated_i + b2*group_i + b3*(treated_i # group_i)
*         + cohort FE + baseline controls + e_i,   robust SEs
*   Sample: baseline row (round_b==1); entrepreneurship arm excluded
*   (treatment_b in {0,1}); group = married_b (T1, women) / female_b (T2, all).
*==============================================================================

clear all
set more off
set linesize 255
version 17

global bd = 0   // set to 1 after downloading the B&D replication data

* --- EDIT THESE TWO LINES ---
global ROOT   "C:\replication"                       // this package's root
global BDDATA "C:\BD2018_replication_package"        // B&D archive root
* ----------------------------

global OUT "$ROOT\output\appendix"

foreach pkg in estout {
    capture which `pkg'
    if _rc ssc install `pkg', replace
}

if $bd {
capture noisily {

set maxvar 10000
use "$BDDATA\data\ILEanalysis.dta", clear

keep if round_b == 1
keep if inlist(treatment_b,0,1)

gen byte treated_t = (treatment_b == 1)
label var treated_t "Assigned to industrial job arm"
global cohort_t "coh1 coh2 coh3 coh4 coh5 coh6 coh7 coh8"
global baseline_t "exactage_p99_b head_b disabled_b educ_p99_b cog_overall_index_b mentalhealth_index_b consc_std_b riskaversion_all_b patience_all_b success_index_b formal_expery_b factory_b optimism_index_b"

* ---- Table 1: women only, treated x married_b ----
preserve
keep if female_b == 1
eststo clear

foreach y in treatdef3 anyfacfarm_m_e facfarm_e {
    quietly regress `y' i.treated_t##i.married_b ${cohort_t} ${baseline_t}, robust
    quietly su `y' if e(sample)==1 & treated_t==0
    estadd scalar cmean = r(mean)
    quietly su married_b if e(sample)==1
    estadd scalar sh_unmar = 1 - r(mean)
    eststo bd_`y'
}

esttab bd_treatdef3 bd_anyfacfarm_m_e bd_facfarm_e using "$OUT\table1_hte_by_married_women.tex", replace ///
    booktabs compress nogaps ///
    se b(%9.3f) se(%9.3f) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(1.treated_t 1.married_b 1.treated_t#1.married_b) ///
    coeflabels(1.treated_t "Treatment" ///
               1.married_b "Married at baseline" ///
               1.treated_t#1.married_b "Treatment $\times$ Married at baseline") ///
    nomtitles nonumbers ///
    prehead("\def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi}" ///
            "\begin{tabular}{l*{3}{c}}" "\toprule" ///
            "          &\multicolumn{1}{c}{(1)}&\multicolumn{1}{c}{(2)}&\multicolumn{1}{c}{(3)}\\" ///
            "          &\multicolumn{1}{c}{\shortstack{Worked in any\\ industrial firm $\geq$30 days}}&\multicolumn{1}{c}{\shortstack{Months worked in\\ industrial firm}}&\multicolumn{1}{c}{\shortstack{In industrial firm\\ at endline}}\\") ///
    posthead("\midrule") postfoot("\bottomrule" "\end{tabular}") ///
    stats(cmean r2 N sh_unmar, fmt(%9.3f %9.3f %9.0f %9.3f) labels("Control mean" "R-squared" "N" "Share unmarried")) ///
    nonotes
restore

* ---- Table 2: full sample, treated x female_b ----
eststo clear
eststo n2a: quietly regress treatdef3      i.treated_t##i.female_b ${cohort_t} ${baseline_t}, robust
eststo n2b: quietly regress anyfacfarm_m_e i.treated_t##i.female_b ${cohort_t} ${baseline_t}, robust
eststo n2c: quietly regress facfarm_e      i.treated_t##i.female_b ${cohort_t} ${baseline_t}, robust

esttab n2a n2b n2c using "$OUT\table2_hte_by_gender_full.tex", replace ///
    booktabs compress nogaps ///
    se b(%9.3f) se(%9.3f) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(1.treated_t 1.female_b 1.treated_t#1.female_b) ///
    coeflabels(1.treated_t "treatment" ///
               1.female_b "female (vs male)" ///
               1.treated_t#1.female_b "treatment x female") ///
    mtitles("Worked in any industrial firm 30+ days" ///
            "Months worked in industrial firm" ///
            "In industrial firm at endline") ///
    stats(N r2, labels("N" "R-squared")) ///
    title("Table 2: HTE by gender (men vs women), full sample")

* ---- numbers quoted in the text (footnote, Sec. 4.1) ----
* "their endline sample was 81% female"
quietly su female_b if e(sample)
di as result "TEXT | Sec 4.1 fn | B&D endline sample share female (draft: 81%) | " %4.1f 100*r(mean) "% (N=" r(N) ")"
* "we did not find differential effects on job tenure by gender"
foreach m in n2a n2b n2c {
    estimates restore `m'
    di as result "TEXT | Sec 4.1 fn | B&D treatment x female, `m' | " %7.3f _b[1.treated_t#1.female_b] " (se " %5.3f _se[1.treated_t#1.female_b] ", p " %5.3f 2*ttail(e(df_r),abs(_b[1.treated_t#1.female_b]/_se[1.treated_t#1.female_b])) ")"
}

di as result "BD2018 done -> table1_hte_by_married_women.tex + table2_hte_by_gender_full.tex"
}
}
else {
    di as error "B&D data not configured: download the Blattman & Dercon (2018) AEJ:Applied replication archive, set BDDATA and bd=1 at the top of this file."
}
