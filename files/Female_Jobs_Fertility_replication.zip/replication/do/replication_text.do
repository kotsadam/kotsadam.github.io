*==============================================================================
* replication_text.do
*   Reproduces the numbers quoted in the TEXT of "Female Jobs and Fertility"
*   that are not reported in any table or figure (sample counts, descriptive
*   shares, survival-model statistics, randomization inference, robustness
*   ranges). Every result is printed to the log on a line starting with
*   "TEXT", followed by the paper location (section / footnote) and the value
*   quoted in the draft of 3 October 2026, so the log can be read against the
*   paper line by line.
*
*   Numbers taken from other papers or external data (UN population figures,
*   DHS fertility rates, the fostering shares of Zipfel 2026, the literature
*   table F.1) are not reproduced here; see README.md.
*
*   RUN: set global ROOT below, then  do "<ROOT>\do\replication_text.do"
*==============================================================================
clear all
set more off
set varabbrev off
set maxvar 20000
set linesize 255
version 17

*--- switches -----------------------------------------------------------------
global txt_desc = 1     // A. sample, timing, descriptive shares
global txt_inf  = 1     // B. survival models, robustness, inference
global txt_ri   = 1     // C. randomization inference (slow: 1,000 permutations)

*--- paths --------------------------------------------------------------------
* EDIT THIS ONE LINE to the absolute path of the replication/ folder.
global ROOT "C:\path\to\replication"
global CRE  "$ROOT\data"
global DHS2024 "$ROOT\data\DHS\2024\ETIR8ADT\ETIR8AFL.dta"   // optional, see README
global OUT  "$ROOT\output\text"
capture mkdir "$ROOT\output"
capture mkdir "$OUT"

capture log close _all
log using "$OUT\replication_text_log.txt", text replace
di as text "replication_text.do  started  $S_DATE $S_TIME"

* helper: print one labelled result
capture program drop _txt
program define _txt
    gettoken where 0 : 0
    gettoken what  0 : 0
    di as result "TEXT | `where' | `what' | `0'"
end


*==============================================================================
* A. SAMPLE, SURVEY TIMING AND DESCRIPTIVE SHARES  (FU_slim.dta, panel_slim.dta)
*==============================================================================
if $txt_desc {
capture noisily {

* ---- A1. Sample and attrition (Introduction; Sec. 3.1-3.2) ------------------
use "$CRE\FU_slim.dta", clear
count
_txt "Sec 2/3.2" "women randomized (draft: 1464)" `r(N)'
count if attrit==0
local n7 = r(N)
_txt "Intro/Sec 3.2" "interviewed at endline (draft: 1130)" `n7'
_txt "Intro/Sec 3.2" "endline response rate (draft: 77%)" `=string(100*`n7'/_N,"%4.1f")'%
_txt "Intro/Sec 3.2" "endline attrition (draft: 23%)" `=string(100*(1-`n7'/_N),"%4.1f")'%
count if attrit==1
_txt "Sec 3.2" "missing at Wave 7 (draft: 334)" `r(N)'
count if attrit_w2==1
_txt "Sec 3.2" "missing at Wave 2 (draft: 201)" `r(N)'
_txt "Sec 3.2" "share missing at Wave 2 (draft: 14%)" `=string(100*r(N)/_N,"%4.1f")'%
* differential Wave-2 attrition (producer: do/attrition_w2.do)
reg attrit_w2 orig_treatment i.block, cl(id_anon)
_txt "Sec 3.2" "W2 attrition on treatment, block FE (draft: -0.0025)" `=string(_b[orig_treatment],"%7.4f")' (se `=string(_se[orig_treatment],"%6.4f")')
* Wave-2 x Wave-7 response
tab attrit_w2 attrit
count if attrit==1 & attrit_w2==1
_txt "Sec 3.2" "W7 attriters also missing at W2 (draft: 201)" `r(N)'
count if attrit_w2==0
local nw2 = r(N)
count if attrit_w2==0 & attrit==1
_txt "Sec 3.2" "attrition at W7 among W2 respondents (draft: 11%)" `=string(100*r(N)/`nw2',"%4.1f")'%
count if attrit_w2==1 & attrit==0
_txt "Sec 3.2" "W2 non-respondents recovered at W7" `r(N)'

* respondents by wave (Sec 3.1: draft W2 1263, W6 976), restricted to the
* randomized sample in FU_slim
keep id_anon
tempfile ids
save `ids'
use id_anon wave any_wage_job_last6_r_alt using "$CRE\panel_slim.dta", clear
merge m:1 id_anon using `ids', keep(match) nogen
forvalues w = 2/6 {
    count if wave==`w' & !missing(any_wage_job_last6_r_alt)
    _txt "Sec 3.1" "respondents at Wave `w'" `r(N)'
}

* ---- A2. Survey timing (Sec 3.1: Waves 2-6 at 8, 15, 22, 35, 48 months) ------
use "$CRE\FU_slim.dta", clear
forvalues a = 2/7 {
    quietly su months_since_bl`a' if !missing(nr_births_w`a') & !missing(orig_treatment)
    _txt "Sec 3.1" "months since baseline, Wave `a'" `=string(r(mean),"%5.2f")'
}
quietly su months_since_bl7 if attrit==0, detail
_txt "Intro" "years between baseline and endline: mean / min / max (draft: eight to nine)" `=string(r(mean)/12*30/30.4375,"%4.1f")' / `=string(r(min)/12*30/30.4375,"%4.1f")' / `=string(r(max)/12*30/30.4375,"%4.1f")'

* ---- A3. Ages ------------------------------------------------------------------
quietly su base_age, detail
_txt "Sec 1 (contribution)" "median baseline age, randomized sample (draft: 23)" `r(p50)'
quietly su base_age if attrit==0, detail
_txt "Sec 1 (contribution)" "median baseline age, endline sample" `r(p50)'
quietly su A6_1 if attrit==0, detail
_txt "Intro / Sec 4.3" "median age at endline, roster age A6_1 (draft: 30)" `r(p50)'
count if A6_1>=30 & attrit==0 & !missing(A6_1)
local a30 = r(N)
count if attrit==0 & !missing(A6_1)
_txt "Intro" "share aged 30+ at endline (draft: 60%)" `=string(100*`a30'/r(N),"%4.1f")'%
_pctile A6_1 if attrit==0, p(12.5 87.5)
_txt "Sec 4.3" "middle three quarters of endline ages (draft: 27-40)" `r(r1)'-`r(r2)'
* the age the surrogate analysis (Table 5) actually uses
gen refage = base_age + 9
replace refage = 28 if refage < 28
replace refage = 40 if refage > 40
quietly su refage if !missing(Ab08), detail
_txt "Sec 4.3" "surrogate reference age: median" `r(p50)'
count if refage>=30 & !missing(Ab08)
local r30 = r(N)
count if !missing(Ab08)
_txt "Sec 4.3" "surrogate reference age: share 30+" `=string(100*`r30'/r(N),"%4.1f")'%
drop refage

* ---- A4. Jobs: women's share of workers, Wave-2 pay and hours (Sec 2) --------
quietly su share_w
_txt "Sec 2" "women's share of factory workers, respondent-weighted (draft: 72%)" `=string(100*r(mean),"%4.1f")'%
gen double w2_pay_total = w2_Ka4_1 + w2_Ka5_1
quietly su w2_pay_total
_txt "Sec 2" "Wave-2 monthly pay incl. benefits, ETB (draft: 1,021)" `=string(r(mean),"%7.1f")' (N=`r(N)')
quietly su w2_Ka4_1 if !missing(w2_pay_total)
_txt "Sec 2" "Wave-2 basic monthly pay, ETB" `=string(r(mean),"%7.1f")'
count if w2_Ka6_1_B==8
local h8 = r(N)
count if !missing(w2_Ka6_1_B)
_txt "Sec 2" "share working 8 hours per day" `=string(100*`h8'/r(N),"%4.1f")'%
count if w2_Ka6_1_A==6
local d6 = r(N)
count if !missing(w2_Ka6_1_A)
_txt "Sec 2" "share working 6 days per week" `=string(100*`d6'/r(N),"%4.1f")'%
* factory pay relative to baseline household income (Sec 6: "about one third")
quietly su w2_pay_total
local pay6 = 6*r(mean)
quietly su base_hhinc6
_txt "Sec 6" "6 months of factory pay / mean baseline 6-month household income" `=string(100*`pay6'/r(mean),"%4.1f")'%

* ---- A5. Combining work and childcare (Sec 2; Sec 5.2) -----------------------
tab K1_53 if attrit==0
tab K1_53 if attrit==0, nolabel
tab K1_53 if attrit==0 & any_child_w1nr==0
tab K1_12C
* (shares are read off the tabulations above: draft Sec 2 56% / 9% / 35% on the
*  endline sample; Sec 5.2 45% yes / 55% no among baseline non-mothers;
*  K1_12C: 60% very difficult, 23% difficult)

* ---- A6. Savings and borrowing (Sec 5.1) -------------------------------------
tab Sc_1 if attrit==0
tab Sc_7 if attrit==0
tab Sc_8 if attrit==0
tab Sc_8 if attrit==0, nolabel
* (draft: 88% have a bank or microfinance savings account; 3% borrowed)

* ---- A7. Baseline gender attitudes (Sec 5.3) ----------------------------------
foreach v in base_norm_salaried_repected base_norm_hhwork_instead {
    quietly su `v' if attrit==0
    _txt "Sec 5.3" "`v' share agreeing" `=string(100*r(mean),"%4.1f")'%
}
foreach v in base_Ga_2 base_Ga_6 {
    count if inlist(`v',1,2) & attrit==0
    local ag = r(N)
    count if !missing(`v') & attrit==0
    _txt "Sec 5.3" "`v' share agreeing or strongly agreeing" `=string(100*`ag'/r(N),"%4.1f")'%
}
* (draft: 92%, 11%, 99%, 92%)

* ---- A8. Childless women still with their baseline partner (Sec 5.3: 32%) ----
quietly su same_partner if Ab08==0
_txt "Sec 5.3" "childless women with the same partner, all" `=string(100*r(mean),"%4.1f")'% (N=`r(N)')
quietly su same_partner if Ab08==0 & orig_treatment==0
_txt "Sec 5.3" "childless women with the same partner, control group" `=string(100*r(mean),"%4.1f")'% (N=`r(N)')

* ---- A9. Baseline desired-fertility bins (App. A.10 notes: 70/15/15) ---------
gen byte want_bin = .
replace want_bin = 1 if base_wanted_nrch < 3
replace want_bin = 2 if inrange(base_wanted_nrch,3,4)
replace want_bin = 3 if base_wanted_nrch >= 5 & !missing(base_wanted_nrch)
tab want_bin, m

di as result "A. text descriptives done"
}
}


*==============================================================================
* B. SURVIVAL MODELS, ROBUSTNESS AND OTHER ESTIMATES QUOTED IN THE TEXT
*==============================================================================
if $txt_inf {
capture noisily {

* ---- B1. Log-rank tests and time-varying Cox models (Sec 4.2, Figure 1 notes)
*      producer: do/duration_analysis_Pauline.do
use "$CRE\FU_slim.dta", clear
drop if attrit==1
gen event = km_event
gen duration = km_duration
stset duration, failure(event)
sts test orig_treatment, logrank
_txt "Fig 1 notes" "log-rank p, all women (draft: 0.34)" `=string(chi2tail(r(df),r(chi2)),"%6.4f")'
sts test orig_treatment if any_child_w1nr==0, logrank
_txt "Fig 1 notes" "log-rank p, baseline non-mothers (draft: rejected at 1%)" `=string(chi2tail(r(df),r(chi2)),"%6.4f")'
rename id_anon id
expand 3
sort id
by id, sort: gen id_p = cond(_n==2,2,cond(_n==3,3,1))
gen pre        = cond(id_p==1,1,0)
gen post_short = cond(id_p==2,1,0)
gen post_long  = cond(id_p==3,1,0)
gen treat_pre   = orig_treatment*pre
gen treat_short = orig_treatment*post_short
gen treat_long  = orig_treatment*post_long
foreach cut in 35 15 {
    local b1 = 9
    local b2 = `cut'
    capture drop t_n duration_het event_het
    gen t_n = cond(id_p==2,`b1',cond(id_p==3,`b2',0))
    gen duration_het = duration
    replace duration_het = . if duration<`b1' & id_p>=2
    replace duration_het = . if duration<`b2' & id_p==3
    gen event_het = event
    replace event_het = . if duration<`b1' & id_p>=2
    replace event_het = . if duration<`b2' & id_p==3
    replace event_het = 0 if duration>=`b1' & id_p==1
    replace event_het = 0 if duration>=`b2' & id_p==2
    replace duration_het = `b1' if id_p==1 & event_het==0
    replace duration_het = `b2' if id_p==2 & event_het==0
    if `cut'==35 {
        local smp "all women"
        stset duration_het, failure(event_het) id(id) time0(t_n)
        stcox treat_pre treat_short treat_long i.em_* i.m_*, strata(block) vce(cluster block)
    }
    else {
        local smp "baseline non-mothers"
        stset duration_het if any_child_w1nr==0, failure(event_het) id(id) time0(t_n)
        stcox treat_pre treat_short treat_long i.m_* if any_child_w1nr==0, strata(block) vce(cluster block)
    }
    foreach t in treat_pre treat_short treat_long {
        _txt "Fig 1 notes / Sec 4.2" "Cox HR `smp', `t' (breaks 9 and `cut' months)" `=string(exp(_b[`t']),"%5.3f")' (p `=string(2*normal(-abs(_b[`t']/_se[`t'])),"%6.4f")')
    }
}
* (draft, all women: 0.90 p=0.65 / 1.07 p=0.61 / 1.15 p=0.12;
*  non-mothers: 1.49 p=0.32 / 0.76 p=0.46 / 1.72 p=0.004)

* ---- B2. Log-rank, work/childcare split (App. Figure KM_workchild notes) ----
*      producer: do/km_workchild_combined.do
use "$CRE\FU_slim.dta", clear
stset km_duration, failure(km_event)
gen byte wchild_bin = .
replace wchild_bin = 1 if inlist(K1_53, 1, 2)
replace wchild_bin = 0 if K1_53 == 3
foreach c in 1 0 {
    local lab = cond(`c'==1, "can combine (draft: 2.90, p=0.089, 117 births)", "cannot combine (draft: 5.69, p=0.017, 138 births)")
    sts test orig_treatment if wchild_bin==`c' & any_child_w1nr==0
    local chi = r(chi2)
    local p = chi2tail(r(df),r(chi2))
    quietly count if wchild_bin==`c' & any_child_w1nr==0 & km_event==1 & !missing(km_duration)
    _txt "App KM_workchild notes" "log-rank, `lab'" chi2 `=string(`chi',"%5.2f")', p `=string(`p',"%6.4f")', births `r(N)'
}

* ---- B3. Drop-one-firm robustness (Sec 4.2 footnote) ------------------------
*      producer: do/bread_BC_hetero_park.do; firm6 = anonymous code of the six
*      largest firms (0 = all other firms)
use "$CRE\FU_slim.dta", clear
count if firm6>0 & !missing(Ab08)
local n6 = r(N)
count if !missing(Ab08)
_txt "Sec 4.2 fn" "share of the endline sample in the six largest firms (draft: 78%)" `=string(100*`n6'/r(N),"%4.1f")'%
foreach y in any_child Ab08 {
    local lo = .
    local hi = .
    forvalues f = 1/6 {
        quietly pdslasso `y' orig_treatment (i.em* m_* bl_fe*) if firm6!=`f', partial(bl_fe*) robust
        di as text "  drop firm `f', `y': b = " %9.6f _b[orig_treatment]
        local lo = min(`lo', _b[orig_treatment])
        local hi = max(`hi', _b[orig_treatment])
    }
    _txt "Sec 4.2 fn" "range of `y' estimates dropping one large firm at a time (draft: 0.020-0.049 / 0.089-0.149)" `=string(`lo',"%5.3f")' to `=string(`hi',"%5.3f")'
}

* ---- B4. Contraceptive use, baseline non-mothers (Sec 5.3) -------------------
*      producer: do/contracep_itt.do (W2-W6) + same spec for W7
foreach w in 2 3 4 5 6 7 {
    quietly pdslasso use_w`w' orig_treatment (i.em_* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
    _txt "Sec 5.3" "contraceptive use, non-mothers, Wave `w'" `=string(_b[orig_treatment],"%6.3f")' (se `=string(_se[orig_treatment],"%5.3f")', p `=string(2*normal(-abs(_b[orig_treatment]/_se[orig_treatment])),"%5.3f")', N `e(N)')
}

* ---- B5. Fertility preferences by baseline motherhood (Sec 4.2) --------------
*      producer: do/wanted_appr_parity01.do
foreach y in wanted_nrch appr_age_fkid {
    forvalues m = 0/1 {
        local grp = cond(`m'==0, "non-mothers", "mothers")
        quietly pdslasso `y' orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==`m', partial(bl_fe*) robust
        _txt "Sec 4.2" "`y', baseline `grp'" `=string(_b[orig_treatment],"%6.3f")' (se `=string(_se[orig_treatment],"%5.3f")', p `=string(2*normal(-abs(_b[orig_treatment]/_se[orig_treatment])),"%5.3f")')
    }
}

* ---- B6. Quitting the factory and first birth (Sec 5.2: "roughly half") -----
*      producer: do/Sequencing_feb20.do (sample: treated baseline non-mothers
*      who worked at the factory and have both a quit date and a first birth)
quietly su quit_before_birth if any_child_w1nr==0 & orig_treatment==1
_txt "Sec 5.2" "treated non-mothers who quit before their first birth (draft: roughly half)" `=string(100*r(mean),"%4.1f")'% (N=`r(N)')

* ---- B7. Cost of a child (Sec 5.3: 4,240 ETB per year; p/I = 16%) -------------
*      producer: do/check_questions.do Q1 (control group; region FE)
gen double non_child_hhsize = hhsize - Ab08
reg hhexp6 Ab08 non_child_hhsize base_age base_edu_yrs i.region if orig_treatment==0, robust
local c6 = _b[Ab08]
quietly su hhexp6 if e(sample)
_txt "Sec 5.3" "6-month household expenditure per child, ETB" `=string(`c6',"%7.1f")' (se `=string(_se[Ab08],"%5.1f")', N `e(N)')
_txt "Sec 5.3" "annual expenditure per child, ETB (draft: 4,240)" `=string(2*`c6',"%7.1f")'
quietly su hhexp6 if orig_treatment==0
_txt "Sec 5.3" "p/I: per-child cost over mean control expenditure (draft: 16%)" `=string(100*`c6'/r(mean),"%4.1f")'%

* ---- B8. Surrogate first step: kappa (Sec 4.3; needs the 2024 EDHS) ---------
*      producer: do/surrogate_dhs.do (linear map). Skipped without the DHS file.
capture confirm file "$DHS2024"
if _rc {
    di as text "SKIP B8 (kappa): DHS 2024 file not found at $DHS2024. See README."
}
else {
    local b3list ""
    forvalues k=1/20 {
        local kk : display %02.0f `k'
        local b3list `b3list' b3_`kk'
    }
    use v005 v011 v012 v025 v201 `b3list' using "$DHS2024", clear
    keep if inrange(v012,45,49)
    gen ceb = v201
    gen byte urban = v025==1
    gen wt = v005/1000000
    forvalues a = 28(2)40 {
        gen par_`a' = 0
        forvalues k=1/20 {
            local kk : display %02.0f `k'
            capture confirm variable b3_`kk'
            if _rc==0 quietly replace par_`a' = par_`a' + (b3_`kk' - v011 < `a'*12 & !missing(b3_`kk'))
        }
    }
    gen long wid = _n
    keep ceb urban wt wid par_*
    reshape long par_, i(wid) j(refage)
    gen remaining = ceb - par_
    drop if remaining < 0
    reg remaining c.par_ c.refage [pw=wt] if urban==1
    _txt "Sec 4.3" "kappa: slope of remaining births on parity, linear map (draft: 0.017)" `=string(_b[par_],"%6.4f")' (se `=string(_se[par_],"%6.4f")', p `=string(2*ttail(e(df_r),abs(_b[par_]/_se[par_])),"%4.2f")', N `e(N)')
    * the text defines kappa as the average derivative of the flexible map used
    * for Table 5 (replication_main.do, T5); print that version too
    reg remaining c.par_##c.refage c.par_#c.par_ c.refage#c.refage [pw=wt] if urban==1
    margins, dydx(par_)
    matrix M = r(table)
    _txt "Sec 4.3" "kappa: average derivative of the flexible map wrt parity" `=string(M[1,1],"%6.4f")' (se `=string(M[2,1],"%6.4f")', p `=string(M[4,1],"%4.2f")')
}

* ---- B9. ML heterogeneity: export for do/ml_hetero.R (Sec 5.2 footnote) -----
*      producer: do/ml_hetero_export.do. Rows are written in the authors'
*      analysis-file order (rawrow), which the seeded forests depend on.
use "$CRE\FU_slim.dta", clear
sort rawrow
keep if !missing(Ab08)
gen byte nonmom = (any_child_w1nr==0)
gen double dAb08 = Ab08 - cond(missing(base_B11), 0, base_B11)
egen double p_block = mean(orig_treatment), by(block)
local feats base_any_child base_B11 base_partner_w_more_ch base_wanted_nrch ///
    base_appr_age_fkid base_K1 base_age base_Muslim base_Protestant ///
    base_leisure base_soc_rel base_edu_yrs
local exportfeats ""
foreach v of local feats {
    quietly su `v', detail
    gen double f_`v' = `v'
    gen byte   fm_`v' = missing(`v')
    quietly replace f_`v' = r(p50) if missing(`v')
    local exportfeats `exportfeats' f_`v' fm_`v'
}
foreach v of local feats {
    quietly su fm_`v'
    if r(mean)==0 {
        drop fm_`v'
        local exportfeats : subinstr local exportfeats "fm_`v'" "", word
    }
}
sort rawrow
keep id_anon orig_treatment any_child Ab08 dAb08 nonmom p_block block `exportfeats'
export delimited using "$OUT\ml_hetero.csv", replace nolabel
di as text "  ml_hetero.csv written; now run do/ml_hetero.R (see README)"

di as result "B. text inference done"
}
}


*==============================================================================
* C. RANDOMIZATION INFERENCE  (Sec 4.2 footnote; Table 3 notes)
*   producer: do/ri_reselect.do. Treatment is re-drawn within randomization
*   lists 1,000 times; each draw re-runs the treatment-side Lasso selection and
*   re-estimates with the union of the outcome-side and treatment-side controls.
*   Seeded; the draws follow the authors' analysis-file order (sort rawrow), so
*   the p-values reproduce exactly. Run time about 10 minutes.
*==============================================================================
if $txt_ri {
capture noisily {
set seed 20260722
use "$CRE\FU_slim.dta", clear
sort rawrow
* Stata breaks ties in -sort- with a separate generator (sortseed) whose state
* advances with every sort in the session; -set seed- and -clear all- do not
* reset it. The original run started in a fresh Stata session, where that
* state is the startup value 1001. Restore it so the permutations reproduce
* whatever ran earlier in the session.
set sortseed 1001
keep if !missing(Ab08)
gen byte nonmom = (any_child_w1nr==0)
local reps 1000
foreach samp in full nonmom {
    preserve
    if "`samp'"=="nonmom" keep if nonmom==1
    foreach y in any_child Ab08 {
        quietly pdslasso `y' orig_treatment (i.em_* m_* bl_fe*), partial(bl_fe*) robust
        local bobs_`y' = _b[orig_treatment]
        quietly rlasso `y' i.em_* m_* bl_fe*, partial(bl_fe*)
        local sely_`y' `e(selected)'
    }
    quietly bysort block: egen __ntreat = total(orig_treatment)
    tempname P
    tempfile rip
    postfile `P' int rep double b_any b_ab08 using `rip', replace
    forvalues r = 1/`reps' {
        quietly {
            gen double __u = runiform()
            sort block __u
            by block: gen byte Tp = (_n <= __ntreat)
            capture rlasso Tp i.em_* m_* bl_fe*, partial(bl_fe*)
            local selt `e(selected)'
            local blist ""
            foreach y in any_child Ab08 {
                local un : list sely_`y' | selt
                capture areg `y' Tp `un', absorb(block)
                if _rc local bp = .
                else   local bp = _b[Tp]
                local blist `blist' (`bp')
            }
            post `P' (`r') `blist'
            drop __u Tp
        }
        if mod(`r',100)==0 di as text "  ...`samp' rep `r' done ($S_TIME)"
    }
    postclose `P'
    use `rip', clear
    quietly count
    local R = r(N)
    quietly count if abs(b_any) >= abs(`bobs_any_child') & !missing(b_any)
    _txt "Sec 4.2 fn / Table 3 notes" "RI p, any children, `samp' (draft: 0.011 full; <0.005 / <0.001 non-mothers)" `=string(r(N)/`R',"%5.3f")' [`R' draws]
    quietly count if abs(b_ab08) >= abs(`bobs_Ab08') & !missing(b_ab08)
    _txt "Sec 4.2 fn / Table 3 notes" "RI p, number of children, `samp' (draft: 0.039 full; <0.005 / 0.004 non-mothers)" `=string(r(N)/`R',"%5.3f")' [`R' draws]
    restore
}
di as result "C. randomization inference done"
}
}


di as text "replication_text.do  finished  $S_DATE $S_TIME"
log close
