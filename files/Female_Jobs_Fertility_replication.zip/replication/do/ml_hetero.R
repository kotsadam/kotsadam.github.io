############################################################
# ml_hetero.R -- ML heterogeneity tests (pre-registered omnibus test)
#   (1) grf causal forest (Athey-Wager): ATE, calibration test
#       (differential.forest.prediction = heterogeneity test)
#   (2) CDDF Generic ML (GenericML): BLP (beta.2 = heterogeneity)
# Samples: full + baseline non-mothers
# Outcomes: any_child, Ab08, dAb08 (change score)
# Input : output/text/ml_hetero.csv  (written by do/replication_text.do, B9)
# Output: output/text/ml_hetero_results.txt
# Paper : Sec 5.2 footnote ("all heterogeneity-test p-values exceed ...").
# Packages: grf, GenericML (+ mlr3learners, glmnet, ranger), from CRAN.
# Verified 2026-10-03 with R 4.6.1, grf 2.6.1, GenericML 0.2.3.
############################################################

# EDIT THIS LINE to the absolute path of the replication/ folder
root <- "C:/path/to/replication"

rm(list = setdiff(ls(), "root"))
set.seed(90210)

suppressMessages({
  library(grf)
  library(GenericML)
})

dat <- read.csv(file.path(root, "output/text/ml_hetero.csv"))

sink(file.path(root, "output/text/ml_hetero_results.txt"), split = TRUE)
cat("ML heterogeneity run:", format(Sys.time()), "\n")
cat("N =", nrow(dat), " treated share =", mean(dat$orig_treatment), "\n\n")

featcols <- grep("^f_|^fm_", names(dat), value = TRUE)
cat("features (", length(featcols), "):", paste(featcols, collapse = " "), "\n\n")

pvals <- data.frame(sample = character(), outcome = character(),
                    test = character(), p = numeric())

run_combo <- function(df, yvar, label) {
  cat("\n==========================================================\n")
  cat("### ", label, " | outcome:", yvar, " | N =", nrow(df), "\n")
  cat("==========================================================\n")

  X <- as.matrix(df[, featcols])
  Y <- df[[yvar]]
  W <- df$orig_treatment
  p <- df$p_block
  p_clip <- pmin(pmax(p, 0.02), 0.98)  # degenerate lists (share 0/1) break AIPW
  cat("obs in degenerate blocks (p in {0,1}):", sum(p %in% c(0, 1)), "\n")

  ## ---------- (1) grf causal forest ----------
  cf <- causal_forest(X, Y, W, W.hat = p_clip, num.trees = 5000, seed = 90210)
  ate <- average_treatment_effect(cf)
  cat("\n[grf] ATE:", sprintf("%.4f (%.4f)", ate["estimate"], ate["std.err"]), "\n")
  tc <- test_calibration(cf)
  cat("[grf] test_calibration (diff.fp = heterogeneity):\n")
  print(round(tc, 4))
  pvals[nrow(pvals) + 1, ] <<- list(label, yvar, "grf calibration (diff.fp)",
                                    tc["differential.forest.prediction", 4])
  blp_vars <- intersect(c("f_base_age", "f_base_B11", "f_base_wanted_nrch",
                          "f_base_edu_yrs", "f_base_K1", "f_base_Muslim",
                          "f_base_leisure"), featcols)

  ## ---------- (2) CDDF GenericML ----------
  cat("\n[GenericML] 100 splits, learners: lasso + random forest ...\n")
  gml <- tryCatch(
    GenericML(
      Z = X, D = W, Y = Y,
      learner_propensity_score = p_clip,
      learners_GenericML = c("mlr3::lrn('cv_glmnet', s = 'lambda.min')",
                             "mlr3::lrn('ranger', num.trees = 500)"),
      num_splits = 100,
      quantile_cutoffs = c(0.2, 0.4, 0.6, 0.8),
      Z_CLAN = X[, blp_vars],
      significance_level = 0.05,
      parallel = FALSE,
      seed = 90210,
      store_learners = FALSE, store_splits = FALSE
    ),
    error = function(e) { cat("GenericML ERROR:", conditionMessage(e), "\n"); NULL }
  )
  if (!is.null(gml)) {
    blp <- get_BLP(gml, plot = FALSE)
    cat("[GenericML] BLP (beta.1 = ATE, beta.2 = heterogeneity):\n")
    print(blp)
    pvals[nrow(pvals) + 1, ] <<- list(label, yvar, "GenericML BLP beta.2",
                                      unname(blp$p_value["beta.2"]))
  }
  invisible(NULL)
}

for (samp in c("full", "nonmom")) {
  df <- if (samp == "nonmom") dat[dat$nonmom == 1, ] else dat
  for (y in c("any_child", "Ab08", "dAb08")) run_combo(df, y, samp)
}

cat("\n\n==== Heterogeneity-test p-values (all combinations) ====\n")
print(pvals, row.names = FALSE)
cat("\nTEXT | Sec 5.2 fn | smallest heterogeneity-test p-value |",
    sprintf("%.4f", min(pvals$p, na.rm = TRUE)), "\n")
sink()
cat("DONE\n")
