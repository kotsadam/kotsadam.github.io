*==============================================================================
* replication_main.do
*   Self-contained, exhibit-by-exhibit replication of the MAIN-BODY exhibits of
*   "Female Jobs and Fertility: Long-term Experimental Evidence from Ethiopian
*   Factories" (current Overleaf draft, July 2026).
*
*   Each block: (i) opens the dataset it needs, (ii) runs the minimal estimation
*   for ONE paper exhibit, (iii) writes a *_check.tex to $OUT, and (iv) prints
*   the key coefficient(s) to the log. Expected values from the committed
*   Jobs_and_Fertility_overleaf results files are given in comments as
*   "EXPECT ..." so the numbers can be checked at a glance.
*
*   MAIN EXHIBITS (paper table/figure number -> committed results file):
*     Table 1  Baseline characteristics        fert_des_new_fert_ed_edt.tex
*     Table 2  First stage by wave             first_lasso_pres.tex
*     Table 3  ITT fertility                   main_pres.tex
*     Table 4  IV                              IV_combined.tex
*     Figure   Duration KM (all / non-moms)    KM_combined.pdf
*     Table 5  Surrogate extrapolation         surrogate_paper.tex        [needs DHS]
*     Table 6  Cumulative income & savings     hhinc6_savings_cum_bal.tex
*     Table 7  Heterogeneity by income         hhinc_hetero_any_nr.tex
*     Table 8  Other mechanisms                mechanisms_combined.tex
*     Figure   Duration KM by firm wage        KM_wage_combined.pdf
*
*   DATASETS (Data/created unless noted):
*     FU_slim.dta   cross-section, Wave-7 endline (orig_treatment)
*     panel_slim.dta      person-wave panel (orig_treatment_r, *_r variables)
*     cumulative_slim.dta      person-wave, income/savings (orig_treatment_r)
*     DHS  Ethiopia_women_2016.DTA  and  2024/ETIR8ADT/ETIR8AFL.dta   (surrogate)
*
*   RUN (StataNow 19, from the project root):
*     MSYS_NO_PATHCONV=1 "/c/Program Files/StataNow19/StataSE-64.exe" /e do 'do\replication_main.do'
*
*==============================================================================
clear all
set more off
set varabbrev off
set maxvar 20000
version 17

*--- switches (1 = run) -------------------------------------------------------
global t1_fertdes   = 1
global t2_firststg  = 1
global t3_mainitt   = 1
global t4_iv        = 1
global f_km         = 1
global t5_surrogate = 1
global t6_cumbal    = 1
global t7_hetero    = 1
global t8_mech      = 1
global f_kmwage     = 1

*--- paths --------------------------------------------------------------------
* EDIT THIS ONE LINE to the absolute path of the replication/ folder on your
* machine (the folder that contains data/, do/, output/). Everything else is
* relative to it. The anonymized datasets live in $ROOT\data.
global ROOT "C:\Users\andrkot\Frischsenteret Dropbox\Andreas Kotsadam\cursor\Fertility_Ethiopia\replication"
global CRE  "$ROOT\data"
global DHS  "$ROOT\data\DHS"     // put DHS files here if you download them (see README)
global OUT  "$ROOT\output\main"
capture mkdir "$ROOT\output"
capture mkdir "$OUT"

capture log close _all
log using "$OUT\replication_main_log.txt", text replace

foreach pkg in estout pdslasso {
    capture which `pkg'
    if _rc ssc install `pkg', replace
}

di as text "{hline 78}"
di as text "replication_main.do  started  $S_DATE $S_TIME"
di as text "{hline 78}"


*==============================================================================
* TABLE 1.  Baseline characteristics, by treatment arm   (fert_des_new_fert_ed_edt)
*   Dataset: FU_slim.dta.  Means/SDs by All/Treated/Control for the endline
*   sample (attrit==0); stars = significance of the treatment-control difference
*   from a block-adjusted regression.
*   EXPECT (All column): Treatment 0.50; Any child 0.69; Number of children 1.41;
*     Partner wants more 0.21; Wanted number 3.96; Appr age 22.70; Any wage job
*     0.31; Age 25.13; Muslim 0.14; Protestant 0.23; Educ 9.28; Leisure 33.98;
*     Soc/relig 6.51.  N: All 1130, Treated 560, Control 570.
*==============================================================================
if $t1_fertdes {
capture noisily {
use "$CRE\FU_slim.dta", clear
keep if attrit==0

* Means/SDs by All/Treated/Control; a star on the control column marks the
* significance of the treatment-control difference (block-adjusted regression);
* the foot reports the joint F-test that all characteristics are unrelated to
* treatment. Baseline "Number of children" is nr_births_w1 (companion of the
* "Any child" row, any_child_w1nr).
capture program drop _fdrow
program define _fdrow
    args fh v label
    quietly su `v'
    local ma=r(mean)
    local sa=r(sd)
    quietly su `v' if orig_treatment==1
    local mt=r(mean)
    local st=r(sd)
    quietly su `v' if orig_treatment==0
    local mc=r(mean)
    local sc=r(sd)
    local star ""
    if "`v'"!="orig_treatment" {
        quietly reg `v' orig_treatment bl_fe*, robust
        local p = 2*ttail(e(df_r), abs(_b[orig_treatment]/_se[orig_treatment]))
        if `p'<0.10 local star "*"
        if `p'<0.05 local star "**"
        if `p'<0.01 local star "***"
    }
    file write `fh' "`label'& " %4.2f (`ma') "& (" %4.2f (`sa') ")& " %4.2f (`mt') "& (" %4.2f (`st') ")& " %4.2f (`mc') "& (" %4.2f (`sc') ")`star'\\" _n
end

file open T using "$OUT\fert_des_new_fert_ed_edt_check.tex", write replace
file write T "\begin{tabular}{l*{14}{l}}" _n "\hline" _n
file write T "            &\multicolumn{2}{c}{All}  &\multicolumn{2}{c}{Treated}&\multicolumn{2}{c}{Control}\\\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}" _n
file write T "            &\multicolumn{2}{c}{(1)}  &\multicolumn{2}{c}{(2)}  &\multicolumn{2}{c}{(3)}  \\" _n
file write T "            &\multicolumn{2}{c}{}     &\multicolumn{2}{c}{}     &\multicolumn{2}{c}{}     \\" _n
file write T "            &\multicolumn{1}{c}{Mean}&\multicolumn{1}{c}{SD}&\multicolumn{1}{c}{Mean}&\multicolumn{1}{c}{SD}&\multicolumn{1}{c}{Mean}&\multicolumn{1}{c}{SD}\\" _n
file write T "\hline" _n
file write T "\multicolumn{4}{l}{\emph{Treatment and fertility variables}} \\" _n
_fdrow T orig_treatment "Treatment"
_fdrow T any_child_w1nr "Any child"
_fdrow T nr_births_w1 "Number of children"
_fdrow T base_partner_w_more_ch "Partner wants more kids"
_fdrow T base_wanted_nrch "Wanted number of children"
_fdrow T base_appr_age_fkid "Appropriate age of first birth"
file write T "\multicolumn{2}{l}{\emph{Other variables}} \\" _n
_fdrow T base_K1 "Any wage job ever"
_fdrow T base_age "Age"
_fdrow T base_Muslim "Muslim"
_fdrow T base_Protestant "Protestant"
_fdrow T base_edu_yrs "Years of education"
_fdrow T base_leisure "Leisure time last 7 days (hours)"
_fdrow T base_soc_rel "Social and religious activities last 7 days (hours)"
file write T "\hline" _n
count
local nall=r(N)
count if orig_treatment==1
local nt=r(N)
count if orig_treatment==0
local nc=r(N)
file write T "\(N\)       & `nall'&            & `nt'&            & `nc'&            \\" _n
file write T "\hline" _n
local fvars any_child_w1nr nr_births_w1 base_partner_w_more_ch base_wanted_nrch ///
            base_appr_age_fkid base_K1 base_age base_Muslim base_Protestant     ///
            base_edu_yrs base_leisure base_soc_rel
quietly reg orig_treatment `fvars' bl_fe*, robust
testparm `fvars'
file write T "F-value & & & & & & " %4.2f (r(F)) " \\" _n
file write T "P-value F-test & & & & & & " %4.2f (r(p)) " \\" _n
file write T "\hline" _n "\end{tabular}" _n
file close T
di as result "T1 done -> fert_des_new_fert_ed_edt_check.tex"
}
}


*==============================================================================
* TABLE 2.  First stage on wage employment, by wave   (first_lasso_pres)
*   Dataset: panel_slim.dta (orig_treatment_r? -> uses orig_treatment; *_r vars).
*   Col 1 pooled (waves 2-7); cols 2-7 = waves 2..7.  DV = any_wage_job_last6_r_alt.
*   EXPECT Treatment: (1) 0.15*** (2) 0.38*** (3) 0.25*** (4) 0.16*** (5) 0.12***
*     (6) 0.032 (7) -0.011
*==============================================================================
if $t2_firststg {
capture noisily {
use "$CRE\panel_slim.dta", clear
capture confirm variable orig_treatment
if _rc capture rename orig_treatment_r orig_treatment

estimates drop _all
pdslasso any_wage_job_last6_r_alt orig_treatment (i.em* m_* bl_fe* i.wave) ///
    if wave>1 & wave<8 & nr_births_r!=., partial(bl_fe* i.wave) cl(id_anon)
estadd local Controls "Lasso"
qui su any_wage_job_last6_r_alt if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo first_w1
forvalues a = 2/7 {
    pdslasso any_wage_job_last6_r_alt orig_treatment (i.em* m_* bl_fe*) ///
        if wave==`a' & nr_births_r!=., partial(bl_fe*) cl(id_anon)
    estadd local Controls "Lasso"
    qui su any_wage_job_last6_r_alt if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo first_w`a'
}
esttab first_w1 first_w2 first_w3 first_w4 first_w5 first_w6 first_w7           ///
    using "$OUT\first_lasso_pres_check.tex", replace style(tex) b(a2) se        ///
    starlevels(* 0.10 ** 0.05 *** 0.01)                                         ///
    keep(orig_treatment) varlabels(orig_treatment "Treatment")                  ///
    stats(mean_depvar_c N Controls, labels("Control mean" "N" "Controls") fmt(2 0 2 0)) ///
    mtitles("Pooled" "W2" "W3" "W4" "W5" "W6" "W7")
di as result "T2 done -> first_lasso_pres_check.tex"
}
}


*==============================================================================
* TABLE 3.  ITT on pre-registered fertility outcomes   (main_pres)
*   Dataset: FU_slim.dta.  pdslasso main spec.
*   EXPECT Treatment: (1) any_child All 0.041*** (2) any_child NM 0.15***
*     (3) Ab08 All 0.12** (4) Ab08 Mothers 0.066 (5) Ab08 NM 0.31***
*     (6) wanted_nrch All -0.13 (7) appr_age_fkid All 0.17
*     N: 1130, 350, 1130, 773, 350, 1130, 1130
*==============================================================================
if $t3_mainitt {
capture noisily {
use "$CRE\FU_slim.dta", clear
estimates drop _all
* (1) any_child, All
pdslasso any_child orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su any_child if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo m1
* (2) any_child, Non-mothers
pdslasso any_child orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su any_child if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Non-mothers"
eststo m2
* (3) Ab08, All
pdslasso Ab08 orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo m3
* (4) Ab08, Mothers
pdslasso Ab08 orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==1, partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Mothers"
eststo m4
* (5) Ab08, Non-mothers
pdslasso Ab08 orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Non-mothers"
eststo m5
* (6) wanted_nrch, All
pdslasso wanted_nrch orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su wanted_nrch if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo m6
* (7) appr_age_fkid, All
pdslasso appr_age_fkid orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su appr_age_fkid if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo m7
esttab m1 m2 m3 m4 m5 m6 m7 using "$OUT\main_pres_check.tex", replace style(tex) ///
    b(a2) se starlevels(* 0.10 ** 0.05 *** 0.01)                                 ///
    keep(orig_treatment) varlabels(orig_treatment "Treatment")                   ///
    stats(mean_depvar_c Sample N Controls, labels("Control mean" "Sample" "N" "Controls") fmt(2 0 0 2 0)) ///
    mtitles("Any children" "Any children" "Number of children" "Number of children" ///
            "Number of children" "Wanted nr children" "Appr age first child")
di as result "T3 done -> main_pres_check.tex"
}
}


*==============================================================================
* TABLE 4.  IV: instrument wage employment with treatment   (IV_combined)
*   Dataset: FU_slim.dta.  Panel A any_child, Panel B Ab08.
*   Cols: (1) FS months (2) OLS (3) IV (4) FS any-month (5) OLS (6) IV.
*   First-stage F reported (squared t-ratio on treatment) as in the paper.
*   EXPECT Panel A IV: months col3 0.0054**, any-month col6 0.19**; F 25 / 64.
*          Panel B IV: months col3 0.020**,  any-month col6 0.72**.
*==============================================================================
if $t4_iv {
capture noisily {
use "$CRE\FU_slim.dta", clear
estimates drop _all
pdslasso months_worked orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su months_worked if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd scalar Fstat = (_b[orig_treatment]/_se[orig_treatment])^2
eststo first
pdslasso any_work_month orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su any_work_month if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd scalar Fstat = (_b[orig_treatment]/_se[orig_treatment])^2
eststo first_b
foreach var of varlist Ab08 any_child {
    pdslasso `var' months_worked (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo OLS_`var'
    pdslasso `var' any_work_month (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo OLS_`var'_b
    ivlasso `var' (months_worked=orig_treatment) (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo IV_`var'
    ivlasso `var' (any_work_month=orig_treatment) (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo IV_`var'_b
}
local vlist months_worked any_work_month orig_treatment
local vlab varlabels(months_worked "Months worked" any_work_month "Any month" orig_treatment "Treatment")
local sts stats(mean_depvar_c Fstat N Controls, labels("Control mean" "F-value" "N" "Controls") fmt(2 0 0 2 0))
local mtit mtitles("First stage: Months" "OLS" "IV" "First stage: Any month" "OLS" "IV")
#delimit ;
esttab first *_any_child first_b *_any_child_b using "$OUT\IV_combined_check.tex",
    replace style(tex) fragment `sts' starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se
    `mtit' keep(`vlist') order(`vlist') `vlab'
    prehead("\begin{tabular}{l*{6}{c}}" "\hline" "\multicolumn{7}{l}{\textbf{Panel A. Any child}}\\")
    posthead("\hline") postfoot("") ;
esttab first *_Ab08 first_b *_Ab08_b using "$OUT\IV_combined_check.tex",
    append style(tex) fragment `sts' starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se
    nomtitles nonumbers keep(`vlist') order(`vlist') `vlab'
    prehead("\hline" "\multicolumn{7}{l}{\textbf{Panel B. Number of children}}\\" "\hline")
    posthead("") postfoot("\hline" "\end{tabular}") ;
#delimit cr
di as result "T4 done -> IV_combined_check.tex"
}
}


*==============================================================================
* FIGURE.  Kaplan-Meier duration, all women / baseline non-mothers   (KM_combined)
*   Dataset: FU_slim.dta.  Two stacked panels.
*==============================================================================
if $f_km {
capture noisily {
use "$CRE\FU_slim.dta", clear
drop if attrit==1
* km_duration (months) and km_event are pre-computed in the release build from
* birth timing and interview dates (the raw dates are not in the public data).
stset km_duration, failure(km_event)
sts graph, by(orig_treatment) survival title("") subtitle("Panel A. All women") ///
    legend(order(1 "Control" 2 "Treatment")) ///
    xline(9, lcolor(purple%50)) xline(35, lcolor(black%50)) ///
    xline(0 1 2 3 4 5 6 7 8 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34, lcolor(gs14)) ///
    xtitle("Months Since Treatment") name(kmA, replace)
graph save "$OUT\kmA.gph", replace
sts graph if any_child_w1nr==0, by(orig_treatment) survival title("") subtitle("Panel B. Baseline non-mothers") ///
    legend(order(1 "Control" 2 "Treatment")) ///
    xline(9, lcolor(purple%50)) xline(15, lcolor(black%50)) ///
    xline(0 1 2 3 4 5 6 7 8 10 11 12 13 14, lcolor(gs14)) ///
    xtitle("Months Since Treatment") name(kmB, replace)
graph save "$OUT\kmB.gph", replace
graph combine "$OUT\kmA.gph" "$OUT\kmB.gph", col(1) xsize(6.5) ysize(9) ///
    graphregion(color(white)) plotregion(color(white)) name(km_combined, replace)
graph export "$OUT\KM_combined_check.pdf", replace
di as result "F(KM) done -> KM_combined_check.pdf"
}
}


*==============================================================================
* TABLE 5.  Surrogate extrapolation to completed fertility   (surrogate_paper)
*   Needs DHS 2024 (ETIR8AFL); see the DHS note below. The committed surrogate_paper.tex is a
*   HAND-ASSEMBLED 2-panel table: Panel A = 2 rows from surrogate_dhs (endline +
*   2024-urban completed-fertility map); Panel B = 2 rows from surrogate_childless
*   (endline childlessness + 2024-urban predicted completed childlessness).
*   This block rebuilds ONLY the 2024-urban map (the one the paper uses).
*   EXPECT Panel A: endline number of children full 0.117 (0.057), nm 0.314 (0.103);
*                   predicted completed fertility full 0.132 (0.063), nm 0.320 (0.107).
*          Panel B: endline childlessness full -0.041 (0.016), nm -0.151 (0.048);
*                   predicted completed childlessness full -0.012 (0.006), nm -0.051 (0.019).
*==============================================================================
if $t5_surrogate {
* This table needs the 2024 Ethiopia DHS individual-recode file, which DHS Program
* terms forbid us from redistributing. It uses only fertility/demographic recode
* variables (no GPS/coordinates), so a replicator can reproduce it after a free
* DHS registration. Download the 2024 Ethiopia "Individual Recode" (Stata .dta)
* from https://dhsprogram.com/data/ (register -> Ethiopia -> 2024 DHS -> IR file)
* and place it at $DHS\2024\ETIR8ADT\ETIR8AFL.dta. If it is absent, this is skipped.
capture confirm file "$DHS\2024\ETIR8ADT\ETIR8AFL.dta"
if _rc {
    di as text "SKIP Table 5 (surrogate): DHS 2024 file not found at $DHS\2024\ETIR8ADT\. See README."
}
else {
capture noisily {
* ---- Build 2024-urban DHS completer panel (parity-at-age) ----
local b3list ""
forvalues k=1/20 {
    local kk : display %02.0f `k'
    local b3list `b3list' b3_`kk'
}
use v005 v011 v012 v025 v133 v201 `b3list' using "$DHS\2024\ETIR8ADT\ETIR8AFL.dta", clear
keep if inrange(v012,45,49)
gen ceb = v201
gen byte urban = v025==1
gen wt = v005/1000000
forvalues a = 28(2)40 {
    gen par_`a' = 0
    forvalues k=1/20 {
        local kk : display %02.0f `k'
        capture confirm variable b3_`kk'
        if _rc==0 quietly replace par_`a' = par_`a' + (b3_`kk' - v011 < `a'*12 & !missing(b3_`kk'))
    }
}
gen long wid = _n
keep ceb urban wt wid par_*
reshape long par_, i(wid) j(refage)
gen remaining = ceb - par_
drop if remaining < 0
gen byte cchildless = (ceb==0)
* map A: remaining births on parity x age (2024 urban)
reg remaining c.par_##c.refage c.par_#c.par_ c.refage#c.refage [pw=wt] if urban==1
estimates save "$OUT\_map2024u.ster", replace
* map B: persistence of childlessness (logit among childless-at-age rows, 2024 urban)
logit cchildless c.refage [pw=wt] if par_==0 & urban==1, vce(cluster wid)
estimates save "$OUT\_pi2024u.ster", replace

* ---- Apply to the RCT endline sample ----
use "$CRE\FU_slim.dta", clear
keep if !missing(Ab08)
gen byte nonmom = (any_child_w1nr==0)
gen byte c0 = (Ab08==0)
gen par_   = Ab08
gen refage = base_age + 9
replace refage = 28 if refage < 28
replace refage = 40 if refage > 40
estimates use "$OUT\_map2024u.ster"
predict rhat, xb
replace rhat = 0 if rhat < 0
gen comp = Ab08 + rhat
estimates use "$OUT\_pi2024u.ster"
predict pihat, pr
gen pc0 = c0 * pihat

tempname S
file open `S' using "$OUT\surrogate_paper_check.tex", write replace
file write `S' "\begin{tabular}{lcc}" _n "\toprule" _n
file write `S' " & Full sample & Baseline non-mothers \\" _n
file write `S' "Treatment effect on \dots & ATE (SE) & ATE (SE) \\" _n "\midrule" _n
file write `S' "Panel A: number of children & & \\" _n
foreach yv in Ab08 comp {
    if "`yv'"=="Ab08" local lab "Observed endline number of children"
    else              local lab "Predicted completed fertility"
    quietly pdslasso `yv' orig_treatment (i.em_* m_* bl_fe*), partial(bl_fe*) robust
    local bf = _b[orig_treatment]
    local sf = _se[orig_treatment]
    quietly pdslasso `yv' orig_treatment (i.em_* m_* bl_fe*) if nonmom==1, partial(bl_fe*) robust
    local bn = _b[orig_treatment]
    local sn = _se[orig_treatment]
    di as result "`lab': full " %6.3f `bf' " (" %5.3f `sf' ")   nm " %6.3f `bn' " (" %5.3f `sn' ")"
    file write `S' "`lab' & " %5.3f (`bf') " (" %5.3f (`sf') ") & " %5.3f (`bn') " (" %5.3f (`sn') ") \\" _n
}
file write `S' "\midrule" _n "Panel B: any children & & \\" _n
foreach yv in c0 pc0 {
    if "`yv'"=="c0" local lab "Observed endline childlessness"
    else            local lab "Predicted completed childlessness"
    quietly pdslasso `yv' orig_treatment (i.em_* m_* bl_fe*), partial(bl_fe*) robust
    local bf = _b[orig_treatment]
    local sf = _se[orig_treatment]
    quietly pdslasso `yv' orig_treatment (i.em_* m_* bl_fe*) if nonmom==1, partial(bl_fe*) robust
    local bn = _b[orig_treatment]
    local sn = _se[orig_treatment]
    di as result "`lab': full " %6.3f `bf' " (" %5.3f `sf' ")   nm " %6.3f `bn' " (" %5.3f `sn' ")"
    file write `S' "`lab' & " %5.3f (`bf') " (" %5.3f (`sf') ") & " %5.3f (`bn') " (" %5.3f (`sn') ") \\" _n
}
file write `S' "\bottomrule" _n "\end{tabular}" _n
file close `S'
di as result "T5 done -> surrogate_paper_check.tex"
}
}
}


*==============================================================================
* TABLE 6.  Cumulative household income & savings, balanced   (hhinc6_savings_cum_bal)
*   Dataset: cumulative_slim.dta (long).  Reshape wide, cumulate, pdslasso.
*   Balanced sample = observed in wave 7 (hhinc67!=. / savings7!=.), N=795.
*   EXPECT Treatment, income:  2525.0*** 4290.3*** 5742.2*** 6991.3*** 8773.7*** 10001.8***
*          Treatment, savings: 2305.8*** 3434.5*** 4303.1*** 5494.7*** 7011.6*** 7651.4***
*==============================================================================
if $t6_cumbal {
capture noisily {
use "$CRE\cumulative_slim.dta", clear
keep hhinc6 savings orig_treatment_r id_anon wave em* m_* bl_fe*
* reshape ONLY the time-varying variables; baseline controls (em* m_* bl_fe*) are
* constant within id_anon and stay as single columns (as in exhibits_aer.do T6).
reshape wide hhinc6 savings orig_treatment_r, i(id_anon) j(wave)
foreach x in hhinc6 savings {
    gen sum27_`x' = `x'2+`x'3+`x'4+`x'5+`x'6+`x'7
    gen sum23_`x' = `x'2+`x'3
    gen sum24_`x' = `x'2+`x'3+`x'4
    gen sum25_`x' = `x'2+`x'3+`x'4+`x'5
    gen sum26_`x' = `x'2+`x'3+`x'4+`x'5+`x'6
}
estimates drop _all
foreach x in hhinc6 savings {
    pdslasso `x'2 orig_treatment_r1 (i.em* m_* `x'1 bl_fe*) if !missing(sum27_`x'), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `x'2 if e(sample)==1 & orig_treatment_r1==0
    estadd scalar mean_depvar_c = r(mean)
    eststo `x'_2
    foreach j in 3 4 5 6 7 {
        pdslasso sum2`j'_`x' orig_treatment_r1 (i.em* m_* `x'1 bl_fe*) if !missing(sum27_`x'), partial(bl_fe*) robust
        estadd local Controls "Lasso"
        qui su sum2`j'_`x' if e(sample)==1 & orig_treatment_r1==0
        estadd scalar mean_depvar_c = r(mean)
        eststo `x'_`j'
    }
}
local sts6 stats(mean_depvar_c N Controls, labels("Control mean" "N" "Controls") fmt(2 0 2 0))
local mt6 mtitles("Wave 2" "2-3" "2-4" "2-5" "2-6" "2-7")
#delimit ;
esttab hhinc6_2 hhinc6_3 hhinc6_4 hhinc6_5 hhinc6_6 hhinc6_7 using "$OUT\hhinc6_savings_cum_bal_check.tex",
    replace style(tex) fragment `sts6' starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se `mt6'
    keep(orig_treatment_r1) order(orig_treatment_r1) varlabels(orig_treatment_r1 "Treatment")
    prehead("\begin{tabular}{l*{6}{c}}" "\hline" "\multicolumn{7}{l}{\textbf{Panel A. Household income}}\\")
    posthead("\hline") postfoot("") ;
esttab savings_2 savings_3 savings_4 savings_5 savings_6 savings_7 using "$OUT\hhinc6_savings_cum_bal_check.tex",
    append style(tex) fragment `sts6' starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nomtitles nonumbers
    keep(orig_treatment_r1) order(orig_treatment_r1) varlabels(orig_treatment_r1 "Treatment")
    prehead("\hline" "\multicolumn{7}{l}{\textbf{Panel B. Savings}}\\" "\hline")
    posthead("") postfoot("\hline" "\end{tabular}") ;
#delimit cr
di as result "T6 done -> hhinc6_savings_cum_bal_check.tex"
}
}


*==============================================================================
* TABLE 7.  Heterogeneity by baseline income quintile   (hhinc_hetero_any_nr)
*   Dataset: FU_slim.dta.  4 pdslasso columns:
*     (1) any_child All  (2) any_child NM  (3) Ab08 All  (4) Ab08 NM
*   with quintile main effects + treatment x quintile interactions (Q1 omitted).
*   EXPECT Treatment: (1) 0.067** (2) 0.26*** (3) 0.14 (4) 0.37**
*==============================================================================
if $t7_hetero {
capture noisily {
use "$CRE\FU_slim.dta", clear
xtile hhinc_q = base_hhinc6 if base_hhinc6<., nq(5)
tab hhinc_q, gen(hhinc_q_)
gen t_q2 = hhinc_q_2 * orig_treatment
gen t_q3 = hhinc_q_3 * orig_treatment
gen t_q4 = hhinc_q_4 * orig_treatment
gen t_q5 = hhinc_q_5 * orig_treatment
estimates drop _all
foreach y in any_child Ab08 {
    pdslasso `y' orig_treatment hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 ///
        t_q2 t_q3 t_q4 t_q5 (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `y' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    estadd local Sample "All"
    eststo `y'_all
    pdslasso `y' orig_treatment hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 ///
        t_q2 t_q3 t_q4 t_q5 (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `y' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    estadd local Sample "Non-mothers"
    eststo `y'_nm
}
local vlist orig_treatment hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 t_q2 t_q3 t_q4 t_q5
esttab any_child_all any_child_nm Ab08_all Ab08_nm using "$OUT\hhinc_hetero_any_nr_check.tex", ///
    replace style(tex) b(a2) se starlevels(* 0.10 ** 0.05 *** 0.01)             ///
    stats(mean_depvar_c Sample N Controls, labels("Control mean" "Sample" "N" "Controls") fmt(2 0 0 2 0)) ///
    keep(`vlist') order(`vlist')                                                ///
    varlabels(orig_treatment "Treatment" hhinc_q_2 "Income Q2" hhinc_q_3 "Income Q3" ///
              hhinc_q_4 "Income Q4" hhinc_q_5 "Income Q5 (richest)"             ///
              t_q2 "Treatment $\times$ Income Q2" t_q3 "Treatment $\times$ Income Q3" ///
              t_q4 "Treatment $\times$ Income Q4" t_q5 "Treatment $\times$ Income Q5 (richest)") ///
    mtitles("Any children" "Any children" "Number of children" "Number of children")
di as result "T7 done -> hhinc_hetero_any_nr_check.tex"
}
}


*==============================================================================
* TABLE 8.  Other potential mechanisms   (mechanisms_combined)
*   Datasets: FU_slim.dta (+ cumulative_slim.dta for the HFIAS balanced z-index).
*   11 columns: physical/emotional abuse, husband-decides x3, confident, married,
*   same partner, never moved, children dying, food-insecurity index.
*   EXPECT Treatment: 0.0050 0.0012 0.016 -0.0079 0.0025 -0.032 | 0.0026 0.0036
*     -0.035 | 0.019 -0.066
*==============================================================================
if $t8_mech {
capture noisily {
* The HFIAS balanced-panel z-index (hfias_index) is pre-computed in the release
* build (from the wave-2..7 food-insecurity scale) and is already in FU_slim.
use "$CRE\FU_slim.dta", clear
estimates drop _all
local vlist physical_violence_3m eviol_3m h_fs_nrch h_fs_contraception h_fs_index_small conf_J5 ///
            married same_partner never_moved nr_kids_dying hfias_index
foreach var of local vlist {
    quietly pdslasso `var' orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    quietly su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    di as text %-22s "`var'" "  b = " %8.4f _b[orig_treatment] "  se = " %7.4f _se[orig_treatment]
    eststo `var'
}
esttab `vlist' using "$OUT\mechanisms_combined_check.tex", replace style(tex)   ///
    stats(mean_depvar_c N Controls, labels("Control mean" "N" "Controls") fmt(2 0 2 0)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se keep(orig_treatment)          ///
    order(orig_treatment) varlabels(orig_treatment "Treatment")
di as result "T8 done -> mechanisms_combined_check.tex"
}
}


*==============================================================================
* FIGURE.  Kaplan-Meier duration, by firm wage level   (KM_wage_combined)
*   Dataset: FU_slim.dta.  Panel A high-wage, Panel B low-wage (all grey).
*==============================================================================
if $f_kmwage {
capture noisily {
use "$CRE\FU_slim.dta", clear
drop if attrit==1
* km_duration (months) and km_event are pre-computed in the release build from
* birth timing and interview dates (the raw dates are not in the public data).
stset km_duration, failure(km_event)
sts graph if mw_fac_hi==1, by(orig_treatment) survival title("") subtitle("Panel A. High-wage firms") ///
    legend(order(1 "Control" 2 "Treatment")) ///
    xline(9, lcolor(purple%50)) xline(35, lcolor(black%50)) ///
    xline(0 1 2 3 4 5 6 7 8 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34, lcolor(gs14)) ///
    xtitle("Months Since Treatment") name(kmwA, replace)
graph save "$OUT\kmwA.gph", replace
sts graph if mw_fac_hi==0, by(orig_treatment) survival title("") subtitle("Panel B. Low-wage firms") ///
    legend(order(1 "Control" 2 "Treatment")) ///
    xline(0 1 2 3 4 5 6 7 8 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 97 98 99 100 101 102 103 104 105 106 107 108 109 110, lcolor(gs14)) ///
    xline(9, lcolor(purple%50)) ///
    xtitle("Months Since Treatment") name(kmwB, replace)
graph save "$OUT\kmwB.gph", replace
graph combine "$OUT\kmwA.gph" "$OUT\kmwB.gph", col(1) xsize(6.5) ysize(9) ///
    graphregion(color(white)) plotregion(color(white)) name(km_wage_combined, replace)
graph export "$OUT\KM_wage_combined_check.pdf", replace
di as result "F(KMwage) done -> KM_wage_combined_check.pdf"
}
}

di as text "{hline 78}"
di as text "replication_main.do  finished  $S_DATE $S_TIME"
di as text "Outputs + log in: $OUT"
di as text "{hline 78}"
log close
