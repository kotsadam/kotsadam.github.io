*==============================================================================
* replication_main.do
*   Self-contained, exhibit-by-exhibit replication of the MAIN-BODY exhibits of
*   "Female Jobs and Fertility: Long-term Experimental Evidence from Ethiopian
*   Factories" (current Overleaf draft, October 2026).
*
*   Each block: (i) opens the dataset it needs, (ii) runs the minimal estimation
*   for ONE paper exhibit, (iii) writes a *.tex to $OUT, and (iv) prints
*   the key coefficient(s) to the log. Expected values from the committed
*   Jobs_and_Fertility_overleaf results files are given in comments as
*   "EXPECT ..." so the numbers can be checked at a glance.
*
*   MAIN EXHIBITS (paper table/figure number -> committed results file):
*     Table 1  Baseline characteristics        fert_des_new_fert_ed_edt.tex
*     Table 2  First stage by wave             first_lasso_pres.tex
*     Table 3  ITT fertility                   main_pres.tex
*     Table 4  IV (Wave-2 employment)          IV_w2.tex
*              (the cumulative-employment IV, IV_combined.tex, is now Appendix
*               Table A.6 and lives in replication_appendix.do)
*     Figure   Duration KM (all / non-moms)    KM_combined.pdf
*     Table 5  Surrogate extrapolation         surrogate_paper.tex        [needs DHS]
*     Table 6  Cumulative income & savings     hhinc6_savings_cum_bal.tex
*     Table 7  Heterogeneity by income         hhinc_hetero_any_nr.tex
*     Table 8  Other mechanisms                mechanisms_combined.tex
*     Figure   Duration KM by firm wage        KM_wage_combined.pdf
*
*   DATASETS (Data/created unless noted):
*     FU_slim.dta   cross-section, Wave-7 endline (orig_treatment)
*     panel_slim.dta      person-wave panel (orig_treatment_r, *_r variables)
*     cumulative_slim.dta      person-wave, income/savings (orig_treatment_r)
*     DHS  Ethiopia_women_2016.DTA  and  2024/ETIR8ADT/ETIR8AFL.dta   (surrogate)
*
*   RUN: set global ROOT below, then  do "<ROOT>\do\replication_main.do"
*   (see README.md). All estimation is deterministic; no seed is needed.
*
*==============================================================================
clear all
set more off
set varabbrev off
set maxvar 20000
version 17

*--- switches (1 = run) -------------------------------------------------------
global t1_fertdes   = 1
global t2_firststg  = 1
global t3_mainitt   = 1
global t4_iv        = 1
global f_km         = 1
global t5_surrogate = 1
global t6_cumbal    = 1
global t7_hetero    = 1
global t8_mech      = 1
global f_kmwage     = 1

*--- paths --------------------------------------------------------------------
* EDIT THIS ONE LINE to the absolute path of the replication/ folder on your
* machine (the folder that contains data/, do/, output/). Everything else is
* relative to it. The anonymized datasets live in $ROOT\data.
global ROOT "C:\path\to\replication"
global CRE  "$ROOT\data"
global DHS  "$ROOT\data\DHS"     // put DHS files here if you download them (see README)
global OUT  "$ROOT\output\main"
capture mkdir "$ROOT\output"
capture mkdir "$OUT"

capture log close _all
log using "$OUT\replication_main_log.txt", text replace

*------------------------------------------------------------------------------
* Required user-written packages.
*
* Installed unconditionally with , replace -- deliberately NOT behind a
* "capture which" test.  "capture which" only detects a package that is
* MISSING, so it can never update one that is already installed but out of
* date.  An outdated lassopack / ivreg2 silently shifts the post-double-
* selection Lasso standard errors (this is what produced the ~0.5% SE
* differences against the committed tables, and an F-statistic of 63 instead
* of 64, in Tables 4-7).
*
*  >>> RESTART STATA AFTER THIS BLOCK HAS RUN FOR THE FIRST TIME. <<<
*  Stata keeps the ado-files it has already loaded in memory for the rest of
*  the session, so a newly installed or updated package is not actually used
*  until Stata is restarted.  So: run the do-file once to install, restart
*  Stata, then run it again to produce the output.  (Once the packages are
*  current this block can be left in place -- it just re-checks SSC -- or
*  commented out to save a few seconds per run.)
*------------------------------------------------------------------------------
ssc install lassopack, replace
ssc install pdslasso, replace
ssc install ivreg2, replace
ssc install ranktest, replace
ssc install estout, replace
ssc install cibar, replace

di as text "{hline 78}"
di as text "replication_main.do  started  $S_DATE $S_TIME"
di as text "{hline 78}"


*==============================================================================
* TABLE 1.  Baseline characteristics, by treatment arm   (fert_des_new_fert_ed_edt)
*   Dataset: FU_slim.dta.  Means/SDs by All/Treated/Control for the endline
*   sample (attrit==0); stars = significance of the treatment-control difference
*   from a block-adjusted regression.
*   EXPECT (All column): Treatment 0.50; Any children 0.69; Number of children 1.36;
*     Partner wants more 0.21; Wanted number 3.96; Appr age 22.70; Any wage job
*     0.31; Age 25.13; Muslim 0.14; Protestant 0.23; Educ 9.28; Leisure 33.98;
*     Soc/relig 6.51.  N: All 1130, Treated 560, Control 570.
*   (Number of children was previously quoted as 1.41 here - stale: both the
*    committed manuscript table and this check print 1.36 from nr_births_w1;
*    see discrepancy_log_for_andreas.md, entry 1. Confirmed 2026-08-20.)
*==============================================================================
if $t1_fertdes {
capture noisily {
use "$CRE\FU_slim.dta", clear
keep if attrit==0

* Means/SDs by All/Treated/Control; a star on the control column marks the
* significance of the treatment-control difference (block-adjusted regression);
* the foot reports the joint F-test that all characteristics are unrelated to
* treatment. Baseline "Number of children" is nr_births_w1 (companion of the
* "Any child" row, any_child_w1nr).
capture program drop _fdrow
program define _fdrow
    args fh v label
    quietly su `v'
    local ma=r(mean)
    local sa=r(sd)
    quietly su `v' if orig_treatment==1
    local mt=r(mean)
    local st=r(sd)
    quietly su `v' if orig_treatment==0
    local mc=r(mean)
    local sc=r(sd)
    local star ""
    if "`v'"!="orig_treatment" {
        quietly reg `v' orig_treatment bl_fe*, robust
        local p = 2*ttail(e(df_r), abs(_b[orig_treatment]/_se[orig_treatment]))
        if `p'<0.10 local star "*"
        if `p'<0.05 local star "**"
        if `p'<0.01 local star "***"
    }
    file write `fh' "`label'& " %4.2f (`ma') "& (" %4.2f (`sa') ")& " %4.2f (`mt') "& (" %4.2f (`st') ")& " %4.2f (`mc') "& (" %4.2f (`sc') ")`star'\\" _n
end

file open T using "$OUT\fert_des_new_fert_ed_edt.tex", write replace
file write T "\begin{tabular}{l*{6}{c}}" _n "\toprule" _n
file write T "            &\multicolumn{2}{c}{All}  &\multicolumn{2}{c}{Treated}&\multicolumn{2}{c}{Control}\\\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}" _n
file write T "            &\multicolumn{2}{c}{(1)}  &\multicolumn{2}{c}{(2)}  &\multicolumn{2}{c}{(3)}  \\" _n
file write T "            &\multicolumn{1}{c}{Mean}&\multicolumn{1}{c}{SD}&\multicolumn{1}{c}{Mean}&\multicolumn{1}{c}{SD}&\multicolumn{1}{c}{Mean}&\multicolumn{1}{c}{SD}\\" _n
file write T "\midrule" _n
file write T "\multicolumn{7}{l}{\underline{\smash{Treatment and fertility variables}}} \\ \addlinespace[2pt]" _n
_fdrow T orig_treatment "Treatment"
_fdrow T any_child_w1nr "Any children"
_fdrow T nr_births_w1 "Number of children"
_fdrow T base_partner_w_more_ch "Partner wants more kids"
_fdrow T base_wanted_nrch "Ideal number of children"
_fdrow T base_appr_age_fkid "Appropriate age of first birth"
file write T "\multicolumn{7}{l}{\underline{\smash{Other variables}}} \\ \addlinespace[2pt]" _n
_fdrow T base_K1 "Any wage job ever"
_fdrow T base_age "Age"
_fdrow T base_Muslim "Muslim"
_fdrow T base_Protestant "Protestant"
_fdrow T base_edu_yrs "Years of education"
_fdrow T base_leisure "Leisure time last 7 days (hours)"
_fdrow T base_soc_rel "Social and religious activities last 7 days (hours)"
file write T "\midrule" _n
count
local nall=r(N)
count if orig_treatment==1
local nt=r(N)
count if orig_treatment==0
local nc=r(N)
file write T "\(N\)       & " %9.0fc (`nall') "&            & " %9.0fc (`nt') "&            & " %9.0fc (`nc') "&            \\" _n
file write T "\midrule" _n
local fvars any_child_w1nr nr_births_w1 base_partner_w_more_ch base_wanted_nrch ///
            base_appr_age_fkid base_K1 base_age base_Muslim base_Protestant     ///
            base_edu_yrs base_leisure base_soc_rel
quietly reg orig_treatment `fvars' bl_fe*, robust
testparm `fvars'
file write T "\(F\)-statistic & & & & & & " %4.2f (r(F)) " \\" _n
file write T "P-value \(F\)-test & & & & & & " %4.2f (r(p)) " \\" _n
file write T "\bottomrule" _n "\end{tabular}" _n
file close T
di as result "T1 done -> fert_des_new_fert_ed_edt.tex"
}
}


*==============================================================================
* TABLE 2.  First stage on wage employment, by wave   (first_lasso_pres)
*   Dataset: panel_slim.dta (orig_treatment_r? -> uses orig_treatment; *_r vars).
*   Col 1 pooled (waves 2-7); cols 2-7 = waves 2..7.  DV = any_wage_job_last6_r_alt.
*   EXPECT Treatment: (1) 0.15*** (2) 0.38*** (3) 0.25*** (4) 0.16*** (5) 0.12***
*     (6) 0.032 (7) -0.008     [table prints 3 decimals: b(3) se(3)]
*==============================================================================
if $t2_firststg {
capture noisily {
use "$CRE\panel_slim.dta", clear
capture confirm variable orig_treatment
if _rc capture rename orig_treatment_r orig_treatment

estimates drop _all
pdslasso any_wage_job_last6_r_alt orig_treatment (i.em* m_* bl_fe* i.wave) ///
    if wave>1 & wave<8 & nr_births_r!=., partial(bl_fe* i.wave) cl(id_anon)
estadd local Controls "Lasso"
estadd local Wave "2-7"
qui su any_wage_job_last6_r_alt if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
eststo first_w1
forvalues a = 2/7 {
    pdslasso any_wage_job_last6_r_alt orig_treatment (i.em* m_* bl_fe*) ///
        if wave==`a' & nr_births_r!=., partial(bl_fe*) cl(id_anon)
    estadd local Controls "Lasso"
    estadd local Wave "`a'"
    qui su any_wage_job_last6_r_alt if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo first_w`a'
}
* Layout: one spanning header giving the outcome definition (no per-column wave
* titles); waves reported in a bottom row, with N as the very last row.
* nonotes suppresses esttab's own SE/star legend -- the notes live in the paper's
* tablenotes, so the .tex fragment must carry none.
esttab first_w1 first_w2 first_w3 first_w4 first_w5 first_w6 first_w7           ///
    using "$OUT\first_lasso_pres.tex", replace style(tex) booktabs        ///
    b(3) se(3) starlevels(* 0.10 ** 0.05 *** 0.01) nonotes nomtitles            ///
    keep(orig_treatment) varlabels(orig_treatment "Treatment")                  ///
    stats(mean_depvar_c Controls Wave N,                                        ///
        labels("Control mean" "Controls" "Wave" "N") fmt(2 0 0 %9.0fc))         ///
    prehead("{" "\def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi}"                    ///
        "\begin{tabular}{l*{7}{c}}" "\toprule"                                  ///
        "&\multicolumn{7}{c}{Any formal wage job in the last six months}\\"     ///
        "\cmidrule(lr){2-8}")                                                   ///
    posthead("\midrule")                                                        ///
    postfoot("\bottomrule" "\end{tabular}" "}")
di as result "T2 done -> first_lasso_pres.tex"
}
}


*==============================================================================
* TABLE 3.  ITT on pre-registered fertility outcomes   (main_pres)
*   Dataset: FU_slim.dta.  pdslasso main spec.
*   EXPECT Treatment: (1) any_child All 0.041*** (2) any_child NM 0.15***
*     (3) Ab08 All 0.12** (4) Ab08 Mothers 0.066 (5) Ab08 NM 0.31***
*     (6) wanted_nrch All -0.13 (7) appr_age_fkid All 0.17
*     N: 1130, 350, 1130, 773, 350, 1130, 1130
*==============================================================================
if $t3_mainitt {
capture noisily {
use "$CRE\FU_slim.dta", clear
estimates drop _all
* (1) any_child, All
pdslasso any_child orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su any_child if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo m1
* (2) any_child, Non-mothers
pdslasso any_child orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su any_child if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Non-mothers"
eststo m2
* (3) Ab08, All
pdslasso Ab08 orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo m3
* (4) Ab08, Mothers
pdslasso Ab08 orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==1, partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Mothers"
eststo m4
* (5) Ab08, Non-mothers
pdslasso Ab08 orig_treatment (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su Ab08 if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "Non-mothers"
eststo m5
* (6) wanted_nrch, All
pdslasso wanted_nrch orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su wanted_nrch if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo m6
* (7) appr_age_fkid, All
pdslasso appr_age_fkid orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su appr_age_fkid if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd local Sample "All"
eststo m7
* House template: spanning outcome headers with a \cmidrule only when the
* outcome spans more than one column (single-column outcomes get no rule).
#delimit ;
esttab m1 m2 m3 m4 m5 m6 m7 using "$OUT\main_pres.tex",
    replace style(tex) booktabs fragment
    b(3) se(3) starlevels(* 0.10 ** 0.05 *** 0.01)
    keep(orig_treatment) varlabels(orig_treatment "Treatment")
    stats(mean_depvar_c Sample Controls N, labels("Control mean" "Sample" "Controls" "N") fmt(2 0 0 %9.0fc))
    nomtitles nonumbers
    prehead("\begin{tabular}{l*{7}{c}}" "\toprule"
            " & \multicolumn{2}{c}{Any children} & \multicolumn{3}{c}{Number of children} & \multicolumn{1}{c}{\shortstack{Ideal nr.\\of children}} & \multicolumn{1}{c}{\shortstack{Appropriate age\\at first birth}} \\"
            "\cmidrule(lr){2-3}\cmidrule(lr){4-6}"
            " & (1) & (2) & (3) & (4) & (5) & (6) & (7) \\")
    posthead("\midrule") postfoot("\bottomrule" "\end{tabular}") ;
#delimit cr
di as result "T3 done -> main_pres.tex"
}
}


*==============================================================================
* TABLE 4.  IV: instrument Wave-2 wage employment with treatment   (IV_w2)
*   Datasets: FU_slim.dta (endline outcomes, controls) + panel_slim.dta (Wave-2
*   employment, merged on id_anon).
*   Endogenous variable: any_wage_job_last6_r_alt at wave 2 = formal wage job in
*   the six months before the Wave-2 interview, the outcome of Table 2.
*   Named w2_emp on purpose: a name starting with "em" or "m_" would be swept
*   into the i.em* / m_* control pool.
*   Sample: endline women with non-missing Wave-2 employment (N=1,044).
*   Cols: (1) first stage (2) OLS (3) IV.  Panel A any_child, Panel B Ab08.
*   EXPECT FS 0.38*** (0.028), F 181; OLS 0.0042 / -0.15**; IV 0.11** / 0.32**.
*==============================================================================
if $t4_iv {
capture noisily {
use id_anon wave any_wage_job_last6_r_alt using "$CRE\panel_slim.dta", clear
keep if wave==2
isid id_anon
rename any_wage_job_last6_r_alt w2_emp
keep id_anon w2_emp
tempfile w2
save `w2'

use "$CRE\FU_slim.dta", clear
merge 1:1 id_anon using `w2', keep(master match) nogen
gen byte ivs = !missing(any_child) & !missing(w2_emp)

estimates drop _all
pdslasso w2_emp orig_treatment (i.em* m_* bl_fe*) if ivs, partial(bl_fe*) robust
estadd local Controls "Lasso"
qui su w2_emp if e(sample)==1 & orig_treatment==0
estadd scalar mean_depvar_c = r(mean)
estadd scalar Fstat = (_b[orig_treatment]/_se[orig_treatment])^2
eststo first
foreach var of varlist any_child Ab08 {
    pdslasso `var' w2_emp (i.em* m_* bl_fe*) if ivs, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo OLS_`var'
    ivlasso `var' (w2_emp=orig_treatment) (i.em* m_* bl_fe*) if ivs, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    eststo IV_`var'
}
local vlist w2_emp orig_treatment
local vlab varlabels(w2_emp "Employment" orig_treatment "Treatment")
local sts stats(mean_depvar_c Fstat Controls N, labels("Control mean" "\(F\)-statistic" "Controls" "N") fmt(2 0 0 %9.0fc))
#delimit ;
esttab first OLS_any_child IV_any_child using "$OUT\IV_w2.tex",
    replace style(tex) fragment `sts' starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se
    nomtitles nonumbers keep(`vlist') order(`vlist') `vlab'
    prehead("\begin{tabular}{l*{3}{c}}" "\toprule"
            " & \multicolumn{3}{c}{Employment = formal wage job, Wave 2} \\"
            "\cmidrule(lr){2-4}"
            " & First stage & OLS & IV \\"
            " & (1) & (2) & (3) \\"
            "\midrule"
            "\multicolumn{4}{l}{\textbf{Panel A. Any children}}\\")
    posthead("") prefoot("\midrule") postfoot("") ;
esttab first OLS_Ab08 IV_Ab08 using "$OUT\IV_w2.tex",
    append style(tex) fragment `sts' starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se
    nomtitles nonumbers keep(`vlist') order(`vlist') `vlab'
    prehead("\midrule" "\multicolumn{4}{l}{\textbf{Panel B. Number of children}}\\")
    posthead("") prefoot("\midrule") postfoot("\bottomrule" "\end{tabular}") ;
#delimit cr
di as result "T4 done -> IV_w2.tex"
}
}


*==============================================================================
* FIGURE.  Kaplan-Meier duration, all women / baseline non-mothers   (KM_combined)
*   Dataset: FU_slim.dta.  Two stacked panels.
*==============================================================================
if $f_km {
capture noisily {
use "$CRE\FU_slim.dta", clear
drop if attrit==1
* km_duration (months) and km_event are pre-computed in the release build from
* birth timing and interview dates (the raw dates are not in the public data).
stset km_duration, failure(km_event)
sts graph, by(orig_treatment) survival title("") subtitle("Panel A. All women") ///
    legend(order(1 "Control" 2 "Treatment")) ///
    xline(9, lcolor(purple%50)) xline(35, lcolor(black%50)) ///
    xline(0 1 2 3 4 5 6 7 8 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34, lcolor(gs14)) ///
    xtitle("Months Since Treatment") name(kmA, replace)
graph save "$OUT\kmA.gph", replace
sts graph if any_child_w1nr==0, by(orig_treatment) survival title("") subtitle("Panel B. Baseline non-mothers") ///
    legend(order(1 "Control" 2 "Treatment")) ///
    xline(9, lcolor(purple%50)) xline(15, lcolor(black%50)) ///
    xline(0 1 2 3 4 5 6 7 8 10 11 12 13 14, lcolor(gs14)) ///
    xtitle("Months Since Treatment") name(kmB, replace)
graph save "$OUT\kmB.gph", replace
graph combine "$OUT\kmA.gph" "$OUT\kmB.gph", col(1) xsize(6.5) ysize(9) ///
    graphregion(color(white)) plotregion(color(white)) name(km_combined, replace)
graph export "$OUT\KM_combined.pdf", replace
di as result "F(KM) done -> KM_combined.pdf"
}
}


*==============================================================================
* TABLE 5.  Surrogate extrapolation to completed fertility   (surrogate_paper)
*   Needs DHS 2024 (ETIR8AFL); see the DHS note below. The committed surrogate_paper.tex is a
*   HAND-ASSEMBLED 2-panel table: Panel A = 2 rows from surrogate_dhs (endline +
*   2024-urban completed-fertility map); Panel B = 2 rows from surrogate_childless
*   (endline childlessness + 2024-urban predicted completed childlessness).
*   This block rebuilds ONLY the 2024-urban map (the one the paper uses).
*   EXPECT Panel A: endline number of children full 0.117 (0.057), nm 0.314 (0.103);
*                   predicted completed fertility full 0.132 (0.063), nm 0.320 (0.107).
*          Panel B: endline childlessness full -0.041 (0.016), nm -0.151 (0.048);
*                   predicted completed childlessness full -0.012 (0.006), nm -0.051 (0.019).
*==============================================================================
if $t5_surrogate {
* This table needs the 2024 Ethiopia DHS individual-recode file, which DHS Program
* terms forbid us from redistributing. It uses only fertility/demographic recode
* variables (no GPS/coordinates), so a replicator can reproduce it after a free
* DHS registration. Download the 2024 Ethiopia "Individual Recode" (Stata .dta)
* from https://dhsprogram.com/data/ (register -> Ethiopia -> 2024 DHS -> IR file)
* and place it at $DHS\2024\ETIR8ADT\ETIR8AFL.dta. If it is absent, this is skipped.
capture confirm file "$DHS\2024\ETIR8ADT\ETIR8AFL.dta"
if _rc {
    di as text "SKIP Table 5 (surrogate): DHS 2024 file not found at $DHS\2024\ETIR8ADT\. See README."
}
else {
capture noisily {
* ---- Build 2024-urban DHS completer panel (parity-at-age) ----
local b3list ""
forvalues k=1/20 {
    local kk : display %02.0f `k'
    local b3list `b3list' b3_`kk'
}
use v005 v011 v012 v025 v133 v201 `b3list' using "$DHS\2024\ETIR8ADT\ETIR8AFL.dta", clear
keep if inrange(v012,45,49)
gen ceb = v201
gen byte urban = v025==1
gen wt = v005/1000000
forvalues a = 28(2)40 {
    gen par_`a' = 0
    forvalues k=1/20 {
        local kk : display %02.0f `k'
        capture confirm variable b3_`kk'
        if _rc==0 quietly replace par_`a' = par_`a' + (b3_`kk' - v011 < `a'*12 & !missing(b3_`kk'))
    }
}
gen long wid = _n
keep ceb urban wt wid par_*
reshape long par_, i(wid) j(refage)
gen remaining = ceb - par_
drop if remaining < 0
gen byte cchildless = (ceb==0)
* map A: remaining births on parity x age (2024 urban)
reg remaining c.par_##c.refage c.par_#c.par_ c.refage#c.refage [pw=wt] if urban==1
estimates save "$OUT\_map2024u.ster", replace
* map B: persistence of childlessness (logit among childless-at-age rows, 2024 urban)
logit cchildless c.refage [pw=wt] if par_==0 & urban==1, vce(cluster wid)
estimates save "$OUT\_pi2024u.ster", replace

* ---- Apply to the RCT endline sample ----
use "$CRE\FU_slim.dta", clear
keep if !missing(Ab08)
gen byte nonmom = (any_child_w1nr==0)
gen byte c0 = (Ab08==0)
gen par_   = Ab08
gen refage = base_age + 9
replace refage = 28 if refage < 28
replace refage = 40 if refage > 40
estimates use "$OUT\_map2024u.ster"
predict rhat, xb
replace rhat = 0 if rhat < 0
gen comp = Ab08 + rhat
estimates use "$OUT\_pi2024u.ster"
predict pihat, pr
gen pc0 = c0 * pihat

* stars from the normal p-value of the pdslasso z-statistic (* 0.10 ** 0.05 *** 0.01)
capture program drop _sstar
program define _sstar, rclass
    args b se
    local p = 2*normal(-abs(`b'/`se'))
    local st ""
    if `p'<0.10 local st "*"
    if `p'<0.05 local st "**"
    if `p'<0.01 local st "***"
    return local s "`st'"
end
tempname S
file open `S' using "$OUT\surrogate_paper.tex", write replace
file write `S' "\begin{tabular}{lcc}" _n "\toprule" _n
file write `S' " & Full sample & Baseline non-mothers \\" _n
* No column numbers here: deliberate exception to the house rule. This table has
* only two columns and they are already named in the header row above.
file write `S' "Treatment effect on \dots & ATE (SE) & ATE (SE) \\" _n "\midrule" _n
file write `S' "\multicolumn{3}{l}{\textbf{Panel A. Number of children}} \\" _n
foreach yv in Ab08 comp {
    if "`yv'"=="Ab08" local lab "Observed endline number of children"
    else              local lab "Predicted completed fertility"
    quietly pdslasso `yv' orig_treatment (i.em_* m_* bl_fe*), partial(bl_fe*) robust
    local bf = _b[orig_treatment]
    local sf = _se[orig_treatment]
    quietly pdslasso `yv' orig_treatment (i.em_* m_* bl_fe*) if nonmom==1, partial(bl_fe*) robust
    local bn = _b[orig_treatment]
    local sn = _se[orig_treatment]
    di as result "`lab': full " %6.3f `bf' " (" %5.3f `sf' ")   nm " %6.3f `bn' " (" %5.3f `sn' ")"
    _sstar `bf' `sf'
    local stf "`r(s)'"
    _sstar `bn' `sn'
    local stn "`r(s)'"
    file write `S' "`lab' & " %5.3f (`bf') "`stf' (" %5.3f (`sf') ") & " %5.3f (`bn') "`stn' (" %5.3f (`sn') ") \\" _n
}
file write `S' "\midrule" _n "\multicolumn{3}{l}{\textbf{Panel B. Any children}} \\" _n
foreach yv in c0 pc0 {
    if "`yv'"=="c0" local lab "Observed endline childlessness"
    else            local lab "Predicted completed childlessness"
    quietly pdslasso `yv' orig_treatment (i.em_* m_* bl_fe*), partial(bl_fe*) robust
    local bf = _b[orig_treatment]
    local sf = _se[orig_treatment]
    quietly pdslasso `yv' orig_treatment (i.em_* m_* bl_fe*) if nonmom==1, partial(bl_fe*) robust
    local bn = _b[orig_treatment]
    local sn = _se[orig_treatment]
    di as result "`lab': full " %6.3f `bf' " (" %5.3f `sf' ")   nm " %6.3f `bn' " (" %5.3f `sn' ")"
    _sstar `bf' `sf'
    local stf "`r(s)'"
    _sstar `bn' `sn'
    local stn "`r(s)'"
    file write `S' "`lab' & " %5.3f (`bf') "`stf' (" %5.3f (`sf') ") & " %5.3f (`bn') "`stn' (" %5.3f (`sn') ") \\" _n
}
file write `S' "\bottomrule" _n "\end{tabular}" _n
file close `S'
di as result "T5 done -> surrogate_paper.tex"
}
}
}


*==============================================================================
* TABLE 6.  Cumulative household income & savings, balanced   (hhinc6_savings_cum_bal)
*   Dataset: cumulative_slim.dta (long).  Reshape wide, cumulate, pdslasso.
*   Balanced sample = observed in wave 7 (hhinc67!=. / savings7!=.), N=795.
*   EXPECT Treatment, income:  2525.0*** 4290.3*** 5742.2*** 6991.3*** 8773.7*** 10001.8***
*          Treatment, savings: 2305.8*** 3434.5*** 4303.1*** 5494.7*** 7011.6*** 7651.4***
*==============================================================================
if $t6_cumbal {
capture noisily {
use "$CRE\cumulative_slim.dta", clear
keep hhinc6 savings orig_treatment_r id_anon wave em* m_* bl_fe*
* reshape ONLY the time-varying variables; baseline controls (em* m_* bl_fe*) are
* constant within id_anon and stay as single columns (as in exhibits_aer.do T6).
reshape wide hhinc6 savings orig_treatment_r, i(id_anon) j(wave)
foreach x in hhinc6 savings {
    gen sum27_`x' = `x'2+`x'3+`x'4+`x'5+`x'6+`x'7
    gen sum23_`x' = `x'2+`x'3
    gen sum24_`x' = `x'2+`x'3+`x'4
    gen sum25_`x' = `x'2+`x'3+`x'4+`x'5
    gen sum26_`x' = `x'2+`x'3+`x'4+`x'5+`x'6
}
estimates drop _all
foreach x in hhinc6 savings {
    pdslasso `x'2 orig_treatment_r1 (i.em* m_* `x'1 bl_fe*) if !missing(sum27_`x'), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `x'2 if e(sample)==1 & orig_treatment_r1==0
    estadd scalar mean_depvar_c = r(mean)
    eststo `x'_2
    foreach j in 3 4 5 6 7 {
        pdslasso sum2`j'_`x' orig_treatment_r1 (i.em* m_* `x'1 bl_fe*) if !missing(sum27_`x'), partial(bl_fe*) robust
        estadd local Controls "Lasso"
        qui su sum2`j'_`x' if e(sample)==1 & orig_treatment_r1==0
        estadd scalar mean_depvar_c = r(mean)
        eststo `x'_`j'
    }
}
local sts6 stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(%12.0fc 0 %9.0fc))
#delimit ;
esttab hhinc6_2 hhinc6_3 hhinc6_4 hhinc6_5 hhinc6_6 hhinc6_7 using "$OUT\hhinc6_savings_cum_bal.tex",
    replace style(tex) booktabs fragment `sts6' starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se
    nomtitles nonumbers
    keep(orig_treatment_r1) order(orig_treatment_r1) varlabels(orig_treatment_r1 "Treatment")
    prehead("\begin{tabular}{l*{6}{c}}" "\toprule"
            " & (1) & (2) & (3) & (4) & (5) & (6) \\"
            " & Wave 2 & Waves 2 to 3 & Waves 2 to 4 & Waves 2 to 5 & Waves 2 to 6 & Waves 2 to 7 \\"
            "\midrule"
            "\multicolumn{7}{l}{\textbf{Panel A. Cumulated household income}}\\")
    posthead("") postfoot("") ;
esttab savings_2 savings_3 savings_4 savings_5 savings_6 savings_7 using "$OUT\hhinc6_savings_cum_bal.tex",
    append style(tex) booktabs fragment `sts6' starlevels(* 0.10 ** 0.05 *** 0.01) b(a2) se nomtitles nonumbers
    keep(orig_treatment_r1) order(orig_treatment_r1) varlabels(orig_treatment_r1 "Treatment")
    prehead("\midrule" "\multicolumn{7}{l}{\textbf{Panel B. Cumulated household savings}}\\")
    posthead("") postfoot("\bottomrule" "\end{tabular}") ;
#delimit cr
di as result "T6 done -> hhinc6_savings_cum_bal.tex"
}
}


*==============================================================================
* TABLE 7.  Heterogeneity by baseline income quintile   (hhinc_hetero_any_nr)
*   Dataset: FU_slim.dta.  4 pdslasso columns:
*     (1) any_child All  (2) any_child NM  (3) Ab08 All  (4) Ab08 NM
*   with quintile main effects + treatment x quintile interactions (Q1 omitted).
*   EXPECT Treatment: (1) 0.067** (2) 0.26*** (3) 0.14 (4) 0.37**
*==============================================================================
if $t7_hetero {
capture noisily {
use "$CRE\FU_slim.dta", clear
xtile hhinc_q = base_hhinc6 if base_hhinc6<., nq(5)
tab hhinc_q, gen(hhinc_q_)
gen t_q2 = hhinc_q_2 * orig_treatment
gen t_q3 = hhinc_q_3 * orig_treatment
gen t_q4 = hhinc_q_4 * orig_treatment
gen t_q5 = hhinc_q_5 * orig_treatment
estimates drop _all
foreach y in any_child Ab08 {
    pdslasso `y' orig_treatment hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 ///
        t_q2 t_q3 t_q4 t_q5 (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `y' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    estadd local Sample "All"
    eststo `y'_all
    pdslasso `y' orig_treatment hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 ///
        t_q2 t_q3 t_q4 t_q5 (i.em* m_* bl_fe*) if any_child_w1nr==0, partial(bl_fe*) robust
    estadd local Controls "Lasso"
    qui su `y' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    estadd local Sample "Non-mothers"
    eststo `y'_nm
}
local vlist orig_treatment hhinc_q_2 hhinc_q_3 hhinc_q_4 hhinc_q_5 t_q2 t_q3 t_q4 t_q5
#delimit ;
esttab any_child_all any_child_nm Ab08_all Ab08_nm using "$OUT\hhinc_hetero_any_nr.tex",
    replace style(tex) booktabs fragment b(3) se(3) starlevels(* 0.10 ** 0.05 *** 0.01)
    stats(mean_depvar_c Sample Controls N, labels("Control mean" "Sample" "Controls" "N") fmt(2 0 0 %9.0fc))
    keep(`vlist') order(`vlist')
    varlabels(orig_treatment "Treatment" hhinc_q_2 "Income Q2" hhinc_q_3 "Income Q3"
              hhinc_q_4 "Income Q4" hhinc_q_5 "Income Q5 (richest)"
              t_q2 "Treatment $\times$ Income Q2" t_q3 "Treatment $\times$ Income Q3"
              t_q4 "Treatment $\times$ Income Q4" t_q5 "Treatment $\times$ Income Q5 (richest)")
    nomtitles nonumbers
    prehead("\begin{tabular}{l*{4}{c}}" "\toprule"
            " & \multicolumn{2}{c}{Any children} & \multicolumn{2}{c}{Number of children} \\"
            "\cmidrule(lr){2-3}\cmidrule(lr){4-5}"
            " & (1) & (2) & (3) & (4) \\")
    posthead("\midrule") postfoot("\bottomrule" "\end{tabular}") ;
#delimit cr
di as result "T7 done -> hhinc_hetero_any_nr.tex"
}
}


*==============================================================================
* TABLE 8.  Other potential mechanisms   (mechanisms_combined)
*   Datasets: FU_slim.dta (+ cumulative_slim.dta for the HFIAS balanced z-index).
*   11 columns: physical/emotional abuse, husband-decides x3, confident, married,
*   same partner, never moved, children dying, food-insecurity index.
*   EXPECT Treatment: 0.0050 0.0012 0.016 -0.0079 0.0025 -0.032 | 0.0026 0.0036
*     -0.035 | 0.019 -0.066
*==============================================================================
if $t8_mech {
capture noisily {
* The HFIAS balanced-panel z-index (hfias_index) is pre-computed in the release
* build (from the wave-2..7 food-insecurity scale) and is already in FU_slim.
use "$CRE\FU_slim.dta", clear
estimates drop _all
local vlist physical_violence_3m eviol_3m h_fs_nrch h_fs_contraception h_fs_index_small conf_J5 ///
            married same_partner never_moved nr_kids_dying hfias_index
foreach var of local vlist {
    quietly pdslasso `var' orig_treatment (i.em* m_* bl_fe*), partial(bl_fe*) robust
    estadd local Controls "Lasso"
    quietly su `var' if e(sample)==1 & orig_treatment==0
    estadd scalar mean_depvar_c = r(mean)
    di as text %-22s "`var'" "  b = " %8.4f _b[orig_treatment] "  se = " %7.4f _se[orig_treatment]
    eststo `var'
}
* Header is written by hand in prehead: three thematic groups, then the column
* labels, then the column numbers (house rule: numbers last). nomtitles/nonumbers
* stop esttab printing the stored-estimate names (the raw variable names) and its
* own numbering row; nonotes stops it appending an SE/star legend that would
* duplicate the paper's tablenotes. LaTeX joins the label row's continuation
* lines, so the row can be split here for readability.
esttab `vlist' using "$OUT\mechanisms_combined.tex", replace style(tex) booktabs   ///
    b(3) se(3) nonotes nomtitles nonumbers                                     ///
    stats(mean_depvar_c Controls N, labels("Control mean" "Controls" "N") fmt(2 0 %9.0fc)) ///
    starlevels(* 0.10 ** 0.05 *** 0.01) keep(orig_treatment)                   ///
    order(orig_treatment) varlabels(orig_treatment "Treatment")                ///
    prehead("{" "\def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi}"                   ///
        "\begin{tabular}{l*{11}{c}}" "\toprule"                                ///
        "&\multicolumn{6}{c}{Bargaining and abuse}&\multicolumn{3}{c}{Marriage and mobility}&\multicolumn{2}{c}{Health}\\" ///
        "\cmidrule(lr){2-7}\cmidrule(lr){8-10}\cmidrule(lr){11-12}"            ///
        "&\multicolumn{1}{c}{\shortstack{Physical\\abuse}}"                    ///
        "&\multicolumn{1}{c}{\shortstack{Emotional\\abuse}}"                   ///
        "&\multicolumn{1}{c}{\shortstack{Husband decides\\no. children}}"      ///
        "&\multicolumn{1}{c}{\shortstack{Husband decides\\contraception}}"     ///
        "&\multicolumn{1}{c}{\shortstack{Husband\\decides index}}"             ///
        "&\multicolumn{1}{c}{\shortstack{Confident in\\fertility decisions}}"  ///
        "&\multicolumn{1}{c}{\shortstack{\\Married}}"                          ///
        "&\multicolumn{1}{c}{\shortstack{Same\\partner}}"                      ///
        "&\multicolumn{1}{c}{\shortstack{Never\\moved}}"                       ///
        "&\multicolumn{1}{c}{\shortstack{Number of\\children dying}}"          ///
        "&\multicolumn{1}{c}{\shortstack{Food insecurity\\index}}\\"           ///
        "&(1)&(2)&(3)&(4)&(5)&(6)&(7)&(8)&(9)&(10)&(11)\\")                    ///
    posthead("\midrule") postfoot("\bottomrule" "\end{tabular}" "}")
di as result "T8 done -> mechanisms_combined.tex"
}
}


*==============================================================================
* FIGURE.  Kaplan-Meier duration, by firm wage level   (KM_wage_combined)
*   Dataset: FU_slim.dta.  Panel A high-wage, Panel B low-wage (all grey).
*==============================================================================
if $f_kmwage {
capture noisily {
use "$CRE\FU_slim.dta", clear
drop if attrit==1
* km_duration (months) and km_event are pre-computed in the release build from
* birth timing and interview dates (the raw dates are not in the public data).
stset km_duration, failure(km_event)
sts graph if mw_fac_hi==1, by(orig_treatment) survival title("") subtitle("Panel A. High-wage firms") ///
    legend(order(1 "Control" 2 "Treatment")) ///
    xline(9, lcolor(purple%50)) xline(35, lcolor(black%50)) ///
    xline(0 1 2 3 4 5 6 7 8 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34, lcolor(gs14)) ///
    xtitle("Months Since Treatment") name(kmwA, replace)
graph save "$OUT\kmwA.gph", replace
sts graph if mw_fac_hi==0, by(orig_treatment) survival title("") subtitle("Panel B. Low-wage firms") ///
    legend(order(1 "Control" 2 "Treatment")) ///
    xline(0 1 2 3 4 5 6 7 8 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 97 98 99 100 101 102 103 104 105 106 107 108 109 110, lcolor(gs14)) ///
    xline(9, lcolor(purple%50)) ///
    xtitle("Months Since Treatment") name(kmwB, replace)
graph save "$OUT\kmwB.gph", replace
graph combine "$OUT\kmwA.gph" "$OUT\kmwB.gph", col(1) xsize(6.5) ysize(9) ///
    graphregion(color(white)) plotregion(color(white)) name(km_wage_combined, replace)
graph export "$OUT\KM_wage_combined.pdf", replace
di as result "F(KMwage) done -> KM_wage_combined.pdf"
}
}

di as text "{hline 78}"
di as text "replication_main.do  finished  $S_DATE $S_TIME"
di as text "Outputs + log in: $OUT"
di as text "{hline 78}"
log close
