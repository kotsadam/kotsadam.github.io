*==============================================================================
* build_release.do   (RUN ONCE, by the authors, with the raw data)
*   Builds slim, ANONYMIZED datasets for public release into replication\data\.
*   - Keeps only the variables the replication scripts use.
*   - Replaces the respondent ID with a random id_anon (one crosswalk, applied
*     to all three files).
*   - Pre-computes the few variables that are derived from identifying inputs,
*     then DROPS those inputs:
*       * km_duration, km_event  (from interview dates + birth timing)
*       * mw_fac_hi_within        (from factory wage + region)
*       * no_conf_f               (from the factory conflicts item)
*       * hfias_index             (balanced food-insecurity z-index)
*   - Drops: exact interview dates, birth-timing days, factory wage,
*     factory names/GPS/id, and the raw respondent ID. No factory-level file,
*     no DHS data, and no direct identifiers are written to replication\data\.
*   - Keeps the industrial-park REGION (5 categories, numeric with value
*     labels; added 2026-10-03 for the ITT-by-region appendix figure). Every
*     randomization block (bl_fe*, already released) lies in a single region,
*     so region adds no identifying information (asserted below).
*   This do-file itself is NOT part of the public package (it reads raw data).
*==============================================================================
clear all
set more off
set varabbrev off
set maxvar 20000
version 17

* --- EDIT these lines: Dropbox root with the raw data, release output, log ---
global DBX   "C:\path\to\authors_raw_data"
global OUT   "$DBX\Fertility_Ethiopia\replication\data"
global BRLOG "$DBX\Fertility_Ethiopia\replication\build_release"

* --- RAW inputs (author machine only) ---
global CRE "$DBX\cursor\Fertility_Ethiopia\Data\created"
global FAC "$DBX\cursor\Fertility_Ethiopia\Data\created\factories.dta"
global GBV "$DBX\GBV_application\Data"
capture mkdir "$OUT"

* log to the author-only build_release folder, NOT into the published data folder
capture log close
log using "$BRLOG\build_release_log.txt", text replace

*------------------------------------------------------------------------------
* 0. ID crosswalk: N_Id -> id_anon (random), over the union of all three files
*------------------------------------------------------------------------------
tempfile xa xb xc idx hf
use N_Id using "$CRE\FU_6th_norest.dta", clear
duplicates drop
save `xa'
use N_Id using "$CRE\panel_long.dta", clear
drop if missing(N_Id)
duplicates drop
save `xb'
use N_Id using "$CRE\cumulative.dta", clear
drop if missing(N_Id)
duplicates drop
save `xc'
use `xa', clear
append using `xb'
append using `xc'
duplicates drop N_Id, force
set seed 20260727
gen double _u = runiform()
sort _u
gen long id_anon = _n
drop _u
save `idx'
di as text "crosswalk built: " _N " unique ids"

*------------------------------------------------------------------------------
* 1. hfias_index: balanced food-insecurity z-index (from cumulative)
*------------------------------------------------------------------------------
use N_Id wave hfias orig_treatment_r using "$CRE\cumulative.dta", clear
forvalues w = 2/7 {
    quietly su hfias if wave==`w' & orig_treatment_r==0
    gen double zval`w'x = (hfias - r(mean))/r(sd) if wave==`w'
}
egen double zval = rowtotal(zval2x zval3x zval4x zval5x zval6x zval7x), missing
keep if inrange(wave,2,7)
keep N_Id wave zval
reshape wide zval, i(N_Id) j(wave)
egen byte n_waves_obs = rownonmiss(zval2 zval3 zval4 zval5 zval6 zval7)
egen double hfias_index = rowmean(zval2 zval3 zval4 zval5 zval6 zval7)
replace hfias_index = . if n_waves_obs < 6
keep N_Id hfias_index
save `hf'

*------------------------------------------------------------------------------
* 1b. Contraceptive use (binary "uses any method", waves 2-6) from raw wave files
*------------------------------------------------------------------------------
tempfile cu cw2 cw3 cw4 cw5 cw6
capture program drop mkuse
program define mkuse
    args src new
    capture decode `src', gen(_s)
    if _rc gen _s = ""
    gen byte `new' = .
    replace `new' = 1 if lower(_s)=="yes"
    replace `new' = 0 if lower(_s)=="no"
    drop _s
end
use "$GBV/playdata_november18.dta", clear
mkuse L29 use_w2
keep N_Id use_w2
duplicates drop N_Id, force
save `cw2'

use "$GBV/2nd_Followup_21092019_clean.dta", clear
mkuse l29 use_w3
rename n_id N_Id
keep N_Id use_w3
duplicates drop N_Id, force
save `cw3'

use "$GBV/3rd_followup_Oct30.dta", clear
mkuse l29 use_w4
rename n_id N_Id
keep N_Id use_w4
duplicates drop N_Id, force
save `cw4'

use "$GBV/fourth_fu_1375_final_15032020.dta", clear
mkuse l29 use_w5
rename n_id N_Id
keep N_Id use_w5
duplicates drop N_Id, force
save `cw5'

use "$GBV/CMI_Fifth_Followup_25042021_Final_Cleaned_Version.dta", clear
mkuse l29 use_w6
rename n_id N_Id
keep N_Id use_w6
duplicates drop N_Id, force
save `cw6'

* Wave-2 job module: monthly basic pay, benefits, days/week, hours/day (text, Sec. 2)
tempfile w2job
use N_Id Ka4_1 Ka5_1 Ka6_1_A Ka6_1_B using "$GBV/playdata_november18.dta", clear
duplicates drop N_Id, force
foreach v in Ka4_1 Ka5_1 Ka6_1_A Ka6_1_B {
    rename `v' w2_`v'
}
save `w2job'

use `cw2', clear
merge 1:1 N_Id using `cw3', nogen
merge 1:1 N_Id using `cw4', nogen
merge 1:1 N_Id using `cw5', nogen
merge 1:1 N_Id using `cw6', nogen
save `cu'

*------------------------------------------------------------------------------
* 2. FU_slim  (cross-section, endline)
*------------------------------------------------------------------------------
use "$CRE\FU_6th_norest.dta", clear
* row position in the authors' analysis file: the randomization inference in
* replication_text.do draws permutations in this order (seeded), so it needs it
gen int rawrow = _n

* --- pre-compute derived-from-identifying variables ---
* KM duration (months) and event, from birth timing + interview dates
gen byte km_event = days_to_birth_after < .
gen double km_duration = days_to_birth_after/30
replace km_duration = (intdat_7 - intdat_1)/30 if km_duration==.
* within-region high-wage indicator, from factory wage + region
bysort base_A4: egen double reg_med_wage = median(mw_fac) if !missing(mw_fac)
gen byte mw_fac_hi_within = (mw_fac >= reg_med_wage) if !missing(mw_fac)
* no_conf_f from the factory conflicts item
capture confirm variable no_conf_f
if _rc {
    merge m:1 factory1 using "$FAC", keepusing(havetherebeenanyconflictsrelated) keep(master match) nogen
    capture tab havetherebeenanyconflictsrelated, gen(conf_f)
    capture rename conf_f1 no_conf_f
}
* hfias_index + contraceptive-use indicators
merge 1:1 N_Id using `hf', keep(master match) nogen
merge 1:1 N_Id using `cu', keep(master match) nogen
* Wave-7 contraceptive use from the endline item L29. Its value label lists Yes
* before No (reversed vs W2-W6), so decode by label text, never by code.
mkuse L29 use_w7
* Wave-2 non-response (no Wave-2 firm record; producer do/attrition_w2.do).
* The firm ID A3_w2 itself is NOT released.
gen byte attrit_w2 = missing(A3_w2)
* Wave-2 job module (pay, hours)
merge 1:1 N_Id using `w2job', keep(master match) nogen
* Anonymous code for the six largest firms (>= 80 sampled women), 0 = other
* firms; used for the drop-one-firm robustness check. Unlabeled; the firm ID
* base_A3 itself is NOT released.
bysort base_A3: gen int _fn = _N if !missing(base_A3)
egen byte firm6 = group(_fn base_A3) if _fn >= 80 & !missing(_fn)
replace firm6 = 0 if missing(firm6)
drop _fn
bysort block (firm6): assert firm6[1]==firm6[_N] if !missing(block)
* Sequencing of quitting the factory and first birth (text, Sec. 5.2). The
* dates themselves are NOT released: 1 = quit before the first birth after
* baseline, 0 = birth first; missing if either event is not observed.
gen byte quit_before_birth = (quitdate_f < Ab16Date_1) ///
    if !missing(work_f) & !missing(quitdate_f) & !missing(Ab16Date_1)
* industrial-park region (string in the raw file) -> numeric with value labels
capture confirm string variable region
if !_rc {
    encode region, gen(_region)
    drop region
    rename _region region
}
* every randomization block lies within one region (region is coarser than bl_fe*)
bysort block (region): assert region[1]==region[_N] if !missing(block)

* --- anonymize ---
merge 1:1 N_Id using `idx', keep(master match) nogen keepusing(id_anon)

keep id_anon orig_treatment attrit block ///
     any_child Ab08 any_child_w7nr nr_births_w7 wanted_nrch appr_age_fkid ///
     married same_partner never_moved nr_kids_dying ///
     months_worked any_work_month ///
     physical_violence_3m eviol_3m h_fs_nrch h_fs_contraception h_fs_index_small conf_J5 ///
     nr_births_w1 nr_births_w2 nr_births_w3 nr_births_w4 nr_births_w5 nr_births_w6 ///
     any_child_w1nr any_child_w2nr any_child_w3nr any_child_w4nr any_child_w5nr any_child_w6nr ///
     any_child_y1 any_child_y2 any_child_y3 any_child_y4 any_child_y5 any_child_y6 any_child_y7 any_child_y8 any_child_y9 ///
     nr_births_y1 nr_births_y2 nr_births_y3 nr_births_y4 nr_births_y5 nr_births_y6 nr_births_y7 nr_births_y8 nr_births_y9 ///
     months_since_bl1 months_since_bl2 months_since_bl3 months_since_bl4 months_since_bl5 months_since_bl6 months_since_bl7 ///
     base_any_child base_B11 base_partner_w_more_ch base_wanted_nrch base_appr_age_fkid ///
     base_K1 base_age base_Muslim base_Protestant base_edu_yrs base_leisure base_soc_rel ///
     base_hhinc6 base_any_t base_nr_t z_base_age z_base_age_t ///
     K1_53 K1_12C Interview_Type mw_fac_hi mw_fac_hi_within Asian American Ethiopian share_w prodyear no_conf_f ///
     hfias_index km_duration km_event ///
     asp_eduyears_d asp_age_marry_d asp_imp_earn_own_d asp_nrch_d asp_eduyears_s asp_nrch_s ///
     use_w2 use_w3 use_w4 use_w5 use_w6 use_w7 region ///
     attrit_w2 A6_1 Sc_1 Sc_7 Sc_8 w2_Ka4_1 w2_Ka5_1 w2_Ka6_1_A w2_Ka6_1_B ///
     rawrow firm6 quit_before_birth hhsize hhexp6 partner_w_more_ch ///
     base_norm_salaried_repected base_norm_hhwork_instead base_Ga_2 base_Ga_6 ///
     em* m_* bl_fe*
order id_anon
compress
label data "FU_slim (anonymized release) -- Female Jobs and Fertility"
save "$OUT\FU_slim.dta", replace
di as text "FU_slim saved: " _N " obs, " c(k) " vars"

*------------------------------------------------------------------------------
* 3. panel_slim  (person-wave)
*------------------------------------------------------------------------------
use "$CRE\panel_long.dta", clear
drop if missing(N_Id)
* bring K1_53 in from the endline file (needed for the can/cannot split)
merge m:1 N_Id using "$CRE\FU_6th_norest.dta", keepusing(K1_53) keep(master match) nogen
merge m:1 N_Id using `idx', keep(master match) nogen keepusing(id_anon)
capture confirm variable orig_treatment
if _rc capture clonevar orig_treatment = orig_treatment_r
keep id_anon wave orig_treatment orig_treatment_r any_wage_job_last6_r_alt nr_births_r ///
     any_child_w1nr any_child_r mw_fac_hi base_hhinc6 K1_53 ///
     hours_r leisure_r eating soc_rel_r school sleeping travel unpaid hh_work_r care ///
     em* m_* bl_fe*
order id_anon wave
compress
label data "panel_slim (anonymized release)"
save "$OUT\panel_slim.dta", replace
di as text "panel_slim saved: " _N " obs, " c(k) " vars"

*------------------------------------------------------------------------------
* 4. cumulative_slim  (person-wave; income/savings)
*------------------------------------------------------------------------------
use "$CRE\cumulative.dta", clear
drop if missing(N_Id)
merge m:1 N_Id using `idx', keep(master match) nogen keepusing(id_anon)
keep id_anon wave orig_treatment_r hhinc6 savings inc6 ea_last6_r fac_last6_r ///
     any_wage_job_last6_r_alt any_child_r mw_fac_hi hfias em* m_* bl_fe*
order id_anon wave
compress
label data "cumulative_slim (anonymized release)"
save "$OUT\cumulative_slim.dta", replace
di as text "cumulative_slim saved: " _N " obs, " c(k) " vars"

log close
di "BUILD_RELEASE DONE."
